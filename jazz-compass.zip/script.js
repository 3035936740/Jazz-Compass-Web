import { mountNeoCanvas } from "./neo_canvas.js?v=20260914-2";
import { mountComposition, mountRhythm } from './composition_ui.js?v=20260921-1';
import { midiName } from './classical_voicing.js';
import { mountHarmonyWheel } from "./harmony_connections_ui.js?v=20260915-2";
import { harmonyNeighborhood, mergeConnectionGraphs } from "./harmony_connections.js?v=20260915-2";
import { mountMicrotonal } from "./microtonal_ui.js?v=20260915-2";
import { mountLccExplorer } from "./lcc_ui.js?v=20260915-lab1";
import { mountJazzToolbox } from "./jazz_toolbox_ui.js?v=20260915-1";
import { mountBluesToolbox } from "./blues_ui.js?v=20260915-1";
import { EnhancedChordConverter, JazzBrain, ClassicalHarmonyConnector } from "./jazz_compass.js?v=20260921-modulation2";
import * as lang from "./lang.js?v=20260921-1";

// 在 script.js 顶部（DOMContentLoaded 之外或内部）添加
let modesData = null;
let funcGroupData = null;

function loadJsonFiles() {
  return Promise.all([
    fetch('modes.json').then(res => res.json()).catch(err => { console.warn('modes.json load failed', err); return []; }),
    fetch('funcGroup.json').then(res => res.json()).catch(err => { console.warn('funcGroup.json load failed', err); return {}; })
  ]).then(([modes, funcGroup]) => {
    modesData = modes;
    funcGroupData = funcGroup;
    console.log('Loaded modes:', modesData?.length);
  });
}
document.addEventListener("DOMContentLoaded", () => {
  loadJsonFiles().then(() => {
    initMultiModeCircle();
    // 原有的初始化代码...
    // 注意：需要等待 json 加载完成后再初始化五度圈控制面板
  });


  let circleCurrentKey = null; // 当前选中的调性
  let audioCtx = null;
  let audioMaster = null;
  let audioDryBus = null;
  let audioWetBus = null;
  let audioReverb = null;
  /** 当前会话中的振荡器，再次播放时 stop() 立即静音 */
  let activeSources = [];

  function getAudioContext() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      setupAudioBus(audioCtx);
    }
    if (audioCtx.state === "suspended") {
      audioCtx.resume().catch(() => { });
    }
    return audioCtx;
  }

  /** 全局音频总线（只连一次 destination，避免多次播放叠加爆音） */
  function setupAudioBus(ctx) {
    if (audioMaster) return;

    audioMaster = ctx.createGain();
    audioMaster.gain.value = 0.2;

    const compressor = ctx.createDynamicsCompressor();
    compressor.threshold.setValueAtTime(-22, ctx.currentTime);
    compressor.knee.setValueAtTime(8, ctx.currentTime);
    compressor.ratio.setValueAtTime(6, ctx.currentTime);
    compressor.attack.setValueAtTime(0.003, ctx.currentTime);
    compressor.release.setValueAtTime(0.2, ctx.currentTime);

    audioReverb = createReverb(ctx, 1.2);
    audioReverb.connect(audioMaster);
    audioMaster.connect(compressor);
    compressor.connect(ctx.destination);

    audioDryBus = ctx.createGain();
    audioWetBus = ctx.createGain();
    audioDryBus.gain.value = 1;
    audioWetBus.gain.value = 0.1;
    audioDryBus.connect(audioMaster);
    audioWetBus.connect(audioReverb);
  }

  function trackSource(node) {
    if (node && typeof node.stop === "function") {
      activeSources.push(node);
    }
  }

  /** 立即打断上一轮：停振荡器、静音总线、重建干/湿输入 */
  function interruptPlayback(ctx) {
    const t = ctx.currentTime;
    activeSources.forEach((src) => {
      try {
        src.stop(t);
      } catch (_) { }
    });
    activeSources = [];

    if (audioDryBus) {
      try {
        audioDryBus.gain.cancelScheduledValues(t);
        audioDryBus.gain.setValueAtTime(0, t);
        audioDryBus.disconnect();
      } catch (_) { }
    }
    if (audioWetBus) {
      try {
        audioWetBus.gain.cancelScheduledValues(t);
        audioWetBus.gain.setValueAtTime(0, t);
        audioWetBus.disconnect();
      } catch (_) { }
    }
    if (audioMaster) {
      try {
        audioMaster.gain.cancelScheduledValues(t);
        audioMaster.gain.setValueAtTime(0, t);
        audioMaster.gain.setValueAtTime(0.2, t + 0.01);
      } catch (_) { }
    }

    audioDryBus = ctx.createGain();
    audioWetBus = ctx.createGain();
    audioDryBus.gain.value = 1;
    audioWetBus.gain.value = 0.1;
    audioDryBus.connect(audioMaster);
    audioWetBus.connect(audioReverb);
  }

  /**
   * 钢琴风格的 ADSR 包络
   */
  function applyPianoEnvelope(gainNode, time, duration) {
    const now = time;
    // 确保 gainNode 是 AudioParam
    const gain = gainNode.gain;
    gain.setValueAtTime(0, now);
    // 快速起音（钢琴锤击弦）
    gain.linearRampToValueAtTime(1, now + 0.003);
    // 衰减到持续电平
    gain.linearRampToValueAtTime(0.4, now + 0.08);
    // 持续
    gain.setValueAtTime(0.35, now + 0.15);
    // 缓慢释放（模拟延音踏板）
    gain.exponentialRampToValueAtTime(0.001, now + duration * 1.5);
  }

  /**
   * 播放单个音符的钢琴音色
   */
  /** 音阶等快速连播：单振荡器，减轻 CPU 与卡顿 */
  function createSimpleTone(ctx, freq, time, duration, peakGain = 0.12) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(freq, time);
    const end = time + duration;
    gain.gain.setValueAtTime(0, time);
    gain.gain.linearRampToValueAtTime(peakGain, time + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.001, end);
    osc.connect(gain);
    trackSource(osc);
    osc.start(time);
    osc.stop(end + 0.05);
    return gain;
  }

  /** 和弦：少量谐波，不用 waveshaper，避免削波 */
  function createPianoTone(ctx, freq, time, duration) {
    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(1, time);

    const harmonics = [
      { ratio: 1, amp: 0.2 },
      { ratio: 2, amp: 0.08 },
      { ratio: 3, amp: 0.04 },
    ];

    const stopAt = time + duration * 1.2;
    harmonics.forEach(({ ratio, amp }) => {
      const osc = ctx.createOscillator();
      const harmonicGain = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(freq * ratio, time);
      harmonicGain.gain.setValueAtTime(0, time);
      harmonicGain.gain.linearRampToValueAtTime(amp, time + 0.004);
      harmonicGain.gain.exponentialRampToValueAtTime(0.001, stopAt);
      osc.connect(harmonicGain);
      harmonicGain.connect(masterGain);
      trackSource(osc);
      osc.start(time);
      osc.stop(stopAt + 0.02);
    });

    return masterGain;
  }

  /**
   * 简单的混响效果
   */
  function createReverb(ctx, duration) {
    const convolver = ctx.createConvolver();

    // 创建脉冲响应
    const sampleRate = ctx.sampleRate;
    const length = Math.floor(sampleRate * 1.5);
    const impulse = ctx.createBuffer(2, length, sampleRate);

    for (let channel = 0; channel < 2; channel++) {
      const data = impulse.getChannelData(channel);
      for (let i = 0; i < length; i++) {
        data[i] = (Math.random() * 2 - 1) *
          Math.exp(-i / (sampleRate * 0.3)) *
          (1 - i / length);
      }
    }

    convolver.buffer = impulse;
    return convolver;
  }

  /**
   * 播放和弦声音 - 钢琴音色版本（多八度扩展）
   */
  function playChord(frequencies, duration = 1.2, options = {}) {
    try {
      const ctx = getAudioContext();
      if (options.interrupt !== false) interruptPlayback(ctx);
      const now = ctx.currentTime;
      // 88-key/MIDI chord input may contain more than eight held notes.
      // Keep the shared multi-harmonic piano timbre while allowing wider harmony.
      const uniqueFreqs = [...new Set(frequencies)].slice(0, 16);

      uniqueFreqs.forEach((freq, index) => {
        const noteTime = now + index * 0.012;
        const tone = createPianoTone(ctx, freq, noteTime, duration);
        tone.connect(audioDryBus);
        tone.connect(audioWetBus);
      });
    } catch (e) {
      console.warn("playChord failure:", e);
    }
  }

  /** Independent piano voices for held MIDI notes and the 88-key chord latch. */
  function createHeldPianoVoice(frequency, velocity = 100) {
    const ctx = getAudioContext();
    const start = ctx.currentTime;
    const level = Math.max(0.08, Math.min(1, velocity / 127));
    const voiceGain = ctx.createGain();
    voiceGain.gain.setValueAtTime(0, start);
    voiceGain.gain.linearRampToValueAtTime(level, start + 0.006);
    voiceGain.gain.exponentialRampToValueAtTime(Math.max(0.001, level * 0.38), start + 0.35);
    voiceGain.gain.exponentialRampToValueAtTime(Math.max(0.001, level * 0.16), start + 3);
    voiceGain.connect(audioMaster);
    let endedPartials = 0;
    const pianoPartials = [
      { ratio: 1, amp: 0.18 },
      { ratio: 2.002, amp: 0.065 },
      { ratio: 3.011, amp: 0.025 },
      { ratio: 4.025, amp: 0.009 },
    ];
    const oscillators = pianoPartials.map(({ ratio, amp }) => {
      const oscillator = ctx.createOscillator();
      const partial = ctx.createGain();
      oscillator.type = "triangle";
      oscillator.frequency.setValueAtTime(frequency * ratio, start);
      partial.gain.setValueAtTime(amp, start);
      oscillator.connect(partial);
      partial.connect(voiceGain);
      oscillator.onended = () => {
        oscillator.disconnect();
        partial.disconnect();
        if (++endedPartials === pianoPartials.length) voiceGain.disconnect();
      };
      oscillator.start(start);
      return { oscillator, ratio };
    });
    // A very short filtered hammer attack gives the held harmonics a piano-like onset.
    const hammerBuffer = ctx.createBuffer(1, Math.max(1, Math.round(ctx.sampleRate * 0.045)), ctx.sampleRate);
    const hammerSamples = hammerBuffer.getChannelData(0);
    for (let i = 0; i < hammerSamples.length; i++) hammerSamples[i] = (Math.random() * 2 - 1) * (1 - i / hammerSamples.length);
    const hammer = ctx.createBufferSource();
    const hammerFilter = ctx.createBiquadFilter();
    const hammerGain = ctx.createGain();
    hammer.buffer = hammerBuffer;
    hammerFilter.type = "highpass";
    hammerFilter.frequency.setValueAtTime(950, start);
    hammerGain.gain.setValueAtTime(0.018 * level, start);
    hammerGain.gain.exponentialRampToValueAtTime(0.001, start + 0.035);
    hammer.connect(hammerFilter);
    hammerFilter.connect(hammerGain);
    hammerGain.connect(voiceGain);
    hammer.onended = () => { hammer.disconnect(); hammerFilter.disconnect(); hammerGain.disconnect(); };
    hammer.start(start);
    hammer.stop(start + 0.045);
    let stopped = false;
    return {
      setFrequency(nextFrequency) {
        if (stopped || !Number.isFinite(nextFrequency) || nextFrequency <= 0) return;
        const now = ctx.currentTime;
        for (const { oscillator, ratio } of oscillators) {
          oscillator.frequency.setTargetAtTime(nextFrequency * ratio, now, 0.012);
        }
      },
      stop() {
        if (stopped) return;
        stopped = true;
        const now = ctx.currentTime;
        voiceGain.gain.cancelScheduledValues(now);
        voiceGain.gain.setValueAtTime(Math.max(0.001, voiceGain.gain.value), now);
        voiceGain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
        for (const { oscillator } of oscillators) oscillator.stop(now + 0.2);
      },
    };
  }

  // 保持原有的音符转频率函数
  function noteToFrequency(noteName) {
    const noteMap = {
      C: 0, "C#": 1, Db: 1, D: 2, "D#": 3, Eb: 3, E: 4,
      F: 5, "F#": 6, Gb: 6, G: 7, "G#": 8, Ab: 8, A: 9,
      "A#": 10, Bb: 10, B: 11,
    };

    const match = noteName.match(/^([A-G][#b]?)(\d)?$/);
    if (!match) return 440;

    const note = match[1];
    const octave = match[2] ? parseInt(match[2]) : 4;

    const semitone = noteMap[note];
    if (semitone === undefined) return 440;

    const midiNote = semitone + (octave + 1) * 12;
    return 440 * Math.pow(2, (midiNote - 69) / 12);
  }

  /**
   * 将音符名转换为半音值（0-11）
   */
  function noteToSemitoneValue(noteName) {
    const noteMap = {
      C: 0, "C#": 1, Db: 1, D: 2, "D#": 3, Eb: 3, E: 4,
      F: 5, "F#": 6, Gb: 6, G: 7, "G#": 8, Ab: 8, A: 9,
      "A#": 10, Bb: 10, B: 11,
    };

    return noteMap[noteName];
  }

  /**
   * 根据半音值和八度直接计算频率
   * @param {number} semitone - 半音值 (0-11)
   * @param {number} octave - 八度，C4 的 MIDI 编号为 60
   * @returns {number} 频率
   */
  function semitoneToFreq(semitone, octave) {
    // MIDI 编号：C0 = 12, C4 = 60
    const midiNote = semitone + (octave + 1) * 12;
    return 440 * Math.pow(2, (midiNote - 69) / 12);
  }

  function semitoneToMidi(semitone, octave) {
    return semitone + (octave + 1) * 12;
  }

  function resolveRootOctave(semitone, baseOctave, lastRootMidi, voiceLeading = "ascending") {
    if (lastRootMidi == null) return baseOctave;

    if (voiceLeading === "nearest") {
      const minMidi = semitoneToMidi(0, baseOctave);
      const maxMidi = semitoneToMidi(11, baseOctave);
      const candidates = [];

      for (let octave = baseOctave - 2; octave <= baseOctave + 2; octave++) {
        const midi = semitoneToMidi(semitone, octave);
        candidates.push({ octave, midi });
      }

      const rangedCandidates = candidates.filter(({ midi }) => midi >= minMidi && midi <= maxMidi);
      const availableCandidates = rangedCandidates.length ? rangedCandidates : candidates;
      let bestOctave = baseOctave;
      let bestDistance = Infinity;

      availableCandidates.forEach(({ octave, midi }) => {
        const distance = Math.abs(midi - lastRootMidi);
        if (distance < bestDistance) {
          bestDistance = distance;
          bestOctave = octave;
        }
      });

      return bestOctave;
    }

    let octave = baseOctave;
    while (semitoneToMidi(semitone, octave) <= lastRootMidi) {
      octave += 1;
    }
    return octave;
  }

  /**
   * 和弦频率：以 i 级（表第一行）为基准八度，后续级根音 MIDI 严格高于前一级
   * @param {number|null} lastRootMidi - 上一行和弦根音 MIDI，首行传 null
   * @returns {{ freqs: number[], rootMidi: number|null }}
   */
  function chordNotesToFrequencies(
    notes,
    baseOctave = 4,
    multiOctave = false,
    lastRootMidi = null,
    options = {},
  ) {
    const freqs = [];
    let prevSemitone = null;
    let octave = baseOctave;
    let rootMidi = null;

    notes.forEach((note, idx) => {
      const semitone = noteToSemitoneValue(note);
      if (semitone === undefined) return;

      if (idx === 0) {
        if (lastRootMidi != null) {
          octave = resolveRootOctave(semitone, baseOctave, lastRootMidi, options.voiceLeading);
        }
        rootMidi = semitoneToMidi(semitone, octave);
      } else if (prevSemitone !== null && semitone <= prevSemitone) {
        octave += 1;
      }

      freqs.push(semitoneToFreq(semitone, octave));

      if (multiOctave) {
        freqs.push(semitoneToFreq(semitone, octave - 1));
        freqs.push(semitoneToFreq(semitone, octave - 2));
        freqs.push(semitoneToFreq(semitone, octave + 1));
        freqs.push(semitoneToFreq(semitone, octave + 2));
      }

      prevSemitone = semitone;
    });

    return { freqs, rootMidi };
  }

  let majorMode = "natural"; // "natural" | "harmonic"
  let minorMode = "natural"; // "natural" | "harmonic"
  const canvas = document.getElementById("circle-canvas");
  const container = document.getElementById("circle-canvas-container");
  const tableContainer = document.getElementById("circle-table-container");
  const resetBtn = document.getElementById("circle-reset");

  if (!canvas || canvas.dataset.initialized) return;
  canvas.dataset.initialized = "true";

  // Canvas 尺寸适配
  function resizeCanvas() {
    const rect = container.getBoundingClientRect();
    const size = Math.min(rect.width, 520);
    const dpr = window.devicePixelRatio || 1;
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    canvas.style.width = size + "px";
    canvas.style.height = size + "px";
    const ctx = canvas.getContext("2d");
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(dpr, dpr);
    return { size, ctx };
  }

  // 五度圈数据：按五度顺序排列（从 F 开始顺时针）
  const circleData = [
    { major: "C", minor: "Am", sharps: 0, flats: 0, enharmonic: null },
    { major: "G", minor: "Em", sharps: 1, flats: 0, enharmonic: null },
    { major: "D", minor: "Bm", sharps: 2, flats: 0, enharmonic: null },
    { major: "A", minor: "F#m", sharps: 3, flats: 0, enharmonic: null },
    { major: "E", minor: "C#m", sharps: 4, flats: 0, enharmonic: null },
    { major: "B", minor: "G#m", sharps: 5, flats: 0, enharmonic: "Cb" },
    { major: "Gb", minor: "Ebm", sharps: 6, flats: 6, enharmonic: "F#" },
    { major: "Db", minor: "Bbm", sharps: 0, flats: 5, enharmonic: "C#" },
    { major: "Ab", minor: "Fm", sharps: 0, flats: 4, enharmonic: null },
    { major: "Eb", minor: "Cm", sharps: 0, flats: 3, enharmonic: null },
    { major: "Bb", minor: "Gm", sharps: 0, flats: 2, enharmonic: null },
    { major: "F", minor: "Dm", sharps: 0, flats: 1, enharmonic: null },
  ];

  // 大调音级公式
  const majorScaleIntervals = [0, 2, 4, 5, 7, 9, 11];
  // 自然小调音级公式
  const minorScaleIntervals = [0, 2, 3, 5, 7, 8, 10];
  // 和声大调音级公式 (降6级)
  const harmonicMajorIntervals = [0, 2, 4, 5, 7, 8, 11];
  // 和声小调音级公式 (升7级)
  const harmonicMinorIntervals = [0, 2, 3, 5, 7, 8, 11];

  const majorChordTypes = ["maj", "m", "m", "maj", "maj", "m", "dim"];
  const minorChordTypes = ["m", "dim", "maj", "m", "m", "maj", "maj"];
  // 和声大调和弦类型 (降6级使 IV 变成小和弦, vi° 变成减和弦)
  const harmonicMajorChordTypes = [
    "maj",
    "dim",
    "m",
    "m",
    "maj",
    "aug",
    "dim",
  ];
  // 和声小调和弦类型 (升7级使 V 变成大和弦, vii° 变成减和弦)
  const harmonicMinorChordTypes = [
    "m",
    "dim",
    "aug",
    "m",
    "maj",
    "maj",
    "dim",
  ];

  const majorDegreeNums = ["I", "ii", "iii", "IV", "V", "vi", "vii°"];
  const minorDegreeNums = ["i", "ii°", "III", "iv", "v", "VI", "VII"];
  // 和声大调音级
  const harmonicMajorDegreeNums = [
    "I",
    "ii°",
    "iii",
    "iv",
    "V",
    "VI+",
    "vii°",
  ];
  // 和声小调音级
  const harmonicMinorDegreeNums = [
    "i",
    "ii°",
    "III+",
    "iv",
    "V",
    "VI",
    "vii°",
  ];

  // 音符标准化映射
  const noteNormalize = {
    "E#": "F",
    Fb: "E",
    "B#": "C",
    Cb: "B",
  };
  function normalizeNote(n) {
    return noteNormalize[n] || n;
  }

  // 扩展音符列表，支持所有常见等音名
  const allNotesExt = [
    "C",
    "C#",
    "Db",
    "D",
    "D#",
    "Eb",
    "E",
    "E#",
    "Fb",
    "F",
    "F#",
    "Gb",
    "G",
    "G#",
    "Ab",
    "A",
    "A#",
    "Bb",
    "B",
    "B#",
    "Cb",
  ];
  const semitoneMap = {
    C: 0,
    "B#": 0,
    "C#": 1,
    Db: 1,
    D: 2,
    "D#": 3,
    Eb: 3,
    E: 4,
    Fb: 4,
    "E#": 5,
    F: 5,
    "F#": 6,
    Gb: 6,
    G: 7,
    "G#": 8,
    Ab: 8,
    A: 9,
    "A#": 10,
    Bb: 10,
    B: 11,
    Cb: 11,
  };
  const noteNormalizeFull = {
    C: "C",
    "C#": "C#",
    Db: "Db",
    D: "D",
    "D#": "D#",
    Eb: "Eb",
    E: "E",
    "E#": "E#",
    Fb: "Fb",
    F: "F",
    "F#": "F#",
    Gb: "Gb",
    G: "G",
    "G#": "G#",
    Ab: "Ab",
    A: "A",
    "A#": "A#",
    Bb: "Bb",
    B: "B",
    "B#": "B#",
    Cb: "Cb",
    // 复合名映射到标准名
    Cbm: "Cb",
    "B#m": "B#",
  };

  // 核心：将任何输入音符标准化为 0-11 索引
  function noteToSemitone(note) {
    // 去掉后缀如 'm', 'dim', '°' 等
    let clean = note
      .replace(/m$/, "")
      .replace(/dim$/, "")
      .replace(/°$/, "")
      .trim();
    const normalized = noteNormalizeFull[clean] || clean;
    if (semitoneMap[normalized] !== undefined) {
      return semitoneMap[normalized];
    }
    console.warn("Unknown note for semitone conversion:", note);
    return undefined;
  }

  function semitoneToNote(idx, preferSharps = false) {
    const preferred = preferSharps
      ? ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
      : ["C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B"];
    return preferred[idx % 12];
  }

  // 覆盖原有的 allNotes/noteToIdx/idxToNote
  let notationMode = localStorage.getItem("jazz-compass-notation") || "flats";
  const flatNoteNames = [
    "C",
    "Db",
    "D",
    "Eb",
    "E",
    "F",
    "Gb",
    "G",
    "Ab",
    "A",
    "Bb",
    "B",
  ];
  const sharpNoteNames = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
  const allNotes = flatNoteNames;
  const noteToIdx = Object.fromEntries(allNotes.map((n, i) => [n, i]));
  let idxToNote = [...flatNoteNames];

  function applyNotationToConverters() {
    idxToNote = [...(notationMode === "sharps" ? sharpNoteNames : flatNoteNames)];
    [
      typeof conv !== "undefined" ? conv : null,
      typeof brain !== "undefined" ? brain?.converter : null,
      typeof classical !== "undefined" ? classical?.converter : null,
      _multiModeChordConverter,
    ]
      .filter(Boolean)
      .forEach((converter) => {
        if (converter.idxToNote) converter.idxToNote.splice(0, converter.idxToNote.length, ...idxToNote);
      });
  }

  function rerenderActivePanel() {
    const active = document.querySelector(".feature-btn.active")?.dataset.feature;
  const runMap = { chord: "chord-run", classical: "classical-run", blues: "blues-run", lcc: "lcc-run", cst: "cst-run", other: "other-run", neo: "neo-run" };
    const button = runMap[active] && document.getElementById(runMap[active]);
    if (button) button.click();
    if (active === "circle") drawCircle(circleCurrentKey?.primary === "major" ? circleCurrentKey.major : null, circleCurrentKey?.primary === "minor" ? circleCurrentKey.minor : null);
    if (active === "ref") initRefPanel();
  }

  function setNotation(mode) {
    notationMode = mode === "sharps" ? "sharps" : "flats";
    localStorage.setItem("jazz-compass-notation", notationMode);
    applyNotationToConverters();
    document.querySelectorAll(".notation-btn").forEach((button) => {
      const active = button.dataset.notation === notationMode;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", String(active));
    });
    rerenderActivePanel();
  }

  function setTheme(mode) {
    const theme = mode === "light" ? "light" : "dark";
    const changed = document.documentElement.dataset.theme !== theme;
    document.documentElement.dataset.theme = theme;
    localStorage.setItem("jazz-compass-theme", theme);
    document.querySelectorAll(".theme-btn").forEach((button) => {
      const active = button.dataset.themeValue === theme;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", String(active));
    });
    if (changed) requestAnimationFrame(rerenderActivePanel);
  }

  // 获取音阶音符（使用半音索引，避免等音名匹配失败）
  function getScaleNotes(root, intervals) {
    const rootIdx = noteToSemitone(root);
    if (rootIdx === undefined) {
      console.error("Unknown root:", root);
      return intervals.map(() => "?");
    }
    const preferSharps = /[#♯]/.test(root);
    return intervals.map((i) => semitoneToNote((rootIdx + i) % 12, notationMode === "sharps" || preferSharps));
  }

  const axisColorMap = {
    T: {
      major: "rgba(96,180,255,0.26)",
      minor: "rgba(96,180,255,0.18)",
      highlight: "rgba(96,180,255,0.42)",
    },
    D: {
      major: "rgba(255,178,92,0.26)",
      minor: "rgba(255,178,92,0.18)",
      highlight: "rgba(255,178,92,0.42)",
    },
    S: {
      major: "rgba(140,220,140,0.26)",
      minor: "rgba(140,220,140,0.18)",
      highlight: "rgba(140,220,140,0.42)",
    },
    default: {
      major: "rgba(255,255,255,0.06)",
      minor: "rgba(255,255,255,0.03)",
      highlight: "rgba(255,255,255,0.18)",
    },
  };

  function getAxisRoot(highlightMajor, highlightMinor) {
    if (highlightMajor) return highlightMajor;
    const found = circleData.find(
      (item) =>
        item.minor === highlightMinor ||
        item.major === highlightMinor ||
        item.enharmonic === highlightMinor,
    );
    return found ? found.major : null;
  }

  function getAxisGroup(itemMajor, axisRoot) {
    if (!axisRoot) return null;
    const rootIndex = circleData.findIndex(
      (item) =>
        item.major === axisRoot ||
        item.enharmonic === axisRoot ||
        item.minor === axisRoot,
    );
    const itemIndex = circleData.findIndex(
      (item) =>
        item.major === itemMajor ||
        item.enharmonic === itemMajor ||
        item.minor === itemMajor,
    );
    if (rootIndex < 0 || itemIndex < 0) return null;
    const offset = (itemIndex - rootIndex + 12) % 12;
    if (offset % 3 === 0) return "T";
    if (offset % 3 === 1) return "D";
    return "S";
  }

  // 绘制五度圈
  function drawCircle(highlightMajor, highlightMinor) {
    const { size, ctx } = resizeCanvas();
    const cx = size / 2;
    const cy = size / 2;
    const outerR = size * 0.42;
    const innerR = size * 0.28;
    const centerR = size * 0.12;

    ctx.clearRect(0, 0, size, size);

    // 背景
    const lightTheme = document.documentElement.dataset.theme === "light";
    ctx.fillStyle = lightTheme ? "rgba(45,44,39,0.055)" : "rgba(0,0,0,0.18)";
    ctx.beginPath();
    ctx.arc(cx, cy, outerR + 20, 0, Math.PI * 2);
    ctx.fill();

    const axisRoot = getAxisRoot(highlightMajor, highlightMinor);
    circleData.forEach((item, i) => {
      const angle = (i / 12) * Math.PI * 2 - Math.PI / 2;
      const nextAngle = ((i + 1) / 12) * Math.PI * 2 - Math.PI / 2;
      const axisGroup = getAxisGroup(item.major, axisRoot);

      // 外环（大调）
      const isHighlightedOuter = highlightMajor === item.major;
      drawArcSegment(
        ctx,
        cx,
        cy,
        innerR,
        outerR,
        angle,
        nextAngle,
        item.major,
        item.sharps,
        item.flats,
        isHighlightedOuter,
        "major",
        axisGroup,
      );

      // 内环（小调）
      const isHighlightedInner = highlightMinor === item.minor;
      drawArcSegment(
        ctx,
        cx,
        cy,
        centerR,
        innerR,
        angle,
        nextAngle,
        item.minor,
        item.sharps,
        item.flats,
        isHighlightedInner,
        "minor",
        axisGroup,
      );

      // 扇区分隔线
      ctx.beginPath();
      ctx.moveTo(
        cx + Math.cos(angle) * centerR,
        cy + Math.sin(angle) * centerR,
      );
      ctx.lineTo(
        cx + Math.cos(angle) * outerR,
        cy + Math.sin(angle) * outerR,
      );
      ctx.strokeStyle = lightTheme ? "rgba(38,37,33,0.18)" : "rgba(255,255,255,0.12)";
      ctx.lineWidth = 1;
      ctx.stroke();
    });

    // 中心标签
    ctx.fillStyle = lightTheme ? "#292925" : "#f5f5f2";
    ctx.font = "bold 12px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(window.__("nav_circle"), cx, cy - 6);
    ctx.font = "9px sans-serif";
    ctx.fillStyle = lightTheme ? "rgba(41,41,37,0.58)" : "rgba(255,255,255,0.5)";
    ctx.fillText("Circle of 5ths", cx, cy + 10);
  }
  // 多调性模式相关变量
  let multiModeActive = false;
  let currentMultiMode = null;       // 当前选中的模式对象
  let currentRoot = null;            // 主音（点击五度圈后设定）

  // 辅助函数：半音差转音级索引（0-11）
  function getSemitoneDistance(fromNote, toNote) {
    const idxFrom = noteToIdx[fromNote];
    const idxTo = noteToIdx[toNote];
    return (idxTo - idxFrom + 12) % 12;
  }

  /** 在音阶顺序上取该级的三音、五音（按半音 3/4 与 6/7/8，非简单 +2/+4 音级） */
  function getScaleTriadAtDegree(intervals, degIndex) {
    const n = intervals.length;
    const root = intervals[degIndex];
    let thirdOff = null;
    let thirdDist = null;
    let fifthOff = null;
    let fifthDist = null;

    for (let step = 1; step < n; step++) {
      const off = intervals[(degIndex + step) % n];
      const d = (off - root + 12) % 12;
      if (thirdOff == null && (d === 3 || d === 4)) {
        thirdOff = off;
        thirdDist = d;
      }
    }

    if (thirdOff != null) {
      for (const want of [7, 6, 8]) {
        for (let step = 1; step < n; step++) {
          const off = intervals[(degIndex + step) % n];
          const d = (off - root + 12) % 12;
          if (d === want) {
            fifthOff = off;
            fifthDist = d;
            break;
          }
        }
        if (fifthOff != null) break;
      }
    }

    if (thirdOff == null) {
      for (let step = 1; step < n; step++) {
        const off = intervals[(degIndex + step) % n];
        const d = (off - root + 12) % 12;
        if (d === 2) {
          thirdOff = off;
          thirdDist = 2;
          break;
        }
        if (d === 5) {
          thirdOff = off;
          thirdDist = 5;
          break;
        }
      }
      if (thirdOff != null) {
        for (const want of [7, 6, 8]) {
          for (let step = 1; step < n; step++) {
            const off = intervals[(degIndex + step) % n];
            const d = (off - root + 12) % 12;
            if (d === want) {
              fifthOff = off;
              fifthDist = d;
              break;
            }
          }
          if (fifthOff != null) break;
        }
      }
    }

    return { thirdOff, fifthOff, thirdDist, fifthDist };
  }

  let _multiModeChordConverter = null;

  function getMultiModeChordConverter() {
    if (!_multiModeChordConverter) {
      _multiModeChordConverter = new EnhancedChordConverter();
    }
    return _multiModeChordConverter;
  }

  /** 从 identifyChord 的 quality 提取基础和弦类型 */
  function extractBaseChordQuality(quality) {
    if (quality == null || quality === "") return "maj";
    const q = String(quality).trim().split(/\s+/)[0];
    if (q === "maj" || q === "major" || q === "M") return "maj";
    if (q === "min" || q === "m" || q === "minor") return "min";
    if (q === "dim") return "dim";
    if (q === "aug") return "aug";
    if (q === "sus2") return "sus2";
    if (q === "sus4") return "sus4";
    return "unknown";
  }
function extractBaseChordQuality(quality) {
    if (!quality) return "maj";
    const q = String(quality).trim().toLowerCase();
    
    // 标准类型列表
    const standardTypes = ["maj", "min", "dim", "aug", "sus2", "sus4", "5"];
    
    for (const type of standardTypes) {
        if (q === type || q.startsWith(type + " ") || q.startsWith(type + "\n")) {
            return type;
        }
    }
    
    // 处理空字符串（大三和弦）
    if (q === "" || q === "maj") return "maj";
    if (q === "m" || q === "min") return "min";
    
    return "unknown";
}
  /**
   * 音阶级数 → 和弦：取调内三音后用 EnhancedChordConverter.identifyChord 识别
   * （与 jazz_compass.js _ensureNotesAndRoot 音名列表逻辑一致）
   */
function buildTriadChordAtDegree(root, intervals, degIndex, converter, preferredType = null) {
    const conv = converter || getMultiModeChordConverter();
    const rootIdx = conv.noteToIdx[root];
    const rootOff = intervals[degIndex];
    const rootNote = conv.idxToNote[(rootIdx + rootOff) % 12];

    // 获取三音和五音（按音阶级进，隔一个取一个）
    const n = intervals.length;
    let thirdOff = null;
    let fifthOff = null;
    
    // 找到第三个音（跳过1个）
    let thirdIdx = (degIndex + 2) % n;
    thirdOff = intervals[thirdIdx];
    
    // 找到第五个音（跳过3个，即 +4 索引）
    let fifthIdx = (degIndex + 4) % n;
    fifthOff = intervals[fifthIdx];
    
    // 构建音符列表
    const noteNames = [rootNote];
    if (thirdOff != null) {
        noteNames.push(conv.idxToNote[(rootIdx + thirdOff) % 12]);
    }
    if (fifthOff != null) {
        noteNames.push(conv.idxToNote[(rootIdx + fifthOff) % 12]);
    }
    
    // 使用 EnhancedChordConverter 识别和弦
    let chordLabel = rootNote;
    let chordType = "unknown";
    let notes = noteNames.join(", ");
    let finalNotes = noteNames;

    // 优先：基于调内音在整调上尝试匹配标准三和弦（不再严格限制为同一格子）
    function findTriadFromScaleNotes(scaleRoot, chordRoot, scaleIntervals, conv, preferred) {
        const scaleRootIdx = conv.noteToIdx[scaleRoot];
        const scaleSet = new Set(
            scaleIntervals.map(i => (scaleRootIdx + i) % 12)
        );
        const rootIdxLocal = conv.noteToIdx[chordRoot];

        const triadSpecs = [
            { type: 'maj', ints: [4,7] },
            { type: 'min', ints: [3,7] },
            { type: 'dim', ints: [3,6] },
            { type: 'aug', ints: [4,8] },
            { type: 'sus2', ints: [2,7] },
            { type: 'sus4', ints: [5,7] },
        ];

        // 按优先级分组： maj/min > dim/aug > sus2/sus4
        const priorityGroups = [
            ['maj','min'],
            ['dim','aug'],
            ['sus2','sus4']
        ];

        // 先检测完全匹配（三音都在调内）
        const matches = [];
        for (const spec of triadSpecs) {
            const ok = spec.ints.every(i => scaleSet.has((rootIdxLocal + i) % 12));
            if (ok) {
                const notesArr = [
                    conv.idxToNote[rootIdxLocal % 12],
                    conv.idxToNote[(rootIdxLocal + spec.ints[0]) % 12],
                    conv.idxToNote[(rootIdxLocal + spec.ints[1]) % 12]
                ];
                matches.push({ type: spec.type, notes: notesArr });
            }
        }

        if (matches.length) {
            // 如果有优先类型且能找到，直接返回
            if (preferred && (preferred === 'maj' || preferred === 'min')) {
                const found = matches.find(m => m.type === preferred);
                if (found) return found;
            }
            
            // 选择最高优先级匹配
            for (const group of priorityGroups) {
                const found = matches.find(m => group.includes(m.type));
                if (found) return found;
            }
            return matches[0];
        }

        // 如果没有完全三音匹配，尝试弱匹配（任意两个音在调内）
        const weakMatches = [];
        for (const spec of triadSpecs) {
            const have = spec.ints.filter(i => scaleSet.has((rootIdxLocal + i) % 12)).length;
            if (have >= 2) {
                const notesArr = [
                    conv.idxToNote[rootIdxLocal % 12],
                    conv.idxToNote[(rootIdxLocal + spec.ints[0]) % 12],
                    conv.idxToNote[(rootIdxLocal + spec.ints[1]) % 12]
                ];
                weakMatches.push({ type: spec.type, notes: notesArr, have });
            }
        }
        if (weakMatches.length) {
            // 按 have(desc) + priority
            weakMatches.sort((a,b) => b.have - a.have);
            
            // 如果有优先类型且能找到，直接返回
            if (preferred && (preferred === 'maj' || preferred === 'min')) {
                const found = weakMatches.find(m => m.type === preferred);
                if (found) return found;
            }
            
            for (const group of priorityGroups) {
                const found = weakMatches.find(m => group.includes(m.type));
                if (found) return found;
            }
            return weakMatches[0];
        }

        return null;
    }

    // 先尝试基于整调的triad匹配
    try {
        const scaleBased = findTriadFromScaleNotes(root, rootNote, intervals, conv, preferredType);
      if (scaleBased) {
        chordType = scaleBased.type === 'min' ? 'min' : (scaleBased.type === 'maj' ? 'maj' : scaleBased.type);
        chordLabel = formatChordName(rootNote, chordType);
        finalNotes = scaleBased.notes;
        notes = finalNotes.join(', ');
        return {
          dist: rootOff,
          degreeLabel: formatRomanDegreeLabel(degIndex, chordType),
          chordLabel: chordLabel,
          notes: notes,
          chordType: chordType,
          notesArray: finalNotes
        };
      }
    } catch (e) {
      console.warn('scale-based triad detection failed', e);
    }

    // 回退到原有的识别逻辑
    if (noteNames.length >= 2) {
      try {
        // 直接使用 identifyChord 方法
        const identified = conv.identifyChord(
          noteNames.map(n => conv.noteToIdx[n])
        );

        if (identified && identified.chord) {
          chordLabel = identified.chord;
          // 提取基础和弦类型
          const quality = identified.quality || "";
          const baseQuality = quality.split(/\s+/)[0];

          // 确定和弦类型
          if (baseQuality === "" || baseQuality === "maj") {
            chordType = "maj";
          } else if (baseQuality === "min" || baseQuality === "m") {
            chordType = "min";
          } else if (baseQuality === "dim") {
            chordType = "dim";
          } else if (baseQuality === "aug") {
            chordType = "aug";
          } else if (baseQuality === "sus2") {
            chordType = "sus2";
          } else if (baseQuality === "sus4") {
            chordType = "sus4";
          } else {
            chordType = baseQuality;
          }

          // 获取识别出的音符
          if (identified.quality && identified.quality !== quality) {
            // 尝试解析出音符
            const parsedNotes = conv._ensureNotesAndRoot(chordLabel);
            if (parsedNotes && parsedNotes.length) {
              finalNotes = parsedNotes;
              notes = finalNotes.join(", ");
            }
          }
        }
      } catch (e) {
        console.warn(`识别和弦失败 ${rootNote}${rootOff}:`, e);
        // 保持原始标签
      }
    }
    
    return {
        dist: rootOff,
        degreeLabel: formatRomanDegreeLabel(degIndex, chordType),
        chordLabel: chordLabel,
        notes: notes,
        chordType: chordType,
        notesArray: finalNotes
    };
}

// 新增：强制匹配最接近的标准三和弦
function forceToStandardTriad(notes, converter) {
    if (!notes || notes.length < 3) return null;
    
    const root = notes[0];
    const rootIdx = converter.noteToIdx[root];
    
    // 计算相对于根音的音程
    const intervals = notes.map(n => {
        const idx = converter.noteToIdx[n];
        return (idx - rootIdx + 12) % 12;
    }).sort((a, b) => a - b);
    
    // 标准三和弦的音程模式
    const standardTriads = [
        { intervals: [0, 4, 7], type: "maj", chord: root, label: root },
        { intervals: [0, 3, 7], type: "min", chord: `${root}m`, label: `${root}m` },
        { intervals: [0, 4, 8], type: "aug", chord: `${root}+`, label: `${root}+` },
        { intervals: [0, 3, 6], type: "dim", chord: `${root}°`, label: `${root}°` },
        { intervals: [0, 2, 7], type: "sus2", chord: `${root}sus2`, label: `${root}sus2` },
        { intervals: [0, 5, 7], type: "sus4", chord: `${root}sus4`, label: `${root}sus4` },
    ];
    
    // 找匹配度最高的
    let bestMatch = null;
    let bestScore = -1;
    
    for (const triad of standardTriads) {
        let score = 0;
        for (const interval of triad.intervals) {
            if (intervals.includes(interval)) score++;
        }
        // 也检查是否有冲突音（不应该有的音）
        for (const interval of intervals) {
            if (!triad.intervals.includes(interval) && interval !== 0) {
                score -= 0.5;
            }
        }
        if (score > bestScore) {
            bestScore = score;
            bestMatch = triad;
        }
    }
    
    if (bestMatch && bestScore >= 2) {
        // 构建标准音符
        const standardNotes = bestMatch.intervals.map(i => 
            converter.idxToNote[(rootIdx + i) % 12]
        );
        return {
            chord: bestMatch.chord,
            chordType: bestMatch.type,
            notes: standardNotes
        };
    }
    
    return null;
}

  function formatChordName(rootNote, chordType) {
    if (chordType === "min") return `${rootNote}m`;
    if (chordType === "dim") return `${rootNote}°`;
    if (chordType === "aug") return `${rootNote}+`;
    if (chordType === "sus2") return `${rootNote}sus2`;
    if (chordType === "sus4") return `${rootNote}sus4`;
    return rootNote;
  }

  function getChordTypeForNote(root, targetNote, intervals) {
    const dist = getSemitoneDistance(root, targetNote);
    const degree = intervals.indexOf(dist);
    if (degree === -1) return null;
    return buildTriadChordAtDegree(root, intervals, degree).chordType;
  }

  // 更新五度圈显示（多调性模式）
  function updateCircleMultiMode() {
    if (!multiModeActive || !currentMultiMode) {
      // 恢复原始五度圈
      if (circleCurrentKey) {
        drawCircle(circleCurrentKey.major, circleCurrentKey.minor);
        renderKeyTable(circleCurrentKey.major, circleCurrentKey.minor, circleCurrentKey.primary);
      } else {
        drawCircle(null, null);
        const tableContainer = document.getElementById("circle-table-container");
        if (tableContainer) tableContainer.innerHTML = "";
      }
      return;
    }

    const includeSet = new Set(currentMultiMode.includeNoteIdx);
    const root = currentRoot;

    drawMultiCircle(root, includeSet, currentMultiMode);

    const tableContainer = document.getElementById("circle-table-container");
    if (root && noteToIdx[root] != null) {
      renderMultiModeTable(root, currentMultiMode);
    } else if (tableContainer) {
      tableContainer.innerHTML = "";
    }
  }

  // 解析内圈功能组标签片段，如 "3D(6s)" → [{text:"3D"}, {text:"6s", inParens:true}]
  function parseFuncRingLabelSegments(label) {
    const m = String(label).match(/^([^(]+)(?:\(([^)]+)\))?$/);
    if (!m) return [{ text: label, inParens: false }];
    const segments = [{ text: m[1], inParens: false }];
    if (m[2]) segments.push({ text: m[2], inParens: true });
    return segments;
  }

  // 与内圈主音环一致：按扇区标签定位功能替代（不用 funcGroup 半音索引）
  function findSectorForFuncReplaceGroup(innerLabels, replaceGroup) {
    if (!replaceGroup || !innerLabels?.length) return null;
    for (let i = 0; i < innerLabels.length; i++) {
      const label = innerLabels[i];
      if (!label) continue;
      const hit = parseFuncRingLabelSegments(label).some((s) => s.text === replaceGroup);
      if (hit) return i;
    }
    return null;
  }

  // 主音环：沿五度圈顺时针 12 格（与画布内圈一致）
  const FUNC_RING_BASE = [
    { main: "t" },
    { main: "d" },
    { main: "S" },
    { main: "T" },
    { main: "D" },
    { main: "DD" },
    { main: "3D", overlap: "6s" },
    { main: "4D", overlap: "5s" },
    { main: "5D", overlap: "4s" },
    { main: "6D", overlap: "3s" },
    { main: "ss" },
    { main: "s" },
  ];

  function getFuncGroupIndexForMode(key, mode) {
    if (!funcGroupData || !mode) return null;
    const idx = funcGroupData[key];
    if (idx == null) return null;
    if (!Array.isArray(idx)) return idx;
    if (key === "tIdx") return mode.tonicGroup === "t" ? idx[0] : idx[1] ?? idx[0];
    if (key === "TIdx") return mode.tonicGroup === "T" ? idx[0] : idx[1] ?? idx[0];
    return idx[0];
  }

  function findCircleSectorForDist(root, dist) {
    for (let i = 0; i < circleData.length; i++) {
      if (getSemitoneDistance(root, circleData[i].major) === dist) return i;
    }
    return 0;
  }

  function formatFuncRingEntry(entry) {
    return entry.overlap ? `${entry.main}(${entry.overlap})` : entry.main;
  }

  /** 内圈功能标签：从 t/T 锚点起沿五度圈顺转一圈 */
  // 在 script.js 中，找到 buildInnerFuncRingLabels 函数并替换

  function buildInnerFuncRingLabels(root, mode) {
    const startChar = mode.tonicGroup === "t" ? "t" : "T";
    const startIdx = FUNC_RING_BASE.findIndex((e) => e.main === startChar);
    const ringSpec = startIdx <= 0
      ? FUNC_RING_BASE
      : [...FUNC_RING_BASE.slice(startIdx), ...FUNC_RING_BASE.slice(0, startIdx)];

    const anchorKey = mode.tonicGroup === "t" ? "tIdx" : "TIdx";
    const anchorDist = getFuncGroupIndexForMode(anchorKey, mode);
    const anchorSector = anchorDist != null ? findCircleSectorForDist(root, anchorDist) : 0;

    // 获取各扇区对应的和弦类型
    const converter = getMultiModeChordConverter();
    const rootIdx = converter.noteToIdx[root];
    const intervals = mode.includeNoteIdx || [];
    const degreePreferredType = buildDegreePreferredTypeMap(mode);

    // 构建每个扇区（距离）对应的和弦类型
    const chordTypeByDist = {};
    const chordLabelByDist = {};
    for (let i = 0; i < intervals.length; i++) {
      const dist = intervals[i];
      const preferred = degreePreferredType[i];
      const triad = buildTriadChordAtDegree(root, intervals, i, converter, preferred);
      chordTypeByDist[dist] = triad.chordType;
      chordLabelByDist[dist] = triad.chordLabel;
    }

    const perSector = Array(12).fill("");
    for (let step = 0; step < 12; step++) {
      const sector = (anchorSector + step) % 12;
      let label = formatFuncRingEntry(ringSpec[step]);

      // 获取该扇区对应的音符和和弦类型
      const sectorNote = circleData[sector].major;
      const dist = getSemitoneDistance(root, sectorNote);
      const chordType = chordTypeByDist[dist];
      const chordLabel = chordLabelByDist[dist];
      console.log(`Sector ${sector}: ${sectorNote} (dist ${dist}) -> ${label}, chord: ${chordLabel} (${chordType})`);
      // 根据和弦类型调整功能标签的大小写
      label = adjustFuncLabelByChordType(label, chordType);
      // console.log(`Sector ${sector}: ${sectorNote} (dist ${dist}) -> ${label}, chord: ${chordLabel} (${chordType})`);
      perSector[sector] = label;
    }
    return perSector;
  }

  // 新增辅助函数：根据和弦类型调整功能标签
  function adjustFuncLabelByChordType(label, chordType) {
      if (!label || !chordType) return label;
      
      const upperToLowerMap = { 'T': 't', 'D': 'd', 'S': 's', 'DD': 'dd' };
      const lowerToUpperMap = { 't': 'T', 'd': 'D', 's': 'S', 'dd': 'DD' };
      
      let adjusted = label;
      
      // 只有 min 转换小写，maj 转换大写
      // dim、aug 保持原样
      if (chordType === 'min') {
          for (const [upper, lower] of Object.entries(upperToLowerMap)) {
              adjusted = adjusted.replace(new RegExp(upper, 'g'), lower);
          }
      } else if (chordType === 'maj') {
          for (const [lower, upper] of Object.entries(lowerToUpperMap)) {
              adjusted = adjusted.replace(new RegExp(lower, 'g'), upper);
          }
      }
      // dim、aug、sus2、sus4 → 不转换
      
      return adjusted;
  }

  function buildFuncNameToSectorMap(innerLabels) {
    const map = {};
    for (let i = 0; i < innerLabels.length; i++) {
      const label = innerLabels[i];
      if (!label) continue;
      for (const seg of parseFuncRingLabelSegments(label)) {
        map[seg.text] = i;
      }
    }
    return map;
  }

  // 替换 drawFuncRingLabel 函数

function drawFuncRingLabel(ctx, centerX, centerY, label, replaceGroup, chordType = null) {
    const segments = parseFuncRingLabelSegments(label);
    const normalColor = "rgba(200,220,255,0.85)";
    const replaceColor = "#ffb74d";
    const replaceGlow = "rgba(255, 183, 77, 0.95)";
    const fontNormal = "9px sans-serif";
    const fontReplace = "bold 10px sans-serif";
    const fontParen = "9px sans-serif";

    // 只有 min 强调括号内，其他情况（maj/dim/aug/null）都强调括号外
    let emphasizeOuter = true;
    let emphasizeInner = false;
    
    if (chordType === 'min') {
        emphasizeOuter = false;
        emphasizeInner = true;
    }
    // dim、aug、maj、null → 保持 emphasizeOuter = true

    const pieces = [];
    let totalW = 0;
    
    for (const seg of segments) {
        const isRep = replaceGroup && seg.text === replaceGroup;
        
        let shouldEmphasize = false;
        if (seg.inParens) {
            shouldEmphasize = emphasizeInner;
        } else {
            shouldEmphasize = emphasizeOuter;
        }
        
        if (isRep) {
            shouldEmphasize = true;
        }
        
        const font = shouldEmphasize ? fontReplace : fontNormal;
        if (seg.inParens) {
            ctx.font = fontParen;
            const wOpen = ctx.measureText("(").width;
            ctx.font = font;
            const wInner = ctx.measureText(seg.text).width;
            ctx.font = fontParen;
            const wClose = ctx.measureText(")").width;
            pieces.push({ text: "(", font: fontParen, isRep: false, shouldEmphasize: false, w: wOpen });
            pieces.push({ text: seg.text, font, isRep, shouldEmphasize, w: wInner });
            pieces.push({ text: ")", font: fontParen, isRep: false, shouldEmphasize: false, w: wClose });
            totalW += wOpen + wInner + wClose;
        } else {
            ctx.font = font;
            const w = ctx.measureText(seg.text).width;
            pieces.push({ text: seg.text, font, isRep, shouldEmphasize, w });
            totalW += w;
        }
    }

    let x = centerX - totalW / 2;
    const prevAlign = ctx.textAlign;
    const prevBaseline = ctx.textBaseline;
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";

    for (const p of pieces) {
        ctx.font = p.font;
        ctx.shadowBlur = 0;
        
        if (p.isRep) {
            ctx.shadowColor = replaceGlow;
            ctx.shadowBlur = 12;
            ctx.fillStyle = replaceColor;
        } else if (p.shouldEmphasize) {
            ctx.fillStyle = "#fff";
            ctx.shadowBlur = 6;
            ctx.shadowColor = "rgba(0, 181, 173, 0.5)";
        } else {
            ctx.fillStyle = normalColor;
        }
        ctx.fillText(p.text, x, centerY);
        x += p.w;
    }

    ctx.shadowBlur = 0;
    ctx.textAlign = prevAlign;
    ctx.textBaseline = prevBaseline;
}

  // 绘制多调性五度圈
  function drawMultiCircle(root, includeSet, mode) {
    const { size, ctx } = resizeCanvas();
    const cx = size / 2;
    const cy = size / 2;
    const outerR = size * 0.42;
    const innerR = size * 0.28;
    const centerR = size * 0.12;

    ctx.clearRect(0, 0, size, size);
    ctx.fillStyle = "rgba(0,0,0,0.15)";
    ctx.beginPath();
    ctx.arc(cx, cy, outerR + 20, 0, Math.PI * 2);
    ctx.fill();

    const hasRoot = root != null && noteToIdx[root] != null;

    // 准备每个扇区的和弦标签
    const degreePreferredType = buildDegreePreferredTypeMap(mode);
    const chordLabels = [];
    for (let i = 0; i < circleData.length; i++) {
      const sectorNote = circleData[i].major; // 扇区代表的音（外环）
      const dist = hasRoot ? getSemitoneDistance(root, sectorNote) : -1;
      let label = sectorNote;
      let isInside = hasRoot && includeSet.has(dist);
      let chordType = null;
      if (isInside) {
        const distIdx = getSemitoneDistance(root, sectorNote);
        const deg = mode.includeNoteIdx.indexOf(distIdx);
        if (deg >= 0) {
          const preferred = degreePreferredType[deg];
          const triad = buildTriadChordAtDegree(root, mode.includeNoteIdx, deg, null, preferred);
          chordType = triad.chordType;
          label = triad.chordLabel;
        }
      }
      chordLabels.push({ label, isInside, chordType });
    }

    const categoryColors = {
      // 非特征类使用更浅的颜色
      tonic: "#e1f5fe",
      tonicChar: "#e1f5fe",
      // 特性组和对照组使用明显不同且醒目的颜色
      featureChar: "#6a71cb", // 更深的天蓝
      contrastChar: "#f17f7f", // 更深的橙红
      // 保留高低极显著色
      // highPole: "#ff80b3",
      // lowPole: "#7c4dff",
    };

    function hexToRgba(hex, alpha) {
      const clean = hex.replace("#", "");
      const r = parseInt(clean.slice(0, 2), 16);
      const g = parseInt(clean.slice(2, 4), 16);
      const b = parseInt(clean.slice(4, 6), 16);
      return `rgba(${r},${g},${b},${alpha})`;
    }

    function getCircleNoteCategory(dist) {
      if (!mode) return null;
      if (dist === mode.tonicGroupNoteIdx) return "tonic";
      if (dist === mode.featureGroupCharNoteIdx) return "featureChar";
      if (dist === mode.tonicGroupCharNoteIdx) return "tonicChar";
      if (dist === mode.contrastGroupCharNoteIdx) return "contrastChar";
      // if (dist === mode.highPoleNoteIdx) return "highPole";
      // if (dist === mode.lowPoleNoteIdx) return "lowPole";
      return null;
    }

    const innerFuncLabels = hasRoot ? buildInnerFuncRingLabels(root, mode) : Array(12).fill("");

    const funcReplaceSector = hasRoot && mode?.funcReplaceGroup
      ? findSectorForFuncReplaceGroup(innerFuncLabels, mode.funcReplaceGroup)
      : null;
    const funcReplaceColor = "#ffb74d";
    const funcReplaceGlow = "rgba(255, 183, 77, 0.95)";

    // 绘制扇区
    for (let i = 0; i < circleData.length; i++) {
      const angle = (i / 12) * Math.PI * 2 - Math.PI / 2;
      const nextAngle = ((i + 1) / 12) * Math.PI * 2 - Math.PI / 2;
      const { label, isInside } = chordLabels[i];
      const sectorNote = circleData[i].major;
      const dist = hasRoot ? getSemitoneDistance(root, sectorNote) : -1;
      const noteCategory = hasRoot ? getCircleNoteCategory(dist) : null;
      const isFuncReplace = funcReplaceSector != null && i === funcReplaceSector;

      // 填充（调内和弦高亮背景 + 特殊类别底色）
      ctx.beginPath();
      ctx.arc(cx, cy, outerR, angle, nextAngle);
      ctx.arc(cx, cy, innerR, nextAngle, angle, true);
      ctx.closePath();
      if (noteCategory/* && noteCategory !== "highPole" && noteCategory !== "lowPole"*/) {
        ctx.fillStyle = hexToRgba(categoryColors[noteCategory], 0.18);
      } else if (isInside) {
        ctx.fillStyle = "rgba(139,200,231,0.3)";
      } else {
        ctx.fillStyle = "rgba(255,255,255,0.03)";
      }
      ctx.fill();

      // 不在此处绘制边框，避免邻接扇区重复描边导致叠加。边框将在全部扇区填充后统一绘制。

      // 标签
      const midAngle = (angle + nextAngle) / 2;
      const midR = (innerR + outerR) / 2;
      const textX = cx + Math.cos(midAngle) * midR;
      const textY = cy + Math.sin(midAngle) * midR;

      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.shadowBlur = 0;
      ctx.fillStyle = isInside ? "#fff" : "rgba(255,255,255,0.8)";
      ctx.font = isInside ? "bold 13px sans-serif" : "12px sans-serif";
      /*
      if (isFuncReplace) {
        ctx.shadowColor = funcReplaceGlow;
        ctx.shadowBlur = 12;
        // ctx.fillStyle = funcReplaceColor;
        ctx.font = "bold 14px sans-serif";
      } else {
      }
        */
      ctx.fillText(label, textX, textY);
      ctx.shadowBlur = 0;
    }

    // 绘制基础分割线和环边界，避免重复扇区描边重叠
    ctx.beginPath();
    for (let i = 0; i < 12; i++) {
      const edgeAngle = (i / 12) * Math.PI * 2 - Math.PI / 2;
      const x1 = cx + Math.cos(edgeAngle) * innerR;
      const y1 = cy + Math.sin(edgeAngle) * innerR;
      const x2 = cx + Math.cos(edgeAngle) * outerR;
      const y2 = cy + Math.sin(edgeAngle) * outerR;
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
    }
    ctx.strokeStyle = "rgba(255,255,255,0.12)";
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(cx, cy, outerR, 0, Math.PI * 2);
    ctx.stroke();

    // 绘制高低极与主音特殊边界
    for (let i = 0; i < circleData.length; i++) {
      const sectorNote = circleData[i].major;
      const dist = hasRoot ? getSemitoneDistance(root, sectorNote) : -1;
      const noteCategory = hasRoot ? getCircleNoteCategory(dist) : null;
      if (!noteCategory || noteCategory === "featureChar" || noteCategory === "contrastChar" || noteCategory === "tonicChar") continue;

      const angle = (i / 12) * Math.PI * 2 - Math.PI / 2;
      const nextAngle = ((i + 1) / 12) * Math.PI * 2 - Math.PI / 2;
      ctx.beginPath();
      ctx.arc(cx, cy, outerR, angle, nextAngle);
      ctx.arc(cx, cy, innerR, nextAngle, angle, true);
      ctx.closePath();
      if (noteCategory === "tonic") {
        ctx.strokeStyle = "rgba(255, 255, 255, 0.95)";
        ctx.lineWidth = 3;
      } else {
        ctx.strokeStyle = hexToRgba(categoryColors[noteCategory], 0.95);
        ctx.lineWidth = 3;
      }
      ctx.stroke();
    }

    // 在五度圈上方绘制图例（圆点染色 + 音名）
    (function drawLegend() {
      const legendItems = [
        { key: 'tonic', label: '主音', idxKey: 'tonicGroupNoteIdx' },
        { key: 'tonicChar', label: '主组特征音', idxKey: 'tonicGroupCharNoteIdx' },
        { key: 'featureChar', label: '特性组特征音', idxKey: 'featureGroupCharNoteIdx' },
        { key: 'contrastChar', label: '对照组特性音', idxKey: 'contrastGroupCharNoteIdx' }
      ];
      const itemW = 120;
      const totalW = legendItems.length * itemW;
      let startX = cx - totalW / 2;
      const y = cy - outerR - 18;
      ctx.font = "12px sans-serif";
      ctx.textAlign = "left";
      ctx.textBaseline = "middle";

      // 先过滤出有效项（必须有 root 且 mode 对应 idx 为 number）
      if (!(root in noteToIdx) || typeof noteToIdx[root] !== 'number') return;
      const rootIdx = noteToIdx[root];
      const validItems = legendItems.filter(it => typeof mode[it.idxKey] === 'number');
      if (!validItems.length) return; // 无有效项则不绘制图例

      for (let i = 0; i < validItems.length; i++) {
        const it = validItems[i];
        const x = startX + i * itemW;
        const distIdx = mode[it.idxKey];
        const noteIdx = (rootIdx + distIdx + 12) % 12;
        const noteName = idxToNote[noteIdx] || '-';

        // 圆点
        ctx.beginPath();
        ctx.arc(x + 6, y, 6, 0, Math.PI * 2);
        ctx.fillStyle = hexToRgba(categoryColors[it.key], 1);
        ctx.fill();
        // 文本
        ctx.fillStyle = "#fff";
        ctx.fillText(` ${it.label}: ${noteName}`, x + 18, y);
      }
    })();

    // 中心标签（显示模式名称）
    ctx.fillStyle = "#fff";
    ctx.font = "bold 10px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(mode.modeName || "多调性", cx, cy - 4);
    ctx.font = "8px sans-serif";
    ctx.fillStyle = "rgba(255,255,255,0.6)";
    ctx.fillText(`张力:${mode.tensionLevel} 温度:${mode.spaceTemp}`, cx, cy + 12);

    // 内圈功能组标注（需已选主音）
    if (!hasRoot) {
      ctx.beginPath();
      ctx.arc(cx, cy, innerR, 0, Math.PI * 2);
      ctx.strokeStyle = "rgba(255,255,255,0.15)";
      ctx.lineWidth = 1;
      ctx.stroke();
      return;
    }

    const innerLabelR = (centerR + innerR) / 2;
    const replaceGroup = mode.funcReplaceGroup || null;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    for (let i = 0; i < circleData.length; i++) {
      const label = innerFuncLabels[i];
      if (!label) continue;
      const angle = (i / 12) * Math.PI * 2 - Math.PI / 2;
      const nextAngle = ((i + 1) / 12) * Math.PI * 2 - Math.PI / 2;
      const midAngle = (angle + nextAngle) / 2;
      const textX = cx + Math.cos(midAngle) * innerLabelR;
      const textY = cy + Math.sin(midAngle) * innerLabelR;
      // 修改为：
      const sectorNote = circleData[i].major;
      const dist = getSemitoneDistance(root, sectorNote);
      let chordTypeForLabel = null;
      if (hasRoot) {
        const chordTypeByDist = {}; // 需要提前构建
        // 或者从已有的 chordLabels 中获取
        const chordData = chordLabels[i];
        if (chordData && chordData.chordType) {
          chordTypeForLabel = chordData.chordType;
        }
      }
      drawFuncRingLabel(ctx, textX, textY, label, replaceGroup, chordTypeForLabel);
    }

    ctx.beginPath();
    ctx.arc(cx, cy, innerR, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(255,255,255,0.15)";
    ctx.lineWidth = 1;
    ctx.stroke();
  }

  function escapeMultiModeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

function formatRomanDegreeLabel(degIndex, chordType) {
    const romanUpper = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];
    const romanLower = ["i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x", "xi", "xii"];
    const upper = romanUpper[degIndex] || `${degIndex + 1}`;
    const lower = romanLower[degIndex] || `${degIndex + 1}`;
    
    switch (chordType) {
        case "min":
            return lower;
        case "dim":
            return `${lower}°`;
        case "aug":
            return `${upper}+`;
        case "sus2":
            return `${upper}sus2`;
        case "sus4":
            return `${upper}sus4`;
        case "maj":
            return upper;
        default:
            return `${upper}?`;
    }
}

  function buildModeScaleChordData(root, mode) {
    // 默认使用 mode 中定义的音级（多数模式在 modes.json 中已预设）
    let intervals = Array.isArray(mode.includeNoteIdx) ? mode.includeNoteIdx : [];

    // 如果这是小调家族且用户选择了和声小调开关，则使用全局的和声小调音级
    if (mode && mode.tonicGroup === "t" && minorMode === "harmonic") {
      intervals = harmonicMinorIntervals;
    }

    const converter = getMultiModeChordConverter();
    const degreePreferredType = buildDegreePreferredTypeMap(mode);
    
    // 生成行数据，考虑功能序列的优先类型
    const rows = intervals.map((_, i) => {
      const preferred = degreePreferredType[i];
      return buildTriadChordAtDegree(root, intervals, i, converter, preferred);
    });
    const chordTypes = rows.map((r) => r.chordType);
    return { intervals, rootIdx: noteToIdx[root], chordTypes, rows };
  }

  function getDesiredChordQualityFromFuncName(funcName) {
    if (!funcName) return null;
    const letters = String(funcName).replace(/[^A-Za-z]/g, "");
    if (!letters) return null;
    const hasLower = /[a-z]/.test(letters);
    const hasUpper = /[A-Z]/.test(letters);
    if (hasLower && !hasUpper) return "min";
    if (hasUpper && !hasLower) return "maj";
    return null;
  }

  function buildDegreePreferredTypeMap(mode) {
    const degreePreferredType = {};
    const funcSeq = Array.isArray(mode.fullFuncSeq) ? mode.fullFuncSeq : [];
    
    funcSeq.forEach(fn => {
      const desiredQuality = getDesiredChordQualityFromFuncName(fn);
      const baseFunc = fn.replace(/\([^)]*\)/g, '').toLowerCase();
      const funcToDegreeMap = {
        't': 0, 'T': 0,
        'd': 4, 'D': 4,
        's': 3, 'S': 3,
        'dd': 1, 'DD': 1,
        'ss': 6,
        '3d': 2, '3D': 2,
        '4d': 5, '4D': 5,
        '5d': 1, '5D': 1,
        '6d': 3, '6D': 3,
      };
      const degIndex = funcToDegreeMap[baseFunc];
      if (degIndex !== undefined && desiredQuality) {
        degreePreferredType[degIndex] = desiredQuality;
      }
    });
    
    return degreePreferredType;
  }

  function applyFuncNameCase(funcName, desiredQuality) {
    if (!funcName || !desiredQuality) return funcName;
    return String(funcName).replace(/[A-Za-z]+/g, (match) =>
      desiredQuality === "maj" ? match.toUpperCase() : match.toLowerCase(),
    );
  }

  function buildTriadChordAtDegreeWithQuality(root, intervals, degIndex, desiredQuality, converter) {
    const triad = buildTriadChordAtDegree(root, intervals, degIndex, converter);
    if (!desiredQuality || (desiredQuality !== "maj" && desiredQuality !== "min")) {
      return triad;
    }

    const conv = converter || getMultiModeChordConverter();
    const rootIdx = conv.noteToIdx[root];
    const rootOff = intervals[degIndex];
    const rootNote = conv.idxToNote[(rootIdx + rootOff) % 12];
    const scaleSet = new Set(intervals.map((off) => (rootIdx + off) % 12));

    const qualityIntervals = desiredQuality === "maj" ? [4, 7] : [3, 7];
    const candidateNotes = qualityIntervals.map((interval) =>
      conv.idxToNote[(rootIdx + rootOff + interval) % 12],
    );
    const candidateIdxs = qualityIntervals.map((interval) =>
      (rootIdx + rootOff + interval) % 12,
    );

    const validCandidate = candidateIdxs.every((idx) => scaleSet.has(idx));
    if (validCandidate) {
      const notes = [rootNote, ...candidateNotes];
      return {
        dist: rootOff,
        degreeLabel: formatRomanDegreeLabel(degIndex, desiredQuality),
        chordLabel: formatChordName(rootNote, desiredQuality),
        notes: notes.join(", "),
        chordType: desiredQuality,
        notesArray: notes,
      };
    }

    return triad;
  }

  /** 按五度圈内圈功能名 → 扇区 → 调内和弦（与画布一致，如 T–S–D–T → C–F–G–C） */
function resolveFuncGroupChord(funcName, root, mode, scaleData, innerLabels) {
    // 1. 解析功能名，获取需要匹配的主功能
    let targetFunc = funcName;
    
    // 获取所有调内和弦的音级映射
    const degreeMap = {};
    scaleData.rows.forEach((row, idx) => {
        degreeMap[row.degreeLabel] = row;
        degreeMap[idx] = row;
        // 也按音级索引映射
        degreeMap[`deg${idx}`] = row;
    });
    
    // 标准功能到音级的映射（音级索引）
    const funcToDegreeIndex = {
        't': 0,   // i 级
        'T': 0,   // I 级
        'd': 4,   // v 级
        'D': 4,   // V 级
        's': 3,   // iv 级
        'S': 3,   // IV 级
        'dd': 1,  // ii 级
        'DD': 1,  // II 级
        'ss': 6,  // bVII 级 / VII 级
        '3D': 2,  // III 级
        '4D': 5,  // VI 级？根据五度圈位置调整
        '5D': 1,  // bII 级
        '6D': 3,  // bIII 级
    };
    
    // 获取原始功能名（去掉大小写和括号）
    let baseFunc = funcName.replace(/\([^)]*\)/g, '').toLowerCase();
    if (baseFunc === 't') baseFunc = 't';
    if (baseFunc === 'd') baseFunc = 'd';
    if (baseFunc === 's') baseFunc = 's';
    if (baseFunc === 'dd') baseFunc = 'dd';
    if (baseFunc === 'ss') baseFunc = 'ss';
    
    // 处理数字前缀功能如 "3D", "6D"
    const numberedMatch = baseFunc.match(/^(\d+)([A-Za-z]+)$/);
    let numberedPrefix = null;
    let numberedMain = null;
    if (numberedMatch) {
        numberedPrefix = parseInt(numberedMatch[1]);
        numberedMain = numberedMatch[2].toLowerCase();
        baseFunc = numberedMain;
    }
    
    // 获取该功能对应的音级索引
    let targetDegreeIndex = funcToDegreeIndex[baseFunc];
    if (targetDegreeIndex === undefined) {
        targetDegreeIndex = funcToDegreeIndex[baseFunc.toLowerCase()];
    }
    
    // 特殊处理：ss 功能对应 VII 级（索引 6）
    if (baseFunc === 'ss') {
        targetDegreeIndex = 6;
    }
    
    // 如果找到了音级索引，尝试获取调内该音级的和弦
    if (targetDegreeIndex !== undefined && scaleData.rows[targetDegreeIndex]) {
        const matchedRow = scaleData.rows[targetDegreeIndex];
        const desiredQuality = getDesiredChordQualityFromFuncName(funcName);
        const finalRow = (desiredQuality === 'maj' || desiredQuality === 'min')
            ? buildTriadChordAtDegreeWithQuality(root, scaleData.intervals, targetDegreeIndex, desiredQuality, getMultiModeChordConverter())
            : matchedRow;
        const isMinorChord = finalRow.chordType === 'min';

        // 确定最终的功能名（大小写根据和弦类型）
        let finalFuncName = funcName;
        if (baseFunc === 't' || baseFunc === 'T') {
            finalFuncName = isMinorChord ? 't' : 'T';
        } else if (baseFunc === 'd' || baseFunc === 'D') {
            finalFuncName = isMinorChord ? 'd' : 'D';
        } else if (baseFunc === 's' || baseFunc === 'S') {
            finalFuncName = isMinorChord ? 's' : 'S';
        } else if (baseFunc === 'dd' || baseFunc === 'DD') {
            finalFuncName = isMinorChord ? 'dd' : 'DD';
        } else {
            finalFuncName = funcName;
        }
        finalFuncName = applyFuncNameCase(finalFuncName, desiredQuality);
        
        // 如果是数字前缀功能，保留原格式、括号片段
        if (numberedPrefix !== null) {
            const base = finalFuncName.replace(/^\d+/, '');
            finalFuncName = `${numberedPrefix}${base}`;
            if (funcName.includes('(')) {
                const parenMatch = funcName.match(/\(([^)]+)\)/);
                if (parenMatch) {
                    finalFuncName += `(${parenMatch[1]})`;
                }
            }
        }
        
        return {
            funcName: finalFuncName,
            degreeLabel: finalRow.degreeLabel,
            chordLabel: finalRow.chordLabel,
            notes: finalRow.notes,
            dist: finalRow.dist,
            isOutOfScale: false
        };
    }
    
    // 如果找不到调内和弦，只返回功能名，不返回和弦信息
    // 这是调外功能的情况（如 C 旋律小调中的 ss 对应 Bb）
    return {
        funcName: funcName,
        degreeLabel: "—",
        chordLabel: "—",
        notes: "—",
        isOutOfScale: true  // 标记为调外
    };
}

  function parseMultiModeNotes(notesStr) {
    if (!notesStr || notesStr === "—") return [];
    return String(notesStr)
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
  }

  function getModeScaleNoteNames(root, intervals) {
    const conv = getMultiModeChordConverter();
    const rootIdx = conv.noteToIdx[root];
    if (rootIdx === undefined) return [];
    return intervals.map((off) => conv.idxToNote[(rootIdx + off) % 12]);
  }

  function buildScalePitchListHtml(root, intervals) {
    const rootIdx = noteToIdx[root];
    return intervals
      .map((off, i) => {
        const note = idxToNote[(rootIdx + off) % 12];
        return `<span class="scale-pitch-chip" data-multi-play="scale-note" data-note="${escapeMultiModeHtml(note)}" title="点击播放 ${escapeMultiModeHtml(note)} · includeNoteIdx[${i}]=${off}">
        <span class="scale-pitch-idx">${i + 1}</span>
        <span class="scale-pitch-note">${escapeMultiModeHtml(note)}</span>
        <span class="scale-pitch-off">+${off}</span>
      </span>`;
      })
      .join("");
  }

function renderMultiModeTable(root, mode) {
    const tableContainer = document.getElementById("circle-table-container");
    if (!tableContainer) return;

    let intervals = mode.includeNoteIdx || [];

    const scalePitchHtml = buildScalePitchListHtml(root, intervals);
    const scaleData = buildModeScaleChordData(root, mode);
    const innerLabels = buildInnerFuncRingLabels(root, mode);
    const replaceGroup = mode.funcReplaceGroup || null;
    const temp = mode.spaceTemp ?? 0;
    const tempHue = 210 + ((Math.max(-8, Math.min(8, temp)) + 8) / 16) * (12 - 210);

    // 构建功能序列 - 只使用调内和弦
    const funcSeq = Array.isArray(mode.fullFuncSeq) ? mode.fullFuncSeq : [];

const funcSteps = funcSeq.map((fn) => {
    const chord = resolveFuncGroupChord(fn, root, mode, scaleData, innerLabels);
    return {
        ...chord,
        isReplace: replaceGroup && fn === replaceGroup,
    };
    // 不再过滤调外的，保留它们以显示功能标签
});

// 修改 seqFlowHtml 的渲染，区分调内调外
const seqFlowHtml = funcSteps.length
    ? funcSteps
          .map((step, i) => {
              // 调外和弦的样式不同
              const isOutClass = step.isOutOfScale ? " func-out-of-scale" : "";
              const node = `
          <div class="func-seq-node${step.isReplace ? " is-func-replace" : ""}${isOutClass}" data-multi-play="func-node" data-func-index="${i}" role="button" tabindex="0" title="${window.__("circle_multi_play_func_seq") || "播放序列"} ${escapeMultiModeHtml(step.chordLabel !== "—" ? step.chordLabel : step.funcName)}">
            <div class="func-seq-func">${escapeMultiModeHtml(step.funcName)}</div>
            <div class="func-seq-degree">${escapeMultiModeHtml(step.degreeLabel)}</div>
            <div class="func-seq-chord">${step.chordLabel !== "—" ? escapeMultiModeHtml(step.chordLabel) : '<span class="out-of-scale">(调外)</span>'} ${step.chordLabel !== "—" ? '<span class="multi-mode-play-hint" aria-hidden="true">🔊</span>' : ''}</div>
            <div class="func-seq-notes">${escapeMultiModeHtml(step.notes)}</div>
          </div>`;
              const arrow =
                  i < funcSteps.length - 1
                      ? '<div class="func-seq-arrow" aria-hidden="true">→</div>'
                      : funcSteps.length > 1
                        ? `<div class="func-seq-arrow func-seq-arrow-return" aria-hidden="true" title="${window.__("circle_multi_func_seq_hint") || "回到起点"}">↺</div>`
                        : "";
              return node + arrow;
          })
          .join("")
    : `<p class="multi-mode-empty">${window.__("circle_multi_empty_seq") || "暂无功能序列"}</p>`;

    const scaleRowsHtml = scaleData.rows
      .map(
        (row, idx) => `
      <tr class="multi-mode-degree-row" data-multi-play="degree" data-degree-index="${idx}" role="button" tabindex="0" title="${window.__("circle_multi_play_scale") || "播放音阶"} ${escapeMultiModeHtml(row.chordLabel)}">
        <td class="col-degree"><span class="roman-badge">${escapeMultiModeHtml(row.degreeLabel)}</span></td>
        <td class="col-chord"><strong>${escapeMultiModeHtml(row.chordLabel)}</strong> <span class="multi-mode-play-hint" aria-hidden="true">🔊</span></td>
        <td class="col-notes">${escapeMultiModeHtml(row.notes)}</td>
      </tr>`,
      )
      .join("");

    const antiTag = mode.isAntiFunc
      ? `<span class="meta-chip meta-anti">${window.__("circle_multi_mode_chip") || "反功能"}</span>`
      : "";

    tableContainer.innerHTML = `
    <div class="multi-mode-display">
      <header class="multi-mode-header">
        <div class="multi-mode-title-row">
          <span class="root-badge">${escapeMultiModeHtml(root)}</span>
          <h3 class="multi-mode-title">${escapeMultiModeHtml(mode.modeName || window.__("circle_multi_mode_label") || "调式")}</h3>
        </div>
        <div class="multi-mode-meta">
          <span class="meta-chip">${window.__("circle_multi_sort_tension")?.replace("{val}", escapeMultiModeHtml(mode.tensionLevel)) || `张力 ${escapeMultiModeHtml(mode.tensionLevel)}`}</span>
          <span class="meta-chip meta-temp" style="--temp-hue:${tempHue}">${window.__("circle_multi_sort_temp")?.replace("{val}", escapeMultiModeHtml(mode.spaceTemp)) || `温度 ${escapeMultiModeHtml(mode.spaceTemp)}`}</span>
          ${mode.funcReplaceGroup ? `<span class="meta-chip meta-replace">${window.__("circle_multi_func_seq_hint") || "功能替代"} ${escapeMultiModeHtml(mode.funcReplaceGroup)}</span>` : ""}
          ${antiTag}
        </div>
      </header>

      <section class="multi-mode-section scale-pitch-section">
        <div class="multi-mode-section-head">
          <h4 class="section-label">${window.__("circle_multi_mode_label") || "调式音阶"}</h4>
          <button type="button" class="multi-mode-play-btn" data-multi-play="scale" title="${window.__("circle_multi_play_scale") || "顺序播放调式音阶"}">🔊 ${window.__("circle_multi_play_scale") || "播放音阶"}</button>
        </div>
        <div class="scale-pitch-list">${scalePitchHtml}</div>
      </section>

      <section class="multi-mode-section full-func-seq-section">
        <div class="multi-mode-section-head">
          <h4 class="section-label">${window.__("circle_multi_play_func_seq") || "完全功能序列"}</h4>
          <button type="button" class="multi-mode-play-btn" data-multi-play="func-seq" title="${window.__("circle_multi_play_func_seq") || "按序列播放各功能和弦"}" ${funcSteps.length ? "" : "disabled"}>🔊 ${window.__("circle_multi_play_func_seq") || "播放序列"}</button>
        </div>
        <p class="section-hint">${window.__("circle_multi_func_seq_hint") || "功能名按五度圈内圈定位 · 点击节点可单独播放 · T–S–D–T → I–IV–V–I"}</p>
        <div class="full-func-seq-flow">${seqFlowHtml}</div>
      </section>

      <section class="multi-mode-section scale-table-section">
        <div class="multi-mode-section-head">
          <h4 class="section-label">${window.__("circle_multi_mode_label") || "调内音级"}</h4>
          <span class="section-hint-inline">${window.__("circle_multi_table_hint") || "点击行播放和弦"}</span>
        </div>
        <div class="multi-mode-table-wrap">
          <table class="multi-mode-degree-table degree-table">
            <thead>
              <tr><th>${window.__("circle_col_degree") || "音级"}</th><th>${window.__("circle_col_chord") || "和弦"}</th><th>${window.__("circle_col_notes") || "音符"}</th></tr>
            </thead>
            <tbody>${scaleRowsHtml}</tbody>
          </table>
        </div>
      </section>

      <footer class="multi-mode-footer">
        <small>${window.__("ack_color_harmony_studio") || "特别感谢色彩和声工作室提供的特性进行数据"}</small>
      </footer>
    </div>`;

    const display = tableContainer.querySelector(".multi-mode-display");
    if (display && window.jazzCompassAudio) {
      window.jazzCompassAudio.wireDisplay(display, {
        scaleNoteNames: getModeScaleNoteNames(root, intervals),
        degreeRows: scaleData.rows,
        funcSteps,
      });
    }
  }

  // 初始化多调性控制面板
  function initMultiModeCircle() {
    const toggleBtn = document.getElementById("circle-multi-toggle");
    const panel = document.getElementById("circle-multi-panel");
    const modeList = document.getElementById("circle-mode-list");
    const modeDropdown = document.getElementById("circle-mode-dropdown");
    const modeSearch = document.getElementById("circle-mode-search");
    const modeToggleBtn = document.getElementById("circle-mode-toggle");
    const applyBtn = document.getElementById("circle-apply-mode");
    const filterNormal = document.getElementById("filter-normal-only");
    const filterNatural = document.getElementById("filter-natural-only");
    const sortType = document.getElementById("circle-sort-type");
    const sortOrder = document.getElementById("circle-sort-order");

    if (!toggleBtn || !modeToggleBtn) return;

    // 颜色映射：空间温度 -> 色相（冷蓝到暖红），空间张力 -> 叠加变暗
    function tempToHsl(temp) {
      // temp: -8 .. 8 -> hue 210 (冷) .. 12 (暖)
      const t = Math.max(-8, Math.min(8, temp));
      const frac = (t + 8) / 16; // 0..1
      const hue = 210 + frac * (12 - 210); // 210 -> 12
      return `hsl(${hue},20%,30%)`;
    }

    function tensionDarkAlpha(tension) {
      const t = Math.max(1, Math.min(10, tension));
      return ((t - 1) / 9) * 0.725; // 0 .. 0.5
    }

    let selectedModeIdx = null;

    function clearSelectionVisual() {
      Array.from(modeList.children).forEach(child => child.style.boxShadow = "none");
    }

    function updateModeToggleLabel() {
      if (currentMultiMode && currentMultiMode.modeName) {
        modeToggleBtn.textContent = `${window.__("circle_multi_mode_chip") || "调式"}: ${currentMultiMode.modeName}`;
      } else {
        modeToggleBtn.textContent = window.__("circle_multi_expand") || '展开调式';
      }
    }

    // 刷新模式卡片列表（以卡片替代 select）
    function refreshModeList() {
      if (!modesData) return;
      let filtered = [...modesData];
      if (filterNormal.checked) filtered = filtered.filter(m => m.isNormalMode === true);
      if (filterNatural.checked) filtered = filtered.filter(m => m.isNaturalScale === true);

      const keyword = modeSearch?.value.trim().toLowerCase();
      if (keyword) {
        filtered = filtered.filter(m => (m.modeName || '').toLowerCase().includes(keyword));
      }

      const sortKey = sortType.value === "tension" ? "tensionLevel" : "spaceTemp";
      const order = sortOrder.value === "asc" ? 1 : -1;
      filtered.sort((a, b) => order * (a[sortKey] - b[sortKey]));

      modeList.innerHTML = "";
      if (filtered.length === 0) {
        const empty = document.createElement('div');
        empty.textContent = window.__("circle_multi_no_match") || '没有匹配的调式';
        empty.style.color = 'rgba(255,255,255,0.6)';
        empty.style.padding = '10px';
        modeList.appendChild(empty);
        return;
      }

      filtered.forEach(m => {
        const card = document.createElement('div');
        card.className = 'mode-card';
        card.style.minWidth = '160px';
        card.style.padding = '8px';
        card.style.borderRadius = '8px';
        card.style.cursor = 'pointer';
        card.style.color = '#fff';
        card.style.display = 'flex';
        card.style.flexDirection = 'column';
        card.style.gap = '6px';
        card.dataset.idx = m.idx;

        const baseColor = tempToHsl(m.spaceTemp);
        const darkAlpha = tensionDarkAlpha(m.tensionLevel);
        card.style.background = `linear-gradient(rgba(0,0,0,${darkAlpha}), rgba(0,0,0,${darkAlpha})), ${baseColor}`;
        card.style.border = '1px solid rgba(255,255,255,0.1)';

        const title = document.createElement('div');
        title.textContent = m.modeName || (`mode ${m.idx}`);
        title.style.fontWeight = '600';
        title.style.fontSize = '13px';

        const meta = document.createElement('div');
        meta.textContent = `${window.__("circle_multi_sort_tension")?.replace("{val}", m.tensionLevel) || `张力:${m.tensionLevel}`} ${window.__("circle_multi_sort_temp")?.replace("{val}", m.spaceTemp) || `温度:${m.spaceTemp}`}`;
        meta.style.fontSize = '12px';
        meta.style.opacity = '0.9';

        card.appendChild(title);
        card.appendChild(meta);

        if (selectedModeIdx === m.idx) {
          card.style.boxShadow = '0 0 0 3px rgba(255,255,255,0.18)';
        }

        card.addEventListener('click', () => {
          selectedModeIdx = m.idx;
          clearSelectionVisual();
          card.style.boxShadow = '0 0 0 3px rgba(255,255,255,0.12)';
          currentMultiMode = m;
          currentRoot = null;
          updateModeToggleLabel();
          updateCircleMultiMode();
        });

        modeList.appendChild(card);
      });
    }

    // helper: 在 checkbox 状态变化时为包裹的 label 添加/移除活动类
    function setFilterLabelState(checkbox) {
      if (!checkbox) return;
      const lbl = checkbox.closest('label') || document.querySelector(`label[for="${checkbox.id}"]`);
      if (!lbl) return;
      if (checkbox.checked) lbl.classList.add('is-active');
      else lbl.classList.remove('is-active');
    }

    // 初始化状态并绑定事件，使 UI 有视觉反馈
    setFilterLabelState(filterNormal);
    setFilterLabelState(filterNatural);
    filterNormal.addEventListener('change', (e) => { setFilterLabelState(e.target); refreshModeList(); });
    filterNatural.addEventListener('change', (e) => { setFilterLabelState(e.target); refreshModeList(); });
    sortType.addEventListener('change', refreshModeList);
    sortOrder.addEventListener('change', refreshModeList);
    modeSearch.addEventListener('input', refreshModeList);

    modeToggleBtn.addEventListener('click', () => {
      if (!modeDropdown) return;
      const isOpen = modeDropdown.style.display === 'flex';
      modeDropdown.style.display = isOpen ? 'none' : 'flex';
      modeToggleBtn.textContent = isOpen
        ? (currentMultiMode?.modeName ? `${window.__("circle_multi_mode_chip") || "调式"}: ${currentMultiMode.modeName}` : window.__("circle_multi_expand") || '展开调式')
        : window.__("circle_multi_collapse") || '收起调式';
      if (!isOpen) {
        refreshModeList();
      }
    });

    toggleBtn.addEventListener('click', () => {
      multiModeActive = !multiModeActive;
      panel.style.display = multiModeActive ? 'flex' : 'none';
      if (multiModeActive) {
        currentRoot = null;
        refreshModeList();
      } else {
        currentRoot = null;
        circleCurrentKey = null;
        drawCircle(null, null);
        const tableContainer = document.getElementById('circle-table-container');
        tableContainer.innerHTML = '';
      }
      toggleBtn.textContent = multiModeActive ? (window.__("circle_multi_mode") || '多调性模式') : (window.__("nav_circle") || '五度圈');
    });

    applyBtn.addEventListener('click', () => {
      if (!multiModeActive) return;
      if (!currentMultiMode) return;
      updateCircleMultiMode();
    });

    // 搜索框 placeholder 本地化
    if (modeSearch) {
      modeSearch.placeholder = window.__("circle_multi_search_placeholder") || "搜索调式";
    }

    // 过滤器 label 本地化（只更新文本部分，保留checkbox）
    if (filterNormal) {
      const lbl = filterNormal.closest('label');
      if (lbl) {
        let textNode = Array.from(lbl.childNodes).find(n => n.nodeType === 3 && n.textContent.trim());
        if (!textNode) {
          textNode = document.createTextNode('');
          lbl.appendChild(textNode);
        }
        textNode.textContent = ' ' + (window.__("circle_multi_filter_normal") || "仅常规调式");
      }
    }
    if (filterNatural) {
      const lbl = filterNatural.closest('label');
      if (lbl) {
        let textNode = Array.from(lbl.childNodes).find(n => n.nodeType === 3 && n.textContent.trim());
        if (!textNode) {
          textNode = document.createTextNode('');
          lbl.appendChild(textNode);
        }
        textNode.textContent = ' ' + (window.__("circle_multi_filter_natural") || "仅自然音阶");
      }
    }

    // 排序类型 label 本地化
    if (sortType) {
      for (const opt of sortType.options) {
        if (opt.value === "tension") opt.textContent = window.__("circle_multi_sort_tension") || "空间张力等级";
        if (opt.value === "temp") opt.textContent = window.__("circle_multi_sort_temp") || "空间温度等级";
      }
    }

    // 排序顺序 label 本地化
    if (sortOrder) {
      for (const opt of sortOrder.options) {
        if (opt.value === "asc") opt.textContent = window.__("sort_asc") || "升序";
        if (opt.value === "desc") opt.textContent = window.__("sort_desc") || "降序";
      }
    }

    // 初始隐藏面板与下拉列表
    panel.style.display = 'none';
    if (modeDropdown) modeDropdown.style.display = 'none';
  }


  function drawArcSegment(
    ctx,
    cx,
    cy,
    innerR,
    outerR,
    startAngle,
    endAngle,
    label,
    sharps,
    flats,
    isHighlighted,
    type,
    axisGroup,
  ) {
    const midAngle = (startAngle + endAngle) / 2;
    const midR = (innerR + outerR) / 2;

    // 填充
    ctx.beginPath();
    ctx.arc(cx, cy, outerR, startAngle, endAngle);
    ctx.arc(cx, cy, innerR, endAngle, startAngle, true);
    ctx.closePath();

    const lightTheme = document.documentElement.dataset.theme === "light";
    const axisColor =
      axisGroup && axisColorMap[axisGroup]
        ? axisColorMap[axisGroup][type]
        : lightTheme
          ? type === "major" ? "rgba(45,44,39,0.10)" : "rgba(45,44,39,0.055)"
          : axisColorMap.default[type];
    const highlightColor =
      axisGroup && axisColorMap[axisGroup]
        ? axisColorMap[axisGroup].highlight
        : axisColorMap.default.highlight;
    if (isHighlighted) {
      const grad = ctx.createLinearGradient(
        cx + Math.cos(midAngle) * innerR,
        cy + Math.sin(midAngle) * innerR,
        cx + Math.cos(midAngle) * outerR,
        cy + Math.sin(midAngle) * outerR,
      );
      grad.addColorStop(0, highlightColor);
      grad.addColorStop(1, lightTheme ? "rgba(35,34,30,0.13)" : "rgba(255,255,255,0.15)");
      ctx.fillStyle = grad;
    } else {
      ctx.fillStyle = axisColor;
    }
    ctx.fill();

    // 边框
    ctx.strokeStyle = isHighlighted
      ? type === "major"
        ? "rgba(100,180,255,0.8)"
        : "rgba(255,160,120,0.7)"
      : lightTheme ? "rgba(35,34,30,0.18)" : "rgba(255,255,255,0.15)";
    ctx.lineWidth = isHighlighted ? 2 : 1;
    ctx.stroke();

    // 标签
    const textX = cx + Math.cos(midAngle) * midR;
    const textY = cy + Math.sin(midAngle) * midR;

    ctx.fillStyle = lightTheme
      ? (isHighlighted ? "#171816" : "rgba(35,34,30,0.82)")
      : (isHighlighted ? "#fff" : "rgba(255,255,255,0.8)");
    ctx.font = isHighlighted ? "bold 13px sans-serif" : "12px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(label, textX, textY);

    // 升号/降号数量小标
    if (sharps > 0 || flats > 0) {
      const subLabel = sharps > 0 ? `${sharps}♯` : `${flats}♭`;
      ctx.fillStyle = lightTheme ? "rgba(35,34,30,0.48)" : "rgba(255,255,255,0.45)";
      ctx.font = "8px sans-serif";
      ctx.fillText(subLabel, textX, textY + (type === "major" ? 14 : -14));
    }
  }
  function createModeButton(label, isActive, onClick) {
    const btn = document.createElement("button");
    btn.textContent = label;
    btn.style.padding = "6px 14px";
    btn.style.borderRadius = "6px";
    btn.style.border = isActive
      ? "2px solid var(--accent-2)"
      : "1px solid rgba(255,255,255,0.2)";
    btn.style.background = isActive
      ? "rgba(255,255,255,0.12)"
      : "transparent";
    btn.style.color = isActive ? "#fff" : "var(--muted)";
    btn.style.fontSize = "0.85em";
    btn.style.cursor = "pointer";
    btn.style.transition = "all 0.2s";
    btn.addEventListener("mouseenter", () => {
      if (!isActive) {
        btn.style.background = "rgba(255,255,255,0.06)";
        btn.style.color = "#ddd";
      }
    });
    btn.addEventListener("mouseleave", () => {
      if (!isActive) {
        btn.style.background = "transparent";
        btn.style.color = "var(--muted)";
      }
    });
    btn.addEventListener("click", onClick);
    return btn;
  }

  // 生成调性对照表
  function renderKeyTable(majorKey, minorKey, primarySection = "major") {
    tableContainer.innerHTML = "";

    // --- 大调切换按钮 ---
    const majorToggleRow = document.createElement("div");
    majorToggleRow.style.display = "flex";
    majorToggleRow.style.gap = "8px";
    majorToggleRow.style.marginBottom = "12px";

    const naturalMajorLabel =
      window.__("circle_major_natural") || "Natural Major";
    const harmonicMajorLabel =
      window.__("circle_major_harmonic") || "Harmonic Major";

    const btnMajorNatural = createModeButton(
      `${naturalMajorLabel} (${majorKey})`,
      majorMode === "natural",
      () => {
        majorMode = "natural";
        renderKeyTable(majorKey, minorKey, circleCurrentKey?.primary || "major");
      },
    );
    const btnMajorHarmonic = createModeButton(
      `${harmonicMajorLabel} (${majorKey})`,
      majorMode === "harmonic",
      () => {
        majorMode = "harmonic";
        renderKeyTable(majorKey, minorKey, circleCurrentKey?.primary || "major");
      },
    );
    majorToggleRow.appendChild(btnMajorNatural);
    majorToggleRow.appendChild(btnMajorHarmonic);

    // --- 大调表 ---
    const majorSec = document.createElement("div");
    majorSec.style.marginBottom = "20px";

    const intervals =
      majorMode === "harmonic" ? harmonicMajorIntervals : majorScaleIntervals;
    const chordTypes =
      majorMode === "harmonic" ? harmonicMajorChordTypes : majorChordTypes;
    const degreeNums =
      majorMode === "harmonic" ? harmonicMajorDegreeNums : majorDegreeNums;
    const funcs =
      majorMode === "harmonic"
        ? buildHarmonicMajorFuncs()
        : buildMajorFuncs();
    const modeLabel =
      majorMode === "harmonic"
        ? window.__("circle_major_harmonic") || "Harmonic Major"
        : window.__("circle_major_natural") || "Natural Major";

    const majorNotes = getScaleNotes(majorKey, intervals);

    const majorTitle = document.createElement("h4");
    majorTitle.className = "section-title";
    majorTitle.style.margin = "0 0 10px 0";
    majorTitle.innerHTML = `<span style="color:var(--accent-2);">${majorKey} ${modeLabel}</span>`;
    majorSec.appendChild(majorTitle);
    majorSec.appendChild(
      buildDegreeTable(majorNotes, degreeNums, funcs, chordTypes, majorKey),
    );

    // --- 分隔线 ---
    const divider = document.createElement("hr");
    divider.style.border = "none";
    divider.style.borderTop = "1px solid rgba(255,255,255,0.1)";
    divider.style.margin = "16px 0";

    // --- 小调切换按钮 ---
    const minorToggleRow = document.createElement("div");
    minorToggleRow.style.display = "flex";
    minorToggleRow.style.gap = "8px";
    minorToggleRow.style.marginBottom = "12px";
    const naturalMinorLabel =
      window.__("circle_minor_natural") || "Natural Minor";
    const harmonicMinorLabel =
      window.__("circle_minor_harmonic") || "Harmonic Minor";

    const btnMinorNatural = createModeButton(
      `${naturalMinorLabel} (${minorKey})`,
      minorMode === "natural",
      () => {
        minorMode = "natural";
        renderKeyTable(majorKey, minorKey, circleCurrentKey?.primary || "major");
      },
    );
    const btnMinorHarmonic = createModeButton(
      `${harmonicMinorLabel} (${minorKey})`,
      minorMode === "harmonic",
      () => {
        minorMode = "harmonic";
        renderKeyTable(majorKey, minorKey, circleCurrentKey?.primary || "major");
      },
    );
    minorToggleRow.appendChild(btnMinorNatural);
    minorToggleRow.appendChild(btnMinorHarmonic);

    // --- 小调表 ---
    const minorSec = document.createElement("div");

    const mIntervals =
      minorMode === "harmonic" ? harmonicMinorIntervals : minorScaleIntervals;
    const mChordTypes =
      minorMode === "harmonic" ? harmonicMinorChordTypes : minorChordTypes;
    const mDegreeNums =
      minorMode === "harmonic" ? harmonicMinorDegreeNums : minorDegreeNums;
    const mFuncs =
      minorMode === "harmonic"
        ? buildHarmonicMinorFuncs()
        : buildMinorFuncs();
    const mModeLabel =
      minorMode === "harmonic"
        ? window.__("circle_minor_harmonic") || "Harmonic Minor"
        : window.__("circle_minor_natural") || "Natural Minor";

    const minorNotes = getScaleNotes(minorKey, mIntervals);

    const minorTitle = document.createElement("h4");
    minorTitle.className = "section-title";
    minorTitle.style.margin = "0 0 10px 0";
    minorTitle.innerHTML = `<span style="color:var(--accent-2);">${minorKey} ${mModeLabel}</span>`;
    minorSec.appendChild(minorTitle);
    minorSec.appendChild(
      buildDegreeTable(
        minorNotes,
        mDegreeNums,
        mFuncs,
        mChordTypes,
        minorKey,
      ),
    );

    if (primarySection === "major") {
      tableContainer.appendChild(majorToggleRow);
      tableContainer.appendChild(majorSec);
      tableContainer.appendChild(divider);
      tableContainer.appendChild(minorToggleRow);
      tableContainer.appendChild(minorSec);
    } else {
      tableContainer.appendChild(minorToggleRow);
      tableContainer.appendChild(minorSec);
      tableContainer.appendChild(divider);
      tableContainer.appendChild(majorToggleRow);
      tableContainer.appendChild(majorSec);
    }
  }

  function buildDegreeTable(notes, degreeNums, funcs, chordTypes, keyRoot) {
    const table = document.createElement("table");
    table.style.width = "100%";
    table.style.borderCollapse = "collapse";
    table.style.fontSize = "0.9em";
    table.className = "degree-table clickable";

    // 表头
    const thead = document.createElement("thead");
    const headerRow = document.createElement("tr");
    [
      window.__("circle_col_degree") || "Degree",
      window.__("circle_col_chord") || "Chord",
      window.__("circle_col_function") || "Function",
      window.__("circle_col_notes") || "Notes",
    ].forEach((h) => {
      const th = document.createElement("th");
      th.style.padding = "8px 6px";
      th.style.borderBottom = "1px solid rgba(255,255,255,0.15)";
      th.style.textAlign = "left";
      th.style.color = "var(--muted)";
      th.style.fontWeight = "500";
      th.textContent = h;
      headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);

    // 表体
    const tbody = document.createElement("tbody");
    const degreeColors = [
      "rgba(100,200,255,0.15)",
      "rgba(150,150,220,0.1)",
      "rgba(150,150,220,0.1)",
      "rgba(100,255,180,0.12)",
      "rgba(255,180,100,0.15)",
      "rgba(150,150,220,0.1)",
      "rgba(255,120,120,0.12)",
    ];
    const augColor = "rgba(255,200,80,0.2)";
    let lastChordRootMidi = null;

    notes.forEach((note, i) => {
      const row = document.createElement("tr");
      const degStr = degreeNums[i] || "";
      const isAug = degStr.includes("+");
      const isDim = degStr.includes("°");
      row.style.background = isAug ? augColor : degreeColors[i];
      row.style.cursor = "pointer";
      row.style.transition = "all 0.2s ease";

      const degCell = document.createElement("td");
      degCell.style.padding = "8px 6px";
      degCell.style.fontWeight = "bold";
      degCell.textContent = degStr;
      row.appendChild(degCell);

      const chordCell = document.createElement("td");
      chordCell.style.padding = "8px 6px";
      chordCell.style.fontWeight = "600";
      const chordNameFull = formatChordNameFull(note, degStr);
      chordCell.textContent = chordNameFull;
      row.appendChild(chordCell);

      const funcCell = document.createElement("td");
      funcCell.style.padding = "8px 6px";
      funcCell.style.color = "var(--muted)";
      funcCell.style.fontSize = "0.85em";
      funcCell.textContent = funcs[i] || "";
      row.appendChild(funcCell);

      const notesCell = document.createElement("td");
      notesCell.style.padding = "8px 6px";
      notesCell.style.display = "flex";
      notesCell.style.gap = "3px";
      notesCell.style.flexWrap = "wrap";

      const chordType = chordTypes[i] || "maj";
      const chordIntervals = getIntervalsByType(chordType);
      const chordNoteNames = []; // 收集和弦音符
      chordIntervals.forEach((interval) => {
        const noteSemitone = noteToSemitone(note);
        if (noteSemitone === undefined) return;
        const idx = (noteSemitone + interval) % 12;
        const chordNote = semitoneToNote(idx);
        chordNoteNames.push(chordNote);
        const span = document.createElement("span");
        span.style.padding = "2px 6px";
        span.style.borderRadius = "3px";
        span.style.background = "rgba(255,255,255,0.08)";
        span.style.fontSize = "0.85em";
        span.textContent = chordNote;
        notesCell.appendChild(span);
      });
      row.appendChild(notesCell);

      // ============ 点击播放声音（i 级定基准，逐级抬高根音） ============
      const { freqs: chordFreqs, rootMidi } = chordNotesToFrequencies(
        chordNoteNames,
        4,
        false,
        lastChordRootMidi,
      );
      if (rootMidi != null) {
        lastChordRootMidi = rootMidi;
      }

      const audioIndicator = document.createElement("span");
      audioIndicator.textContent = " 🔊";
      audioIndicator.style.opacity = "0";
      audioIndicator.style.transition = "opacity 0.2s";
      audioIndicator.style.fontSize = "0.8em";
      chordCell.appendChild(audioIndicator);

      row.addEventListener("mouseenter", () => {
        row.style.background = isAug
          ? "rgba(255,220,100,0.35)"
          : degreeColors[i].replace("0.1", "0.25").replace("0.12", "0.28").replace("0.15", "0.32");
        row.style.transform = "translateX(4px)";
        audioIndicator.style.opacity = "1";
      });

      row.addEventListener("mouseleave", () => {
        row.style.background = isAug ? augColor : degreeColors[i];
        row.style.transform = "translateX(0)";
        audioIndicator.style.opacity = "0";
      });

      row.addEventListener("click", () => {
        row.style.transform = "scale(0.98)";
        playChord(chordFreqs);
        requestAnimationFrame(() => {
          row.style.transform = "translateX(4px)";
        });
      });

      tbody.appendChild(row);
    });
    table.appendChild(tbody);

    return table;
  }

  function formatChordNameFull(root, degreeStr) {
    const cleanRoot = semitoneToNote(noteToSemitone(root) || 0);
    if (degreeStr.includes("°")) return cleanRoot + "°";
    if (degreeStr.includes("+")) return cleanRoot + "+";
    if (degreeStr === degreeStr.toLowerCase() && degreeStr.includes("m"))
      return cleanRoot + "m";
    // I, IV, V 等大写 = 大三和弦
    if (
      degreeStr === degreeStr.toUpperCase() &&
      !degreeStr.includes("°") &&
      !degreeStr.includes("+")
    )
      return cleanRoot;
    // ii, iii, vi 等小写 = 小和弦
    if (degreeStr === degreeStr.toLowerCase()) return cleanRoot + "m";
    return cleanRoot;
  }

  function getIntervalsByType(type) {
    switch (type) {
      case "maj":
        return [0, 4, 7];
      case "m":
        return [0, 3, 7];
      case "dim":
        return [0, 3, 6];
      case "aug":
        return [0, 4, 8];
      default:
        return [0, 4, 7];
    }
  }

  // Canvas 点击事件
  canvas.addEventListener("click", (e) => {
    const rect = canvas.getBoundingClientRect();
    const size = rect.width;
    const scaleX = size / rect.width;
    const scaleY = size / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    const cx = size / 2;
    const cy = size / 2;
    const dist = Math.sqrt((x - cx) ** 2 + (y - cy) ** 2);
    const outerR = size * 0.42;
    const innerR = size * 0.28;
    const centerR = size * 0.12;

    if (dist < centerR || dist > outerR) return;

    let angle = Math.atan2(y - cy, x - cx) + Math.PI / 2;
    if (angle < 0) angle += Math.PI * 2;
    const sectorIndex = Math.floor((angle / (Math.PI * 2)) * 12) % 12;
    const item = circleData[sectorIndex];

    if (multiModeActive && currentMultiMode) {
      if (dist >= innerR && dist <= outerR) {
        currentRoot = item.major;
      } else if (dist >= centerR && dist < innerR) {
        currentRoot = item.minor;
      }
      updateCircleMultiMode();
      return;
    }

    if (dist >= innerR && dist <= outerR) {
      // 点击外环 — 大调
      circleCurrentKey = {
        major: item.major,
        minor: item.minor,
        primary: "major",
      };
      drawCircle(item.major, null);
      renderKeyTable(item.major, item.minor, "major");
    } else if (dist >= centerR && dist < innerR) {
      // 点击内环 — 小调
      circleCurrentKey = {
        major: item.major,
        minor: item.minor,
        primary: "minor",
      };
      drawCircle(null, item.minor);
      renderKeyTable(item.major, item.minor, "minor");
    }
  });

  // 重置按钮
  resetBtn.addEventListener("click", () => {
    circleCurrentKey = null;
    drawCircle(null, null);
    tableContainer.innerHTML = "";
  });

  // 窗口大小变化重绘
  window.addEventListener("resize", () => {
    if (document.getElementById("panel-circle").style.display !== "none") {
      if (multiModeActive && currentMultiMode) {
        updateCircleMultiMode();
      } else if (circleCurrentKey) {
        drawCircle(
          circleCurrentKey.primary === "major"
            ? circleCurrentKey.major
            : null,
          circleCurrentKey.primary === "minor"
            ? circleCurrentKey.minor
            : null,
        );
        renderKeyTable(
          circleCurrentKey.major,
          circleCurrentKey.minor,
          circleCurrentKey.primary,
        );
      } else {
        drawCircle(null, null);
      }
    }
  });

  // 初始绘制
  drawCircle(null, null);


  const navButtons = Array.from(document.querySelectorAll(".feature-btn"));
  const panels = Array.from(document.querySelectorAll(".panel"));
  let compositionTimer = null;
  let compositionMarks = [];
  const compositionAudio = {
    stop() {
      const wasPlaying = compositionTimer !== null || compositionMarks.length > 0;
      clearInterval(compositionTimer); compositionTimer = null;
      compositionMarks.forEach(clearTimeout); compositionMarks = [];
      if (wasPlaying && audioCtx) interruptPlayback(audioCtx);
    },
    play(events, bpm, duration, highlight) {
      this.stop(); stopClassicalSequencePlayback();
      const ctx = getAudioContext();
      interruptPlayback(ctx);
      ctx.resume();
      const start = ctx.currentTime + .08, seconds = 60 / bpm;
      const sorted = [...events].sort((a,b) => a.beat-b.beat);
      let index = 0, lastMarker = -1;
      const schedule = () => {
        while (index < sorted.length && start + sorted[index].beat * seconds < ctx.currentTime + .15) {
          const event = sorted[index++], time = start + event.beat * seconds;
          const tone = createPianoTone(ctx, 440 * 2 ** ((event.midi-69)/12), time, event.duration * seconds);
          const gain = ctx.createGain(); gain.gain.value = event.velocity;
          tone.connect(gain); gain.connect(audioDryBus); gain.connect(audioWetBus);
          const marker = event.bar ?? event.step;
          if (marker !== lastMarker) {
            lastMarker = marker;
            compositionMarks.push(setTimeout(() => highlight(event), Math.max(0,(time-ctx.currentTime)*1000)));
          }
        }
        if (ctx.currentTime > start + duration * seconds + .2) { clearInterval(compositionTimer); compositionTimer = null; }
      };
      schedule(); compositionTimer = setInterval(schedule,25);
    }
  };

  const conv = new EnhancedChordConverter();
  const brain = new JazzBrain();
  const classical = new ClassicalHarmonyConnector();
  let classicalChain = [];
  let classicalSegments = [];
  let classicalLastKey = null;
  let classicalLastMode = null;
  let classicalActiveView = "recommendations";
  let classicalPendingChain = null;
  let classicalSequencePlaybackId = 0;
  let classicalSequenceTimers = [];
  const CLASSICAL_PLAYBACK_STORAGE_KEY = "jazz-compass-classical-playback";
  const DEFAULT_CLASSICAL_PLAYBACK = { bpm: 80, meter: "4/4", mode: "block" };

  function stopClassicalSequencePlayback() {
    const wasPlaying = classicalSequenceTimers.length > 0;
    classicalSequencePlaybackId += 1;
    classicalSequenceTimers.forEach(timer => clearTimeout(timer));
    classicalSequenceTimers = [];
    if (wasPlaying && audioCtx) interruptPlayback(audioCtx);
  }

  function loadClassicalPlaybackSettings() {
    try {
      const saved = JSON.parse(localStorage.getItem(CLASSICAL_PLAYBACK_STORAGE_KEY) || "{}");
      return {
        bpm: Math.max(40, Math.min(640, Math.round(Number(saved.bpm) || DEFAULT_CLASSICAL_PLAYBACK.bpm))),
        meter: ["4/4", "3/4", "6/8", "8/8", "12/16", "16/16"].includes(saved.meter) ? saved.meter : DEFAULT_CLASSICAL_PLAYBACK.meter,
        mode: ["block", "arpeggio"].includes(saved.mode) ? saved.mode : DEFAULT_CLASSICAL_PLAYBACK.mode,
      };
    } catch (_) {
      return { ...DEFAULT_CLASSICAL_PLAYBACK };
    }
  }

  function saveClassicalPlaybackSettings(settings) {
    localStorage.setItem(CLASSICAL_PLAYBACK_STORAGE_KEY, JSON.stringify(settings));
  }
  document.querySelectorAll(".theme-btn").forEach((button) => {
    button.addEventListener("click", () => setTheme(button.dataset.themeValue));
  });
  setTheme(document.documentElement.dataset.theme || "light");
  document.querySelectorAll(".notation-btn").forEach((button) => {
    button.addEventListener("click", () => setNotation(button.dataset.notation));
  });
  applyNotationToConverters();
  document.querySelectorAll(".notation-btn").forEach((button) => {
    const active = button.dataset.notation === notationMode;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", String(active));
  });
  // state for "other" panel mode
  let currentOtherMode = "report";

  // 本地化负和声轴标签
  const axisLabelEl = document.getElementById("label_other_axis");
  if (axisLabelEl && window.__) {
    axisLabelEl.textContent = window.__("neg_axis") || "Axis";
  }

  function showOnlyFeature(feature) {
    if (feature !== 'blues') document.getElementById('panel-blues-body')?.stopBluesPlayback?.();
    if (feature !== 'classical') stopClassicalSequencePlayback();
    document.querySelectorAll('#panel-form, #panel-rhythm').forEach(panel => { if (panel.dataset.feature !== feature) panel.dispatchEvent(new Event('toolbox-stop')); });
    const featureIndex = navButtons.findIndex(button => button.dataset.feature === feature);
    const featureCodes = { form:'FORM STUDIES', rhythm:'RHYTHM LAB', chord: 'CHORD STUDY', classical: 'HARMONY', blues: 'BLUES', lcc: 'LCC CONCEPT LAB', cst: 'JAZZ TOOLBOX', neo: 'HARMONIC CONNECTIONS', micro: 'MICROTONAL LAB', ref: 'REFERENCE', circle: 'CIRCLE OF FIFTHS', other: 'TOOLS', about: 'ABOUT' };
    document.getElementById('workspace-index').textContent = `${String(featureIndex + 1).padStart(2, '0')} / ${featureCodes[feature]}`;
    document.getElementById('workspace-title').textContent = window.__(`nav_${feature}`);
    document.getElementById('workspace-description').textContent = window.__(`intro_${feature}`);
    navButtons.forEach((b) => {
      const active = b.dataset.feature === feature;
      b.classList.toggle("active", active);
      b.setAttribute("aria-selected", String(active));
      b.setAttribute("tabindex", active ? "0" : "-1");
    });
    panels.forEach((p) => {
      const f = p.dataset.feature;
      if (f === feature) {
        p.classList.add("active");
        p.style.display = "block";
        p.setAttribute("aria-hidden", "false");
      } else {
        p.classList.remove("active");
        p.style.display = "none";
        p.setAttribute("aria-hidden", "true");
      }
    });
    document.querySelector(`.feature-btn[data-feature="${feature}"]`)?.scrollIntoView({
      block: "nearest",
      inline: "center",
      behavior: "smooth",
    });
    // special handling for about panel
    if (feature === "about") {
      showAbout();
    }
    if (feature === "circle") {
      drawCircle(null, null);
    }
    if (feature === "ref") {
      initRefPanel();
    }
    if (feature === "classical" && !document.getElementById("panel-classical-body")?.children.length) {
      document.getElementById("classical-run")?.click();
    }
    if (feature === 'neo' && !document.getElementById('panel-neo-body')?.children.length) {
      document.getElementById('neo-run')?.click();
    }
    if (feature === 'form' && !document.getElementById('panel-form').children.length) mountComposition(document.getElementById('panel-form'), compositionAudio);
    if (feature === 'rhythm' && !document.getElementById('panel-rhythm').children.length) mountRhythm(document.getElementById('panel-rhythm'), compositionAudio);
  }

  function showAbout() {
    const aboutBody = document.getElementById("panel-about-body");
    if (!aboutBody) return;

    const html = `
      <h3>${window.__("about_title")}</h3>
      <p>${window.__("about_desc")}</p>
      
      <h4 style="margin-top:20px">${window.__("about_features")}</h4>
      <ul style="margin-left:20px">
        <li>${window.__("about_feature_chord")}</li>
        <li>${window.__("about_feature_blues")}</li>
        <li>${window.__("about_feature_lcc")}</li>
        <li>${window.__("about_feature_cst")}</li>
      </ul>
      <p style="margin-top:16px; color:#ddd; font-size:0.95rem; line-height:1.6;">${window.__("about_acknowledgement")}</p>
      <p class="about-credit">${window.__("about_sposobin")}</p>
      
      <h4 style="margin-top:20px">${window.__("about_github")}</h4>
      <div style="margin: 12px 0;">
        <p>
          <a href="https://github.com/3035936740/Jazz-Compass-Web" target="_blank" style="color:#0066cc">
            ${window.__("about_github_web")}
          </a>
        </p>
        <p>
          <a href="https://github.com/3035936740/JazzCompassPy" target="_blank" style="color:#0066cc">
            ${window.__("about_github_py")}
          </a>
        </p>
      </div>
      
      <hr style="margin-top:30px">
      <p style="font-size:0.9em; color:#999">${window.__("about_footer")}</p>
    `;

    aboutBody.innerHTML = html;
  }

  function prettyChordRender(targetEl, inputValue) {
    const v = inputValue.trim();
    const data = conv._ensureNotesAndRoot(v, true);
    const notes = data.notes;
    const displayNotes = data.voicing?.length ? data.voicing : notes;
    const chord = data.chord;

    if (notes && Array.isArray(notes) && notes.length > 0) {
      const offsets = displayNotes.map((n) => conv.noteToIdx[n]);
      // 美化输出：根 / 链接 和 列表 + 偏移 + 小键盘视图
      const root = data.root || notes[0];
      const isSlash = v.includes("/");
      const bass = data.bass;
      const bassIdx = bass ? conv.noteToIdx[bass] : null;
      const htmlParts = [];
      htmlParts.push(`<div class="chord-result-heading"><div><span class="result-eyebrow">${window.__("identified_chord")}</span><h3 class="chord-symbol">${chord}</h3></div><span class="chord-note-count">${displayNotes.length} ${window.__("note_count_unit")}</span></div>`);
      /*
      htmlParts.push(
        `<p><strong>${window.__("root_label")}：</strong>${root} <strong style="margin-left:12px">${window.__("slash_label")}：</strong>${isSlash}</p>`,
      );
    */
      htmlParts.push('<div class="note-grid">');
      for (let i = 0; i < displayNotes.length; i++) {
        const note = displayNotes[i];
        const classes = ["note-cell"];
        if (bass && conv.noteToIdx[note] === bassIdx) classes.push("bass-note");
        if (conv.noteToIdx[note] === conv.noteToIdx[root]) classes.push("root-note");
        const degree = ('CDEFGAB'.indexOf(note[0]) - 'CDEFGAB'.indexOf(root[0]) + 7) % 7;
        const semitones = (conv.noteToIdx[note] - conv.noteToIdx[root] + 12) % 12;
        const alteration = (semitones - [0, 2, 4, 5, 7, 9, 11][degree] + 18) % 12 - 6;
        const interval = `${alteration < 0 ? '♭'.repeat(-alteration) : '♯'.repeat(alteration)}${degree + 1}`;
        htmlParts.push(
          `<div class="${classes.join(" ")}"><div class="note">${note}</div><span class="note-interval">${interval}</span></div>`,
        );
      }
      htmlParts.push("</div>");

      const rootIdx = conv.noteToIdx[root];
      const activeSet = new Set(offsets);
      const whitePcs = [0, 2, 4, 5, 7, 9, 11, 0, 2, 4, 5, 7, 9, 11];
      const blackAfter = new Set([0, 2, 5, 7, 9]);
      const blackPc = { 0: 1, 2: 3, 5: 6, 7: 8, 9: 10 };
      const keys = whitePcs.map((pc, index) => {
        const octave = index < 7 ? 4 : 5;
        const white = `<button type="button" class="piano-key piano-white-key${activeSet.has(pc) ? " is-active" : ""}${rootIdx === pc ? " is-root" : ""}${bassIdx === pc ? " is-bass" : ""}" data-piano-pc="${pc}" data-piano-octave="${octave}" aria-label="${conv.idxToNote[pc]}${octave}"><span class="piano-key-label">${conv.idxToNote[pc]}</span></button>`;
        let black = "";
        if (blackAfter.has(pc)) {
          const accidentalPc = blackPc[pc];
          black = `<button type="button" class="piano-key piano-black-key${activeSet.has(accidentalPc) ? " is-active" : ""}${rootIdx === accidentalPc ? " is-root" : ""}${bassIdx === accidentalPc ? " is-bass" : ""}" data-piano-pc="${accidentalPc}" data-piano-octave="${octave}" aria-label="${conv.idxToNote[accidentalPc]}${octave}"><span class="piano-key-label">${conv.idxToNote[accidentalPc]}</span></button>`;
        }
        return `<div class="piano-white-wrap">${white}${black}</div>`;
      }).join("");
      htmlParts.push(`<section class="piano-section"><div class="piano-section-head"><div><strong>${window.__("piano_title")}</strong><span class="piano-caption">${window.__("piano_hint")}</span></div><button type="button" class="chord-play-button" id="chord-play-result"><span aria-hidden="true">▶</span> ${window.__("play_chord")}</button></div><div class="mini-keyboard piano-keyboard">${keys}</div><div class="piano-legend"><span><i class="legend-root"></i>${window.__("root_label")}</span><span><i class="legend-bass"></i>${window.__("bass_tone")}</span><span><i class="legend-tone"></i>${window.__("chord_tone")}</span><span class="piano-range">C4 — B5</span></div></section>`);

      targetEl.innerHTML = htmlParts.join("");
      targetEl.querySelector("#chord-play-result")?.addEventListener("click", () => {
        const { freqs } = chordNotesToFrequencies(displayNotes, isSlash ? 3 : 4, false, null);
        playChord(freqs);
      });
      targetEl.querySelectorAll("[data-piano-pc]").forEach((key) => {
        key.addEventListener("click", () => {
          playChord([semitoneToFreq(Number(key.dataset.pianoPc), Number(key.dataset.pianoOctave))], 0.7);
        });
      });
      return;
    }

    // 退回到 parse（只显示 chord 与 notes，忽略 offsets）
    try {
      const data = conv.parseAndGetNotes(v);
      const display = {
        chord: data.chord,
        notes: data.notes,
        voicing: data.voicing,
        isSlash: data.isSlash,
      };
      targetEl.innerHTML = `<h3>${window.__f("chord_parse_heading", { input: v })}</h3><pre>${JSON.stringify(display, null, 2)}</pre>`;
    } catch (e) {
      targetEl.innerHTML = `<h3>${window.__("chord_parse_error")}</h3><pre>${e.message}</pre>`;
    }
  }

  // helper: create a card element for a scale suggestion (name,reason,notes)
  function createScaleCard(scale) {
    const card = document.createElement("div");
    card.className = "result-card";
    const title = document.createElement("div");
    title.className = "card-title";
    title.textContent = scale.name;
    card.appendChild(title);
    if (scale.reasonId != null) {
      const reason = document.createElement("div");
      reason.className = "small-muted";
      reason.textContent = window.__("reason_" + scale.reasonId);
      card.appendChild(reason);
    }
    if (scale.notes && scale.notes.length) {
      // grid view
      const noteRow = document.createElement("div");
      noteRow.className = "note-grid";
      scale.notes.forEach((n) => {
        const nc = document.createElement("div");
        nc.className = "note-cell";
        nc.innerHTML = `<div class="note">${n}</div>`;
        noteRow.appendChild(nc);
      });
      card.appendChild(noteRow);
    }
    return card;
  }

  // helper: render a full report object into nicely formatted HTML
  function renderReport(report) {
    if (!report) return document.createTextNode("");
    const cont = document.createElement("div");
    cont.className = "full-report";
    // chord name
    const h = document.createElement("h3");
    h.textContent = report.chordName || "";
    cont.appendChild(h);
    // notes grid
    if (report.notes && report.notes.length) {
      const notesDiv = document.createElement("div");
      notesDiv.className = "note-grid";
      report.notes.forEach((n) => {
        const nc = document.createElement("div");
        nc.className = "note-cell";
        nc.innerHTML = `<div class="note">${n}</div>`;
        notesDiv.appendChild(nc);
      });
      cont.appendChild(notesDiv);
    }
    // voicings
    if (report.voicings) {
      const vsec = document.createElement("div");
      vsec.className = "report-section";
      const vt = document.createElement("div");
      vt.className = "section-title";
      vt.textContent = window.__("voicings_label") || "Voicings";
      vsec.appendChild(vt);
      ["shell", "drop2"].forEach((k) => {
        if (report.voicings[k]) {
          const row = document.createElement("div");
          row.className = "note-grid";
          report.voicings[k].forEach((n) => {
            const nc = document.createElement("div");
            nc.className = "note-cell";
            nc.innerHTML = `<div class="note">${n}</div>`;
            row.appendChild(nc);
          });
          const label = document.createElement("div");
          label.className = "small-muted";
          label.textContent = window.__("voicings_" + k) || k;
          vsec.appendChild(label);
          vsec.appendChild(row);
        }
      });

      cont.appendChild(vsec);
    }
    // substitutions
    if (report.substitutions && report.substitutions.length) {
      const ssec = document.createElement("div");
      ssec.className = "report-section";
      const st = document.createElement("h3");
      st.className = "section-title";
      st.textContent = window.__("substitutions_label") || "Substitutions";
      ssec.appendChild(st);
      report.substitutions.forEach((sub) => {
        const card = createScaleCard({
          name: sub.name,
          reason: window.__("sub_type_name_" + sub.descriptionId) || sub.type,
          notes: [],
        });
        const desc = document.createElement("div");
        desc.className = "small-muted";
        desc.textContent =
          window.__("sub_type_desc_" + sub.descriptionId) || sub.description;
        card.appendChild(desc);
        ssec.appendChild(card);
      });
      cont.appendChild(ssec);
    }
    return cont;
  }

  function updateBlues(targetEl, inputValue) {
    mountBluesToolbox(targetEl, inputValue, { brain, conv, playChord, semitoneToFreq });
  }

  function updateCST(targetEl, inputValue) {
    mountJazzToolbox(targetEl, inputValue, { conv, playChord, semitoneToFreq });
  }

  function updateLCC(targetEl, inputValue) {
    mountLccExplorer(targetEl, inputValue, { brain, conv, playChord, semitoneToFreq });
  }

  function updateRec(targetEl, inputValue) {
    const v = inputValue.trim();
    if (!v) {
      targetEl.innerHTML = `<div class="result-card">${window.__("cannot_parse_input") || "无法解析输入 请输入有效和弦（如 C7、Am9）"}</div>`;
      return;
    }

    // 调用 JazzBrain 的和弦推荐方法
    let recommendations = [];
    try {
      recommendations = brain.getChordRecommendations(v);
    } catch (e) {
      console.error("get chord scale failure:", e);
      targetEl.innerHTML = `<div class="result-card">${window.__("parse_error") || "解析失败 "}${e.message}</div>`;
      return;
    }

    // 清空目标容器并渲染结果
    targetEl.innerHTML = "";

    // 结果头部统计
    const headerRec = document.createElement("div");
    headerRec.className = "small-muted";
    headerRec.textContent =
      window.__f("header_rec", {
        count: recommendations.length,
        input: v,
      }) ||
      window.__f("rec_count", {
        input1: v,
        input2: recommendations.length,
      });
    targetEl.appendChild(headerRec);

    // 遍历推荐结果渲染卡片
    recommendations.forEach((item, idx) => {
      const card = document.createElement("div");
      card.className = "result-card rec-card";

      // 按评分线性渐变（从高分蓝绿 → 低分浅红，连续过渡）
      // 按评分线性渐变（高分：深青绿 → 低分：暗赤红，高级暗调风格）
      const scoreNorm = item.score / 15; // 归一化到 0-1

      // 1. 色相（Hue）线性过渡：175(深青绿) → 25(暗赤红)（更贴合参考界面的色调）
      const hueMin = 25; // 低分：暗赤红（替代原浅红，更暗更高级）
      const hueMax = 175; // 高分：深青绿（匹配参考界面的主色调）
      const hue = hueMin + (hueMax - hueMin) * scoreNorm;

      // 2. 饱和度（Saturation）：整体低饱和（高级感核心），高分略低、低分略高
      const satStartMin = 28; // 低分起始饱和度（低饱和）
      const satStartMax = 22; // 高分起始饱和度（更低饱和）
      const satStart = satStartMin + (satStartMax - satStartMin) * scoreNorm;

      const satEndMin = 18; // 低分结束饱和度
      const satEndMax = 12; // 高分结束饱和度
      const satEnd = satEndMin + (satEndMax - satEndMin) * scoreNorm;

      // 3. 亮度（Lightness）：极致暗调，整体下调到 15-22 区间（核心暗调调整）
      const lightStartMin = 10; // 低分起始亮度（暗）
      const lightStartMax = 6; // 高分起始亮度（更暗，匹配参考界面）
      const lightStart =
        lightStartMin + (lightStartMax - lightStartMin) * scoreNorm;

      const lightMidMin = 18; // 低分中间亮度
      const lightMidMax = 16; // 高分中间亮度
      const lightMid = lightMidMin + (lightMidMax - lightMidMin) * scoreNorm;

      const lightEndMin = 15; // 低分结束亮度（极暗）
      const lightEndMax = 13; // 高分结束亮度（极致暗）
      const lightEnd = lightEndMin + (lightEndMax - lightEndMin) * scoreNorm;
      // 多色阶线性渐变（从左上到右下，3个色阶过渡，渐变更自然）
      card.style.background = `linear-gradient(135deg, 
        hsl(${hue}, ${satStart}%, ${lightStart}%), 
        hsl(${hue + 5}, ${(satStart + satEnd) / 2}%, ${lightMid}%) 50%, 
        hsl(${hue + 8}, ${satEnd}%, ${lightEnd}%)
      )`;

      // 卡片标题（和弦名 + 综合评分）
      const title = document.createElement("div");
      title.className = "card-title";
      title.innerHTML = `${item.chord} 
        <span class="score-badge">${window.__("sort_score") || "Score"}: ${item.score}</span>`;
      card.appendChild(title);

      // 核心指标行
      const metricsRow = document.createElement("div");
      metricsRow.style.display = "flex";
      metricsRow.style.gap = "12px";
      metricsRow.style.margin = "8px 0";
      metricsRow.style.fontSize = "0.9em";

      // 稳定性
      const stabilitySpan = document.createElement("span");
      stabilitySpan.textContent = `${window.__("sort_stability") || "Stability"}: ${item.stability.toFixed(1)}`;
      // 紧张度
      const tensionSpan = document.createElement("span");
      tensionSpan.textContent = `${window.__("sort_tension") || "Tension"}: ${item.tension.toFixed(1)}`;
      // 明亮度
      const brightnessSpan = document.createElement("span");
      brightnessSpan.textContent = `${window.__("brightness_label") || "Brightness"}: ${item.brightness.toFixed(1)}`;

      metricsRow.appendChild(stabilitySpan);
      metricsRow.appendChild(tensionSpan);
      metricsRow.appendChild(brightnessSpan);
      card.appendChild(metricsRow);

      // 来源标注（Formula/Creative）
      const sourceSpan = document.createElement("div");
      sourceSpan.className = "small-muted";
      sourceSpan.textContent = `${window.__("source_label") || "来源"}: ${item.source}`;
      card.appendChild(sourceSpan);

      // 和弦音符网格（复用现有 note-grid 样式）
      const noteRow = document.createElement("div");
      noteRow.className = "note-grid";
      item.notes.forEach((n) => {
        const nc = document.createElement("div");
        nc.className = "note-cell";
        nc.innerHTML = `<div class="note">${n}</div>`;
        noteRow.appendChild(nc);
      });
      card.appendChild(noteRow);

      targetEl.appendChild(card);
    });
  }

  // generic processor for the other-panel actions
  function processOther(targetEl, inputValue) {
    const v = inputValue.trim();
    targetEl.innerHTML = "";
    try {
      switch (currentOtherMode) {
        case "key_center": {
          // 1. 获取输入并分析
          const arr = parseChordList(v);
          const results = brain.findKeyCenterPro(arr, true);

          if (Array.isArray(results) && results.length) {
            results.forEach(function (result, index) {
              // const result = results[0]; // 获取匹配度最高的调性
              const parts = result.name.split(" ");
              const root = parts[0];
              const sysName = parts.slice(1).join(" ").trim();

              let notes = [];
              try {
                notes = brain.cst.scaleNotes(root, sysName);
              } catch (e) {
                notes = [];
              }

              // 2. 创建卡片容器
              const card = document.createElement("div");
              card.className = "result-card";

              try {
                const sp = Number(feel.spiciness_level || 0);
                let hue = 200,
                  sat = 20,
                  top = 30,
                  bot = 26;
                if (sp <= 1) {
                  hue = 200;
                  sat = 18;
                  top = 30;
                  bot = 26;
                } else if (sp <= 3) {
                  hue = 38;
                  sat = 20;
                  top = 32;
                  bot = 26;
                } else if (sp <= 5) {
                  hue = 18;
                  sat = 24;
                  top = 34;
                  bot = 28;
                } else {
                  hue = 300;
                  sat = 20;
                  top = 34;
                  bot = 26;
                }
                card.style.background = `linear-gradient(135deg, hsl(${hue}, ${sat}%, ${top}%), hsl(${hue}, ${Math.max(sat - 4, 8)}%, ${bot}%))`;
              } catch (e) { }

              // 4. 构建标题和评分
              const title = document.createElement("div");
              title.className = "card-title";
              title.innerHTML = `<span>${result.name}</span> <span class="spice-badge" style="margin-left:8px; font-size:0.8em; opacity:0.8;">${window.__("key_center_match_score") || "Score"}: ${Math.round(result.score)}</span>`;

              const noteRow = document.createElement("div");
              noteRow.className = "note-grid";
              (notes || []).forEach((n) => {
                const nc = document.createElement("div");
                nc.className = "note-cell";
                nc.innerHTML = `<div class="note">${n}</div>`;
                noteRow.appendChild(nc);
              });

              // 6. 组合元素
              card.appendChild(title);

              // 如果有原因/描述，也可以加上
              const reason = document.createElement("div");
              reason.className = "small-muted";
              reason.style.marginBottom = "8px";
              reason.textContent = `${window.__("key_center_detected") || "Detected Key Center"}`;
              card.appendChild(reason);

              card.appendChild(noteRow);

              // targetEl.innerHTML = "";
              targetEl.appendChild(card);
            });
          } else {
            targetEl.innerHTML = `<div class="small-muted">${window.__("no_key_recommended") || "no key recommended"}</div>`;
          }
          break;
        }
        case "report": {
          const card = document.createElement("div");
          card.className = "result-card";

          try {
            const sp = Number(feel.spiciness_level || 0);
            let hue = 200,
              sat = 20,
              top = 30,
              bot = 26;
            if (sp <= 1) {
              hue = 200;
              sat = 18;
              top = 30;
              bot = 26;
            } else if (sp <= 3) {
              hue = 38;
              sat = 20;
              top = 32;
              bot = 26;
            } else if (sp <= 5) {
              hue = 18;
              sat = 24;
              top = 34;
              bot = 28;
            } else {
              hue = 300;
              sat = 20;
              top = 34;
              bot = 26;
            }
            card.style.background = `linear-gradient(135deg, hsl(${hue}, ${sat}%, ${top}%), hsl(${hue}, ${Math.max(sat - 4, 8)}%, ${bot}%))`;
          } catch (e) { }

          // 1. 获取完整的分析报告数据
          const report = brain.getFullReport(v);

          // 3. 添加标题
          const header = document.createElement("h3");
          header.textContent =
            window.__("other_report") || "Chord Analysis Report";
          card.appendChild(header);

          // 4. 调用你定义的 renderReport 函数进行美化渲染
          if (report) {
            const reportElement = renderReport(report);
            card.appendChild(reportElement);
          } else {
            const noData = document.createElement("div");
            noData.className = "small-muted";
            noData.textContent =
              window.__("no_data_available") || "No analysis data found.";
            card.appendChild(noData);
          }
          targetEl.appendChild(card);
          break;
        }
        case "progression": {
          const prog = parseChordList(v);
          const analysis = brain.analyzeProgression(prog); // 假设返回的是字符串数组

          targetEl.innerHTML = ""; // 清空容器
          const container = document.createElement("div");
          container.className = "progression-stepper";
          container.style.display = "flex";
          container.style.flexDirection = "column";
          container.style.gap = "12px";

          if (Array.isArray(analysis) && analysis.length > 0) {
            analysis.forEach((step, index) => {
              const row = document.createElement("div");
              row.className = "result-card";
              row.style.margin = "0";
              row.style.borderLeft = "4px solid var(--accent)"; // 左侧色条增加专业感

              // 提取 "Cmaj7 -> Fmaj7" 这种核心部分加粗
              const parts = step.split(":");
              const flow = parts[0] || "";
              const desc = parts[1] || "";

              row.innerHTML = `
						<div style="display:flex; align-items:center; gap:10px;">
							<div class="step-badge" style="background:var(--accent); color:#fff; border-radius:50%; width:24px; height:24px; display:flex; align-items:center; justify-content:center; font-size:12px;">${index + 1}</div>
							<div style="font-weight:bold; color:var(--accent-2); font-size:1.1em;">${flow}</div>
						</div>
						<div class="small-muted" style="margin-top:8px; padding-left:34px;">${window.__("motion_dominant_label") || desc.trim()}</div>
					`;
              container.appendChild(row);
            });
            targetEl.appendChild(container);
          } else {
            targetEl.innerHTML = `<div class="small-muted">Could not analyze this progression.</div>`;
          }
          break;
        }
        case "negative": {
          // 负和声：使用两个输入框，一个是和弦 (other-input)，一个是轴 (other-axis-input)
          const chord = v;
          const axisInput = document.getElementById("other-axis-input");
          const axisRaw = axisInput ? axisInput.value : "";
          const axis = (axisRaw && axisRaw.trim()) || "C";

          // 1. 数据准备
          const chord_keys = brain.converter._ensureNotesAndRoot(chord);
          const negResult = brain.toNegative(chord, axis);
          // 注意：假设 negResult 返回的是 ['F', 'D', 'Bb', 'G'] 或包含 notes 属性的对象
          const neg_notes = Array.isArray(negResult)
            ? negResult
            : negResult.notes || [];
          const neg_name = negResult.negative || "Negative Chord";

          targetEl.innerHTML = "";

          // 2. 创建主卡片
          const card = document.createElement("div");
          card.className = "result-card";
          // 使用深蓝色到深紫色的渐变，营造一种“镜像”或“深夜”的乐理氛围
          card.style.background =
            "linear-gradient(135deg, hsl(230, 25%, 15%), hsl(260, 20%, 12%))";
          card.style.border = "1px solid rgba(255,255,255,0.1)";

          // 3. 头部信息
          const header = document.createElement("div");
          header.style.textAlign = "center";
          header.style.marginBottom = "20px";
          header.innerHTML = `
				<div class="small-muted" style="letter-spacing: 2px; text-transform: uppercase; font-size: 0.75rem;">${window.__("neg_harmony_title")}</div>
				<div style="font-size: 0.9rem; color: var(--accent-2); margin-top: 4px;">${window.__("neg_axis") || "Axis"}: <span style="font-weight: bold; color: #fff;">${axis} / ${brain.converter.idxToNote[(brain.converter.noteToIdx[axis] + 7) % 12]}</span></div>
			`;
          card.appendChild(header);

          // 4. 镜像对比区域
          const comparison = document.createElement("div");
          comparison.style.display = "flex";
          comparison.style.alignItems = "center";
          comparison.style.justifyContent = "space-between";
          comparison.style.gap = "10px";

          // 创建左右音符列的函数
          const createNoteColumn = (
            title,
            chordName,
            notes,
            isNegative = false,
          ) => {
            const col = document.createElement("div");
            col.style.flex = "1";
            col.style.textAlign = "center";

            const label = document.createElement("div");
            label.className = "small-muted";
            label.textContent = title;
            col.appendChild(label);

            const name = document.createElement("div");
            name.style.fontSize = "1.4rem";
            name.style.fontWeight = "bold";
            name.style.margin = "5px 0 15px 0";
            name.style.color = isNegative ? "var(--accent-2)" : "#fff";
            name.textContent = chordName;
            col.appendChild(name);

            const grid = document.createElement("div");
            grid.className = "note-grid";
            grid.style.justifyContent = "center";
            notes.forEach((n) => {
              const cell = document.createElement("div");
              cell.className = "note-cell";
              if (isNegative) cell.style.borderColor = "var(--accent-2)";
              cell.innerHTML = `<div class="note">${n}</div>`;
              grid.appendChild(cell);
            });
            col.appendChild(grid);
            return col;
          };

          // 原和声列
          comparison.appendChild(
            createNoteColumn(
              window.__("neg_original") || "Original",
              chord,
              chord_keys,
            ),
          );

          // 中间箭头
          const arrow = document.createElement("div");
          arrow.style.fontSize = "1.5rem";
          arrow.style.color = "var(--accent)";
          arrow.style.opacity = "0.6";
          arrow.innerHTML = "⇄";
          comparison.appendChild(arrow);

          // 负和声列
          comparison.appendChild(
            createNoteColumn(
              window.__("neg_negative") || "Negative",
              neg_name,
              neg_notes,
              true,
            ),
          );

          card.appendChild(comparison);
          targetEl.appendChild(card);
          break;
        }
        case "guide": {
          const prog = parseChordList(v);
          const path = brain.getGuideTonePath(prog); // 假设返回 [[3, 7], [3, 7]...]

          targetEl.innerHTML = "";
          const container = document.createElement("div");
          container.className = "guide-tone-path";
          container.style.display = "flex";
          container.style.flexDirection = "column";
          container.style.gap = "15px";
          container.style.padding = "10px";

          path.forEach((tones, index) => {
            const chordName = prog[index] || `Chord ${index + 1}`;
            const row = document.createElement("div");
            row.className = "result-card";
            row.style.margin = "0";
            row.style.display = "flex";
            row.style.alignItems = "center";
            row.style.background = "linear-gradient(90deg, #1a1a2e, #16213e)";

            // 左侧：和弦名称
            const nameLabel = document.createElement("div");
            nameLabel.style.width = "80px";
            nameLabel.style.fontWeight = "bold";
            nameLabel.style.color = "var(--accent-2)";
            nameLabel.textContent = chordName;

            // 中间：导音对 (通常是 3音 和 7音)
            const tonesGrid = document.createElement("div");
            tonesGrid.style.display = "flex";
            tonesGrid.style.gap = "10px";
            tonesGrid.style.flex = "1";
            tonesGrid.style.justifyContent = "center";

            tones.forEach((note, i) => {
              const cell = document.createElement("div");
              cell.className = "note-cell";
              // 给 3音和 7音上点不同的色（假设顺序是 3, 7）
              if (i === 0) cell.style.borderColor = "var(--accent)";
              cell.innerHTML = `<div class="note">${note}</div><small style="font-size:9px; opacity:0.5; display:block; margin-top:2px;">${i === 0 ? "3rd" : "7th"}</small>`;
              tonesGrid.appendChild(cell);
            });

            row.appendChild(nameLabel);
            row.appendChild(tonesGrid);

            // 右侧：连接箭头 (除了最后一个)
            if (index < path.length - 1) {
              const arrow = document.createElement("div");
              arrow.style.textAlign = "center";
              arrow.style.color = "var(--accent)";
              arrow.style.padding = "5px";
              arrow.innerHTML = `↓ <span style="font-size:0.7em; opacity:0.6;">${window.__("voice_leading_label") || "Voice Leading"}</span>`;

              container.appendChild(row);
              container.appendChild(arrow);
            } else {
              container.appendChild(row);
            }
          });

          targetEl.appendChild(container);
          break;
        }
      }
    } catch (e) {
      targetEl.innerHTML = `<h3>${window.__("other_error")}</h3><pre>${e.message}</pre>`;
    }
  }

  // helper: parse comma-separated or JSON list of chords/objects
  function parseChordList(input) {
    const t = input.trim();
    if (t.startsWith("[")) {
      try {
        return JSON.parse(t);
      } catch (e) { }
    }
    return t
      .split(";")
      .map((s) => s.trim())
      .filter((s) => s);
  }

  // helpers for key-center dynamic inputs
  function createKeyCenterEntry(value = "") {
    const div = document.createElement("div");
    div.className = "kc-chord-entry";
    div.style.display = "flex";
    div.style.alignItems = "center";
    div.style.marginBottom = "4px";

    const input = document.createElement("input");
    input.type = "text";
    input.className = "kc-chord";
    input.value = value;
    input.style.flex = "1";

    const btn = document.createElement("button");
    btn.type = "button";
    btn.textContent = "-";
    btn.title = window.__("remove_chord") || "Remove Chord";
    btn.style.marginLeft = "6px";
    btn.addEventListener("click", () => {
      div.remove();
    });

    div.appendChild(input);
    div.appendChild(btn);
    return div;
  }

  function setKeyCenterChords(arr) {
    const container = document.getElementById("keycenter-inputs");
    // remove existing entries (but keep the add button as last child)
    Array.from(container.querySelectorAll(".kc-chord-entry")).forEach((e) =>
      e.remove(),
    );
    arr.forEach((v) => {
      const entry = createKeyCenterEntry(v);
      container.insertBefore(
        entry,
        document.getElementById("add-keycenter-chord"),
      );
    });
  }

  function getKeyCenterValue() {
    const container = document.getElementById("keycenter-inputs");
    const chords = Array.from(container.querySelectorAll(".kc-chord"))
      .map((i) => i.value.trim())
      .filter((s) => s);

    return chords.join(";");
  }

  // Navigation binding: show only selected feature
  navButtons.forEach((b) =>
    b.addEventListener("click", () => showOnlyFeature(b.dataset.feature)),
  );
  navButtons.forEach((button, index) => {
    button.setAttribute('role', 'tab');
    button.id = `tab-${button.dataset.feature}`;
    button.setAttribute('aria-controls', `panel-${button.dataset.feature}`);
    document.getElementById(`panel-${button.dataset.feature}`).setAttribute('aria-labelledby', button.id);
    button.addEventListener('keydown', event => {
      let next;
      if (event.key === 'ArrowDown' || event.key === 'ArrowRight') next = (index + 1) % navButtons.length;
      if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') next = (index - 1 + navButtons.length) % navButtons.length;
      if (event.key === 'Home') next = 0;
      if (event.key === 'End') next = navButtons.length - 1;
      if (next === undefined) return;
      event.preventDefault();
      navButtons[next].focus();
      navButtons[next].click();
    });
  });
  // initialize other panel mode buttons
  initOtherControls();

  // setup additional controls for "other" panel
  function initOtherControls() {
    const modes = ["key_center", "report", "progression", "negative", "guide"];
    const row = document.getElementById("other-action-row");
    const buttons = {};
    modes.forEach((mode) => {
      const btn = document.createElement("button");
      btn.className = "panel-action";
      btn.textContent = window.__(`other_mode_${mode}`);
      btn.addEventListener("click", () => setOtherMode(mode));
      row.appendChild(btn);
      buttons[mode] = btn;
    });

    // default examples for each mode
    const sampleInputs = {
      key_center: "Cmaj7,Ebdim7,Dm7,G7",
      report: "C7",
      progression: "Cmaj7,Fmaj7,G7,Cmaj7",
      // 负和声：和弦与轴拆成两个输入框，这里只保留和弦示例
      negative: "Dm7 add b13 omit 5/C",
      guide: "Dm7,G7,Cmaj7",
    };

    function setOtherMode(mode) {
      currentOtherMode = mode;
      modes.forEach((m) => buttons[m].classList.toggle("active", m === mode));
      const labelEl = document.getElementById("label_other_example");
      const newText =
        window.__(`label_other_example_${mode}`) ||
        window.__("label_other_example");
      labelEl.textContent = newText;

      const inputEl = document.getElementById("other-input");
      const kcContainer = document.getElementById("keycenter-inputs");
      const axisRow = document.getElementById("negative-axis-row");
      const axisInput = document.getElementById("other-axis-input");

      // key_center / progression / guide 三种模式用“可增删”的和弦列表排版
      const useChordList =
        mode === "key_center" || mode === "progression" || mode === "guide";

      // 负和声模式：使用两个输入框（和弦 + 轴）
      if (mode === "negative") {
        inputEl.style.display = "";
        kcContainer.style.display = "none";
        if (axisRow) axisRow.style.display = "block";
        if (sampleInputs[mode] !== undefined)
          inputEl.value = sampleInputs[mode];
        if (axisInput && !axisInput.value) axisInput.value = "C";
      } else {
        if (axisRow) axisRow.style.display = "none";
        if (useChordList) {
          // 显示可增删列表，隐藏单行输入
          inputEl.style.display = "none";
          kcContainer.style.display = "block";
          const example = sampleInputs[mode] || "";
          const arr = example
            .split(",")
            .map((s) => s.trim())
            .filter((s) => s);
          setKeyCenterChords(arr);
        } else {
          inputEl.style.display = "";
          kcContainer.style.display = "none";
          if (sampleInputs[mode] !== undefined)
            inputEl.value = sampleInputs[mode];
        }
      }
    }

    setOtherMode(currentOtherMode);
  }

  // ===================== 新里曼面板渲染 =====================
  // ===================== 新里曼面板渲染（树型布局 + 右键拖拽节点 + 节点大小调节）=====================
  let neoCanvasCleanup = null;
  let neoCurrentView = 'tonnetz';
  let neoCurrentDepth = 1;
  let neoCurrentInput = "";
  let neoLayerSpacing = 100;      // 层间垂直间距
  let neoNodeSize = 22;           // 节点半径
  let neoCanvasState = { offsetX: 0, offsetY: 0, scale: 1 };
  let neoNodeOffsets = {};        // 手动偏移 { nodeId: {x, y} }
  let neoHarmonyViewState = { zoom: 1, panX: 0, panY: 0 };

  // 基本操作集
  const PRIMARY_OPS = new Set(["P", "L", "R", "S", "N", "D1"]);

  function updateNeo(targetEl, inputValue) {
    neoCanvasCleanup?.();
    neoCanvasCleanup = null;
    const v = inputValue.trim();
    if (!v) {
      targetEl.innerHTML = `<div class="result-card">${window.__("cannot_parse_input")}</div>`;
      return;
    }

    neoCurrentInput = v;
    neoCanvasState = { offsetX: 0, offsetY: 0, scale: 1 };
    neoNodeOffsets = {};

    let geometric = {};
    if (neoCurrentView !== 'harmony') {
      try {
        geometric = brain.nrt.getGeometricNeighbors(v);
      } catch (e) {
        if (neoCurrentView !== 'all') {
          targetEl.innerHTML = `<div class="result-card">${window.__("chord_parse_error")}: ${e.message}</div>`;
          return;
        }
      }
    }

    targetEl.innerHTML = "";

    // ---------- 可视化切换按钮 ----------
    const vizRow = document.createElement('div');
    vizRow.className = 'neo-view-switch';
    const neoGroup = document.createElement('div'); neoGroup.className = 'neo-view-group';
    const neoGroupLabel = document.createElement('span'); neoGroupLabel.textContent = window.__('neo_sublevel');
    neoGroup.appendChild(neoGroupLabel);
    const viewButtons = new Map();
    for (const [view, label, parent] of [
      ['tonnetz', window.__('neo_triad_title'), neoGroup],
      ['octatonic', window.__('neo_octatonic_title'), neoGroup],
      ['harmony', window.__('neo_harmony_title'), vizRow],
      ['all', window.__('neo_all_title'), vizRow],
    ]) {
      const button = document.createElement('button'); button.type = 'button';
      button.className = 'panel-action'; button.dataset.view = view; button.textContent = label;
      viewButtons.set(view, button); parent.appendChild(button);
    }
    // Keep the nested Neo-Riemannian controls first in the reading order.
    vizRow.prepend(neoGroup);
    targetEl.appendChild(vizRow);

    // 可视化容器
    const canvasContainer = document.createElement("div");
    canvasContainer.id = "neo-canvas-container";
    canvasContainer.style.width = "100%";
    canvasContainer.style.minHeight = "500px";
    canvasContainer.style.position = "relative";
    canvasContainer.style.overflow = "hidden";
    canvasContainer.style.borderRadius = "12px";
    canvasContainer.style.background = "rgba(0,0,0,0.2)";
    canvasContainer.style.cursor = "grab";
    canvasContainer.style.userSelect = "none";
    targetEl.appendChild(canvasContainer);

    // 图例/详情区
    const detailArea = document.createElement("div");
    detailArea.id = "neo-detail-area";
    detailArea.style.marginTop = "16px";
    detailArea.className = "neo-detail-area";
    targetEl.appendChild(detailArea);

    // 绑定控件
    const depthInput = document.getElementById("neo-depth-input");
    const spacingInput = document.getElementById("neo-spacing-input");
    const nodeSizeInput = document.getElementById("neo-node-size-input");
    const nodeSizeVal = document.getElementById("neo-node-size-val");
    const applyBtn = document.getElementById("neo-depth-apply");

    if (depthInput) depthInput.value = neoCurrentDepth;
    if (spacingInput) spacingInput.value = neoLayerSpacing;
    if (nodeSizeInput) {
      nodeSizeInput.value = neoNodeSize;
      if (nodeSizeVal) nodeSizeVal.textContent = neoNodeSize;
      nodeSizeInput.oninput = () => {
        neoNodeSize = parseInt(nodeSizeInput.value) || 22;
        if (nodeSizeVal) nodeSizeVal.textContent = neoNodeSize;
        renderCurrent();
      };
    }

    const applyDepthAndRender = () => {
      if (depthInput) {
        neoCurrentDepth = Math.max(1, Math.min(10, parseInt(depthInput.value) || 1));
        depthInput.value = neoCurrentDepth;
      }
      if (spacingInput) {
        neoLayerSpacing = Math.max(50, Math.min(250, parseInt(spacingInput.value) || 100));
        spacingInput.value = neoLayerSpacing;
      }
      neoCanvasState = { offsetX: 0, offsetY: 0, scale: 1 };
      neoNodeOffsets = {};
      renderCurrent();
    };

    if (applyBtn) applyBtn.onclick = applyDepthAndRender;
    if (depthInput) depthInput.onkeydown = e => { if (e.key === "Enter") applyDepthAndRender(); };
    if (spacingInput) spacingInput.onkeydown = e => { if (e.key === "Enter") applyDepthAndRender(); };

    // 重置视图
    document.getElementById("neo-reset-view").onclick = () => {
      neoCanvasState = { offsetX: 0, offsetY: 0, scale: 1 };
      neoNodeOffsets = {};
      renderCurrent();
    };

    // 重置节点位置
    document.getElementById("neo-reset-positions").onclick = () => {
      neoNodeOffsets = {};
      renderCurrent();
    };

    // ---------- 渲染函数 ----------
    let currentView = neoCurrentView;

    function renderTonnetzMulti() {
      canvasContainer.innerHTML = "";
      detailArea.innerHTML = "";

      const multiGraph = buildTreeGraph(v, neoCurrentDepth, "tonnetz");
      if (!multiGraph || !multiGraph.nodes.length) {
        canvasContainer.innerHTML = `<div class="small-muted" style="padding:20px;">${window.__("neo_no_transform")}</div>`;
        return;
      }

      drawTreeCanvas(canvasContainer, multiGraph, "tonnetz");

      const uniqueChords = [...new Set(multiGraph.nodes.map(n => n.chord))];
      const listTitle = document.createElement("h4");
      listTitle.className = "section-title";
      listTitle.textContent = `${window.__("neo_triad_title")} (${neoCurrentDepth}层, ${uniqueChords.length}个和弦)`;
      detailArea.appendChild(listTitle);
      detailArea.appendChild(createChordCard(v, true));

      const byDepth = {};
      multiGraph.nodes.forEach(n => {
        if (n.depth > 0) {
          if (!byDepth[n.depth]) byDepth[n.depth] = [];
          byDepth[n.depth].push(n);
        }
      });

      Object.keys(byDepth).sort((a, b) => a - b).forEach(depth => {
        const depthLabel = document.createElement("div");
        depthLabel.className = "small-muted";
        depthLabel.style.marginTop = "12px";
        depthLabel.style.fontWeight = "bold";
        depthLabel.textContent = `第 ${depth} 层`;
        detailArea.appendChild(depthLabel);

        const depthGrid = document.createElement("div");
        depthGrid.style.display = "flex";
        depthGrid.style.flexWrap = "wrap";
        depthGrid.style.gap = "8px";

        byDepth[depth].forEach(node => {
          const chordCard = createChordCard(node.chord, false);
          if (node.operation) {
            const opLabel = document.createElement("div");
            opLabel.className = "small-muted";
            opLabel.style.fontSize = "0.7em";
            const isPrimary = PRIMARY_OPS.has(node.operation);
            opLabel.style.color = isPrimary ? "hsl(145, 55%, 55%)" : "hsl(260, 50%, 70%)";
            opLabel.textContent = `← ${node.operation}${isPrimary ? '' : window.__("neo_extended")}`;
            chordCard.insertBefore(opLabel, chordCard.firstChild);
          }
          depthGrid.appendChild(chordCard);
        });
        detailArea.appendChild(depthGrid);
      });
    }

    function renderOctatonicMulti() {
      canvasContainer.innerHTML = "";
      detailArea.innerHTML = "";

      const multiGraph = buildTreeGraph(v, neoCurrentDepth, "octatonic");
      if (!multiGraph || !multiGraph.nodes || multiGraph.nodes.length === 0) {
        canvasContainer.innerHTML = `<div class="small-muted" style="padding:20px;">${window.__("neo_no_octatonic")}</div>`;
        return;
      }

      drawTreeCanvas(canvasContainer, multiGraph, "octatonic");

      const uniqueChords = [...new Set(multiGraph.nodes.map(n => n.chord))];
      const listTitle = document.createElement("h4");
      listTitle.className = "section-title";
      listTitle.style.marginTop = "8px";
      listTitle.textContent = `${window.__("neo_octatonic_neighbors")} (${window.__f("neo_chord_depth_heading", {
        depth: neoCurrentDepth,
        chords_count: uniqueChords.length
      })}`;
      detailArea.appendChild(listTitle);

      // ===== 添加原始和弦卡片（修复：八度音阶塔现在也显示原始和弦）=====
      const originalCard = createChordCard(v, true);
      detailArea.appendChild(originalCard);

      const byDepth = {};
      multiGraph.nodes.forEach(n => {
        if (n.depth > 0) {
          if (!byDepth[n.depth]) byDepth[n.depth] = [];
          byDepth[n.depth].push(n);
        }
      });

      Object.keys(byDepth).sort((a, b) => a - b).forEach(depth => {
        const depthLabel = document.createElement("div");
        depthLabel.className = "small-muted";
        depthLabel.style.marginTop = "12px";
        depthLabel.style.fontWeight = "bold";
        depthLabel.textContent = window.__f("neo_chord_depth_heading", {
          depth: depth
        });
        detailArea.appendChild(depthLabel);
        const depthGrid = document.createElement("div");
        depthGrid.style.display = "flex";
        depthGrid.style.flexWrap = "wrap";
        depthGrid.style.gap = "8px";
        byDepth[depth].forEach(node => depthGrid.appendChild(createChordCard(node.chord, false)));
        detailArea.appendChild(depthGrid);
      });
    }

    function createChordCard(chordName, isOriginal) {
      const card = document.createElement("div");
      card.className = "result-card";
      card.style.margin = "4px";
      card.style.padding = "10px";
      card.style.cursor = "pointer";
      card.style.transition = "all 0.2s";
      if (isOriginal) {
        card.style.border = "1px solid var(--accent-2)";
        card.style.background = "linear-gradient(135deg, hsl(200, 25%, 20%), hsl(200, 20%, 12%))";
      }
      card.addEventListener("mouseenter", () => { card.style.transform = "translateY(-2px)"; card.style.boxShadow = "0 4px 12px rgba(0,0,0,0.3)"; });
      card.addEventListener("mouseleave", () => { card.style.transform = "translateY(0)"; card.style.boxShadow = "none"; });
      card.addEventListener("click", () => {
        const neoInput = document.getElementById("neo-input");
        if (neoInput) neoInput.value = chordName;
        neoCanvasState = { offsetX: 0, offsetY: 0, scale: 1 };
        neoNodeOffsets = {};
        updateNeo(canvasContainer.parentElement, chordName);
      });
      const title = document.createElement("div");
      title.className = "card-title";
      title.style.fontSize = "0.9em";
      title.style.margin = "0";
      title.textContent = chordName;
      card.appendChild(title);
      try {
        const parsed = brain.converter._ensureNotesAndRoot(chordName, true);
        if (parsed?.notes?.length) {
          const noteRow = document.createElement("div");
          noteRow.className = "note-grid";
          noteRow.style.margin = "6px 0 0 0";
          noteRow.style.gap = "4px";
          parsed.notes.slice(0, 6).forEach(n => {
            const nc = document.createElement("div");
            nc.className = "note-cell";
            nc.style.padding = "4px 6px";
            nc.style.minWidth = "auto";
            nc.style.fontSize = "0.75em";
            nc.innerHTML = `<div class="note" style="font-size:0.85em;">${n}</div>`;
            noteRow.appendChild(nc);
          });
          card.appendChild(noteRow);
        }
      } catch (e) { }
      return card;
    }

    function renderHarmony() {
      neoCanvasCleanup?.(); neoCanvasCleanup = null;
      detailArea.replaceChildren();
      neoCanvasCleanup = mountHarmonyWheel(canvasContainer, v, chord => {
        document.getElementById('neo-input').value = chord;
        updateNeo(targetEl, chord);
      }, key => window.__(key), chord => createChordCard(chord, false), neoHarmonyViewState);
    }

    function renderAll() {
      canvasContainer.replaceChildren(); detailArea.replaceChildren();
      const sources = [];
      for (const family of ['tonnetz', 'octatonic']) {
        try { sources.push({ family, graph: buildTreeGraph(v, neoCurrentDepth, family) }); }
        catch { sources.push({ family, graph: null }); }
      }
      sources.push({ family: 'harmony', graph: harmonyNeighborhood(v, neoCurrentDepth) });
      const combined = mergeConnectionGraphs(v, sources);
      drawTreeCanvas(canvasContainer, combined, 'all');
      const heading = document.createElement('h4'); heading.className = 'section-title';
      heading.textContent = `${window.__('neo_all_title')} · ${combined.nodes.length} ${window.__('neo_all_chords')}`;
      detailArea.append(heading, createChordCard(v, true));
      for (const { family, graph } of sources) {
        const section = document.createElement('section'); section.className = `neo-all-family family-${family}`;
        const title = document.createElement('h5');
        title.textContent = `${window.__({ tonnetz: 'neo_triad_title', octatonic: 'neo_octatonic_title', harmony: 'neo_harmony_title' }[family])} · ${Math.max(0, (graph?.nodes?.length || 1) - 1)}`;
        section.appendChild(title);
        const grid = document.createElement('div'); grid.className = 'neo-all-family-cards';
        graph?.nodes?.filter(node => node.depth === 1).forEach(node => grid.appendChild(createChordCard(node.chord, false)));
        if (!grid.childElementCount) grid.appendChild(document.createTextNode(window.__('neo_all_no_neighbors')));
        section.appendChild(grid); detailArea.appendChild(section);
      }
    }

    function renderCurrent() {
      viewButtons.forEach((button, view) => {
        const active = currentView === view;
        button.classList.toggle('active', active); button.setAttribute('aria-pressed', String(active));
      });
      canvasContainer.classList.toggle('is-harmony-wheel', currentView === 'harmony');
      if (currentView === 'tonnetz') renderTonnetzMulti();
      else if (currentView === 'octatonic') renderOctatonicMulti();
      else if (currentView === 'harmony') renderHarmony();
      else renderAll();
    }
    viewButtons.forEach((button, view) => button.addEventListener('click', () => {
      currentView = neoCurrentView = view;
      neoCanvasState = { offsetX: 0, offsetY: 0, scale: 1 };
      neoNodeOffsets = {};
      renderCurrent();
    }));
    if (currentView === 'tonnetz' && !(geometric.Tonnetz_PLRSND && Object.keys(geometric.Tonnetz_PLRSND).length)) {
      currentView = neoCurrentView = 'octatonic';
    }
    renderCurrent();
  }

  /**
   * 树型布局：根节点顶部，子节点向下展开
   * 类似二叉树/族谱结构，每层水平分布
   */
  function buildTreeGraph(rootChord, maxDepth, type) {
    const visited = new Set();
    const nodes = [];
    const edges = [];

    const normalize = (chord) => {
      try {
        const notes = brain.converter._ensureNotesAndRoot(chord);
        if (notes?.length) return [...notes].sort().join(',');
      } catch (e) { }
      return chord;
    };

    const rootNorm = normalize(rootChord);
    visited.add(rootNorm);

    const centerInfo = brain.converter._ensureNotesAndRoot(rootChord, true);
    nodes.push({
      id: 0,
      chord: rootChord,
      notes: centerInfo?.notes || [],
      label: rootChord.length > 8 ? rootChord.slice(0, 7) + ".." : rootChord,
      x: 0,
      y: 0,
      group: "center",
      depth: 0
    });

    let nodeId = 1;
    // BFS: 队列元素 { chord, depth, parentId, operation, childIndex, totalSiblings }
    const queue = [{ chord: rootChord, depth: 0, parentId: null, operation: null }];

    while (queue.length > 0) {
      const { chord, depth, parentId } = queue.shift();
      if (depth >= maxDepth) continue;

      let neighbors = {};
      const geo = brain.nrt.getGeometricNeighbors(chord);

      if (type === "tonnetz" && geo.Tonnetz_PLRSND) {
        // 优先排列基本操作，再排扩展操作
        const primary = [];
        const secondary = [];
        Object.entries(geo.Tonnetz_PLRSND).forEach(([op, result]) => {
          if (result.chord) {
            if (PRIMARY_OPS.has(op)) primary.push([op, result.chord]);
            else secondary.push([op, result.chord]);
          }
        });
        // 基本操作按固定顺序：P, L, R, S, N, D1
        const order = ["P", "L", "R", "S", "N", "D1"];
        primary.sort((a, b) => order.indexOf(a[0]) - order.indexOf(b[0]));
        const allNeighbors = [...primary, ...secondary];
        allNeighbors.forEach(([op, chord]) => { neighbors[op] = chord; });
      } else if (type === "octatonic" && geo.Octatonic_Tower) {
        geo.Octatonic_Tower.forEach((neighbor, i) => {
          if (neighbor) neighbors[`O${i + 1}`] = neighbor;
        });
      }

      const neighborEntries = Object.entries(neighbors);
      const totalSiblings = neighborEntries.length;
      const parentNode = nodes.find(n => n.id === parentId);
      const parentX = parentNode ? parentNode.x : 0;
      const parentY = parentNode ? parentNode.y : 0;

      // 树的水平展开宽度随深度动态调整
      const levelWidth = neoLayerSpacing * 2 + (depth + 1) * neoLayerSpacing * 0.8;
      const startX = parentX - levelWidth / 2 + levelWidth / (totalSiblings + 1);

      neighborEntries.forEach(([op, neighborChord], idx) => {
        const normNeighbor = normalize(neighborChord);

        // 计算树型位置
        const childX = startX + (idx + 1) * (levelWidth / (totalSiblings + 1));
        const childY = parentY + neoLayerSpacing;

        if (!visited.has(normNeighbor)) {
          visited.add(normNeighbor);

          let notes = [];
          try {
            const parsed = brain.converter._ensureNotesAndRoot(neighborChord, true);
            notes = parsed?.notes || [];
          } catch (e) { }

          const isPrimary = PRIMARY_OPS.has(op);
          const newNode = {
            id: nodeId,
            chord: neighborChord,
            notes: notes,
            label: op,
            operation: op,
            isPrimary: isPrimary,
            x: Math.round(childX),
            y: Math.round(childY),
            group: isPrimary ? "transform" : "secondary",
            depth: depth + 1
          };

          nodes.push(newNode);
          edges.push({
            source: parentId !== null ? parentId : 0,
            target: nodeId,
            label: op,
            depth: depth + 1,
            isPrimary: isPrimary
          });

          queue.push({
            chord: neighborChord,
            depth: depth + 1,
            parentId: nodeId,
            operation: op
          });

          nodeId++;
        } else {
          // 连接到已访问节点
          const existingNode = nodes.find(
            n => normalize(n.chord) === normNeighbor && n.id !== parentId
          );
          if (existingNode && !edges.some(
            e => (e.source === parentId && e.target === existingNode.id) ||
              (e.source === existingNode.id && e.target === parentId)
          )) {
            edges.push({
              source: parentId !== null ? parentId : 0,
              target: existingNode.id,
              label: op,
              depth: Math.max(depth + 1, existingNode.depth),
              isPrimary: PRIMARY_OPS.has(op)
            });
          }
        }
      });
    }

    return { nodes, edges, center: rootChord };
  }

  function drawTreeCanvas(container, graphData, type) {
    neoCanvasCleanup?.();
    neoCanvasCleanup = mountNeoCanvas(container, graphData, {
      size: neoNodeSize,
      spacing: neoLayerSpacing,
      family: type,
      state: neoCanvasState,
      offsets: neoNodeOffsets,
      onSelect(chord) {
        document.getElementById('neo-input').value = chord;
        updateNeo(container.parentElement, chord);
      },
    });
  }
  // ==================== 和弦音阶速查面板 ====================
  function initRefPanel() {
    const rootSelect = document.getElementById("ref-root-select");
    const scaleSelect = document.getElementById("ref-scale-select");
    const familySelect = document.getElementById("ref-family-select");
    const body = document.getElementById("panel-ref-body");

    // 检查是否已初始化（避免重复填充）
    if (rootSelect.options.length > 0) return;

    const ms = brain.cst; // MusicScale 实例

    // --- 填充根音下拉 ---
    const roots = [
      "C",
      "Db",
      "D",
      "Eb",
      "E",
      "F",
      "Gb",
      "G",
      "Ab",
      "A",
      "Bb",
      "B",
    ];
    roots.forEach((r) => {
      const opt = document.createElement("option");
      opt.value = r;
      opt.textContent = r;
      rootSelect.appendChild(opt);
    });

    // --- 填充音阶下拉 ---
    ms.scaleMode.forEach((scale) => {
      const opt = document.createElement("option");
      opt.value = scale.id;
      opt.textContent = scale.scale_name[0]; // 优先第一个名称
      scaleSelect.appendChild(opt);
    });

    // --- 填充和弦家族下拉 ---
    const families = Object.keys(ms.chordFamily);
    families.forEach((f) => {
      const opt = document.createElement("option");
      opt.value = f;
      opt.textContent = f;
      familySelect.appendChild(opt);
    });

    // ============ 音阶查询按钮 ============
    document.getElementById("ref-scale-run").addEventListener("click", () => {
      const root = rootSelect.value;
      const scaleId = scaleSelect.value;

      if (!root || !scaleId) {
        body.innerHTML = `<div class="result-card">${window.__("ref_select_root_first")}</div>`;
        return;
      }

      const scaleInfo = ms.get_scale_by_id(scaleId);
      if (!scaleInfo) {
        body.innerHTML = `<div class="result-card">Scale not found</div>`;
        return;
      }

      renderScaleDetail(body, root, scaleInfo, ms);
    });

    // ============ 和弦家族查询按钮 ============
    document.getElementById("ref-family-run").addEventListener("click", () => {
      const familyName = familySelect.value;

      if (!familyName) {
        body.innerHTML = `<div class="result-card">${window.__("ref_select_family_first")}</div>`;
        return;
      }

      renderFamilyDetail(body, familyName, ms);
    });
  }

  function jumpToScale(root, scaleId) {
    const body = document.getElementById("panel-ref-body");
    if (!body) return;

    showOnlyFeature("ref");
    initRefPanel();

    const rootSelect = document.getElementById("ref-root-select");
    const scaleSelect = document.getElementById("ref-scale-select");
    if (rootSelect && root) rootSelect.value = root;
    if (scaleSelect && scaleId) scaleSelect.value = scaleId;

    const ms = brain.cst;
    const scaleInfo = ms.get_scale_by_id(scaleId);
    if (scaleInfo) {
      renderScaleDetail(
        body,
        root || (rootSelect && rootSelect.value) || "C",
        scaleInfo,
        ms,
      );
    }
  }

  /**
   * 播放音阶（上行+下行）
   * @param {Array} scaleNotes - 音阶音符数组（不含八度信息）
   * @param {number} baseOctave - 基准八度
   * @param {number} noteDuration - 每个音符的时长（秒）
   */
  function playNoteSequence(frequencies, noteDuration = 0.15) {
    try {
      const ctx = getAudioContext();
      interruptPlayback(ctx);
      const now = ctx.currentTime;
      const dur = Math.max(0.08, noteDuration);

      frequencies.forEach((freq, index) => {
        const startTime = now + index * dur;
        const tone = createSimpleTone(ctx, freq, startTime, dur * 1.1, 0.1);
        tone.connect(audioDryBus);
      });
    } catch (e) {
      console.warn("playNoteSequence failure:", e);
    }
  }

  function scaleNoteNamesToFreqs(noteNames) {
    let lastRootMidi = null;
    const freqs = [];
    noteNames.forEach((name) => {
      const { freqs: f, rootMidi } = chordNotesToFrequencies(
        [name],
        4,
        false,
        lastRootMidi,
      );
      if (f.length) freqs.push(f[0]);
      if (rootMidi != null) lastRootMidi = rootMidi;
    });
    return freqs;
  }

  function classicalPlaybackNotes(entry) {
    return entry?.voicing?.length ? entry.voicing : (entry?.notes || []);
  }

  const classicalMidiFreqs = entry => (entry?.midiVoicing || []).map(n => 440 * 2 ** ((n - 69) / 12));

  function buildMultiModeDegreeFreqs(rows) {
    let lastRootMidi = null;
    return rows.map((row) => {
      const names = parseMultiModeNotes(row.notes);
      const { freqs, rootMidi } = chordNotesToFrequencies(
        names,
        4,
        false,
        lastRootMidi,
      );
      if (rootMidi != null) lastRootMidi = rootMidi;
      return freqs;
    });
  }

  function playMultiModeScale(noteNames) {
    if (!noteNames?.length) return;
    playNoteSequence(scaleNoteNamesToFreqs(noteNames), 0.18);
  }

  function playMultiModeFuncSequence(funcSteps) {
    if (!funcSteps?.length) return;
    try {
      const ctx = getAudioContext();
      interruptPlayback(ctx);
      const now = ctx.currentTime;
      let t = now;
      let lastRootMidi = null;
      funcSteps.forEach((step) => {
        const names = parseMultiModeNotes(step.notes);
        if (!names.length) {
          t += 0.4;
          return;
        }
        const { freqs, rootMidi } = chordNotesToFrequencies(
          names,
          4,
          false,
          lastRootMidi,
          { voiceLeading: "nearest" },
        );
        if (rootMidi != null) lastRootMidi = rootMidi;
        freqs.forEach((freq, i) => {
          const noteTime = t + i * 0.012;
          const tone = createPianoTone(ctx, freq, noteTime, 0.85);
          tone.connect(audioDryBus);
          tone.connect(audioWetBus);
        });
        t += 0.95;
      });
    } catch (e) {
      console.warn("playMultiModeFuncSequence failure:", e);
    }
  }

  function wireMultiModeDisplayAudio(displayEl, payload) {
    if (!payload || displayEl.dataset.audioWired === "1") return;
    displayEl.dataset.audioWired = "1";

    const degreeFreqs = buildMultiModeDegreeFreqs(payload.degreeRows || []);

    displayEl.addEventListener("click", (e) => {
      const target = e.target.closest("[data-multi-play]");
      if (!target) return;
      if (target.closest(".func-seq-arrow")) return;

      const kind = target.dataset.multiPlay;

      if (kind === "scale") {
        playMultiModeScale(payload.scaleNoteNames);
        return;
      }

      if (kind === "func-seq") {
        playMultiModeFuncSequence(payload.funcSteps);
        return;
      }

      if (kind === "scale-note") {
        const note = target.dataset.note;
        if (note) {
          const { freqs } = chordNotesToFrequencies([note], 4, false, null);
          playChord(freqs, 0.5);
        }
        return;
      }

      if (kind === "degree") {
        const idx = parseInt(target.dataset.degreeIndex, 10);
        if (!Number.isNaN(idx) && degreeFreqs[idx]?.length) {
          playChord(degreeFreqs[idx]);
        }
        return;
      }

      if (kind === "func-node") {
        const idx = parseInt(target.dataset.funcIndex, 10);
        const step = payload.funcSteps?.[idx];
        if (!step) return;
        const names = parseMultiModeNotes(step.notes);
        if (!names.length) return;
        let lastRootMidi = null;
        if (idx > 0) {
          for (let j = 0; j < idx; j++) {
            const prev = parseMultiModeNotes(payload.funcSteps[j].notes);
            if (!prev.length) continue;
            const { rootMidi } = chordNotesToFrequencies(
              prev,
              4,
              false,
              lastRootMidi,
              { voiceLeading: "nearest" },
            );
            if (rootMidi != null) lastRootMidi = rootMidi;
          }
        }
        const { freqs } = chordNotesToFrequencies(
          names,
          4,
          false,
          lastRootMidi,
          { voiceLeading: "nearest" },
        );
        playChord(freqs);
      }
    });

    displayEl.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" && e.key !== " ") return;
      const target = e.target.closest("[data-multi-play]");
      if (!target || target.tagName === "BUTTON") return;
      e.preventDefault();
      target.click();
    });
  }

  window.jazzCompassAudio = {
    wireDisplay: wireMultiModeDisplayAudio,
    playScale: playMultiModeScale,
    playFuncSequence: playMultiModeFuncSequence,
    chordNotesToFrequencies,
    parseMultiModeNotes,
  };

  function playScale(scaleNotes, baseOctave = 3, noteDuration = 0.15) {
    const sequence = buildScaleSequence(scaleNotes, baseOctave, true);
    playNoteSequence(
      sequence.map((s) => s.freq),
      noteDuration,
    );
  }

  /**
   * 智能计算音阶序列的八度分配
   * 确保上行时音符逐渐升高，下行时逐渐降低
   */
  function buildScaleSequence(scaleNotes, baseOctave, includeDescending = true) {
    const sequence = [];
    const rootSemitone = noteToSemitoneValue(scaleNotes[0]);

    // 上行
    let currentOctave = baseOctave;
    let prevSemitone = null;

    scaleNotes.forEach((note, index) => {
      const semitone = noteToSemitoneValue(note);
      if (semitone === undefined) return;

      // 如果当前音符比前一个音符小（如 B→C），进入下一个八度
      if (prevSemitone !== null && semitone <= prevSemitone) {
        currentOctave++;
      }

      sequence.push({
        freq: semitoneToFreq(semitone, currentOctave),
        octave: currentOctave,
        note: note
      });

      prevSemitone = semitone;
    });

    // 高点：再升高八度的主音
    sequence.push({
      freq: semitoneToFreq(rootSemitone, currentOctave + 1),
      octave: currentOctave + 1,
      note: scaleNotes[0]
    });

    if (includeDescending) {
      // 下行
      prevSemitone = null;

      sequence.push({
        freq: semitoneToFreq(rootSemitone, currentOctave + 1),
        octave: currentOctave + 1,
        note: scaleNotes[0]
      });
      // currentOctave = currentOctave + 1;

      for (let i = scaleNotes.length - 1; i >= 0; i--) {
        const semitone = noteToSemitoneValue(scaleNotes[i]);
        if (semitone === undefined) continue;

        // 如果当前音符比前一个音符大（如 C→B），进入低一个八度
        if (prevSemitone !== null && semitone > prevSemitone) {
          currentOctave--;
        }

        sequence.push({
          freq: semitoneToFreq(semitone, currentOctave),
          octave: currentOctave,
          note: scaleNotes[i]
        });

        prevSemitone = semitone;
      }
    }

    return sequence;
  }

  /**
   * 播放音阶（使用智能八度分配）
   */
  function playScaleSequence(scaleNotes, baseOctave = 3, noteDuration = 0.15) {
    playScale(scaleNotes, baseOctave, noteDuration);
  }

  function renderScaleDetail(container, root, scaleInfo, ms) {
    const rootIdx = ms.noteToVal ? ms.noteToVal[root] : conv.noteToIdx[root];
    if (rootIdx === undefined) {
      container.innerHTML = `<div class="result-card">Invalid root: ${root}</div>`;
      return;
    }

    const intervals = scaleInfo.intervals;
    const avoidIds = scaleInfo.avoid_intervals_ids || [];
    const avoidSet = new Set(
      avoidIds.map((i) => intervals[i]).map((v) => (rootIdx + v) % 12),
    );

    // 计算音符 — 必须在播放按钮之前定义
    const noteNames = intervals.map((i) => {
      const val = (rootIdx + i) % 12;
      return { note: conv.idxToNote[val], val, intervalIdx: i };
    });

    // 获取音阶音符列表（纯音符名称数组）
    const scaleNoteNames = noteNames.map(({ note }) => note);

    // 关联音阶
    const strongRelated = (scaleInfo.related_strong || [])
      .map((id) => ms.get_scale_by_id(id))
      .filter((s) => s);
    const weakRelated = (scaleInfo.related_weak || [])
      .map((id) => ms.get_scale_by_id(id))
      .filter((s) => s);

    // 同家族音阶
    const sameFamilyScales = ms.get_scales_by_chord_family(scaleInfo.family);

    // 家族和弦音符
    const familyChordIntervals = ms.chordFamily[scaleInfo.family] || [];
    const familyChordNotes = familyChordIntervals.map(
      (i) => conv.idxToNote[(rootIdx + i) % 12],
    );

    container.innerHTML = "";

    // ---- 标题 ----
    const header = document.createElement("h3");
    header.className = "card-title";
    header.style.margin = "0 0 12px 0";
    header.textContent = `${root} ${scaleInfo.scale_name[0]}`;
    container.appendChild(header);

    const subHeader = document.createElement("div");
    subHeader.className = "small-muted";
    subHeader.textContent = `${window.__("ref_family_title")}: ${scaleInfo.family}`;
    container.appendChild(subHeader);

    // ---- 音阶内音（标注避免音） ----
    const notesSec = document.createElement("div");
    notesSec.style.marginTop = "16px";

    // 音符标题行 + 播放按钮
    const notesHeaderRow = document.createElement("div");
    notesHeaderRow.style.display = "flex";
    notesHeaderRow.style.alignItems = "center";
    notesHeaderRow.style.justifyContent = "space-between";
    notesHeaderRow.style.marginBottom = "8px";

    const notesLabel = document.createElement("div");
    notesLabel.style.fontWeight = "bold";
    notesLabel.textContent = window.__("ref_notes") || "Scale Notes";
    notesHeaderRow.appendChild(notesLabel);

    // 创建播放按钮组
    const playBtnGroup = document.createElement("div");
    playBtnGroup.style.display = "flex";
    playBtnGroup.style.gap = "8px";

    // 上行+下行播放按钮
    const playUpDownBtn = document.createElement("button");
    playUpDownBtn.textContent = window.__("scale_play_title") || "Play";
    playUpDownBtn.style.padding = "6px 12px";
    playUpDownBtn.style.borderRadius = "6px";
    playUpDownBtn.style.border = "1px solid var(--accent-2)";
    playUpDownBtn.style.background = "rgba(0, 181, 173, 0.15)";
    playUpDownBtn.style.color = "var(--accent-2)";
    playUpDownBtn.style.cursor = "pointer";
    playUpDownBtn.style.fontSize = "0.85em";

    playBtnGroup.appendChild(playUpDownBtn);
    notesHeaderRow.appendChild(playBtnGroup);
    notesSec.appendChild(notesHeaderRow);

    // 播放按钮事件
    playUpDownBtn.addEventListener("click", () => {
      playScaleSequence(scaleNoteNames, 3, 0.15);
      playUpDownBtn.style.background = "rgba(0, 181, 173, 0.3)";
      requestAnimationFrame(() => {
        playUpDownBtn.style.background = "rgba(0, 181, 173, 0.15)";
      });
    });

    // 音符网格
    const noteGrid = document.createElement("div");
    noteGrid.className = "note-grid";
    noteNames.forEach(({ note, val }) => {
      const cell = document.createElement("div");
      cell.className = "note-cell";
      if (avoidSet.has(val)) {
        cell.classList.add("avoid-note");
        cell.style.background = "rgba(255, 80, 80, 0.2)";
        cell.style.borderColor = "rgba(255, 100, 100, 0.6)";
      }
      cell.innerHTML = `<div class="note">${note}</div>`;
      noteGrid.appendChild(cell);
    });

    notesSec.appendChild(noteGrid);

    // 避免音提示
    if (avoidIds.length > 0) {
      let avoidNote = [];
      avoidIds.forEach((avoidId) => {
        avoidNote.push(noteNames[avoidId].note);
      });
      const avoidTip = document.createElement("div");
      avoidTip.className = "small-muted";
      avoidTip.style.marginTop = "6px";
      avoidTip.textContent = `${window.__("ref_avoid")}: ${avoidNote.join(", ")}`;
      notesSec.appendChild(avoidTip);
    }
    container.appendChild(notesSec);

    // ---- 家族和弦 ----
    const familySec = document.createElement("div");
    familySec.style.marginTop = "16px";
    const familyLabel = document.createElement("div");
    familyLabel.style.fontWeight = "bold";
    familyLabel.style.marginBottom = "8px";
    familyLabel.textContent = window.__("ref_family_chord") || "Family Chord";
    familySec.appendChild(familyLabel);

    const familyGrid = document.createElement("div");
    familyGrid.className = "note-grid";
    familyChordNotes.forEach((n) => {
      const cell = document.createElement("div");
      cell.className = "note-cell";
      cell.innerHTML = `<div class="note">${n}</div>`;
      familyGrid.appendChild(cell);
    });
    familySec.appendChild(familyGrid);
    container.appendChild(familySec);

    // ---- 强关联音阶 ----
    if (strongRelated.length > 0) {
      const sec = document.createElement("div");
      sec.style.marginTop = "16px";
      const lbl = document.createElement("div");
      lbl.style.fontWeight = "bold";
      lbl.style.marginBottom = "8px";
      lbl.textContent = window.__("ref_related_strong") || "Strongly Related";
      sec.appendChild(lbl);
      sec.appendChild(makeScaleList(strongRelated, root, ms));
      container.appendChild(sec);
    }

    // ---- 关联音阶 ----
    if (weakRelated.length > 0) {
      const sec = document.createElement("div");
      sec.style.marginTop = "16px";
      const lbl = document.createElement("div");
      lbl.style.fontWeight = "bold";
      lbl.style.marginBottom = "8px";
      lbl.textContent = window.__("ref_related_weak") || "Related";
      sec.appendChild(lbl);
      sec.appendChild(makeScaleList(weakRelated, root, ms));
      container.appendChild(sec);
    }
  }

  /**
   * 从预构建的序列播放音阶
   */
  function playScaleFromSequence(sequence, noteDuration = 0.15) {
    const dur = Math.max(0.08, noteDuration);
    playNoteSequence(
      sequence.map((s) => (typeof s === "number" ? s : s.freq)),
      dur,
    );
  }

  // ============ 渲染和弦家族详情 ============
  function renderFamilyDetail(container, familyName, ms) {
    const familyIntervals = ms.chordFamily[familyName];
    const scales = ms.get_scales_by_chord_family(familyName);

    if (!familyIntervals) {
      container.innerHTML = `<div class="result-card">Family not found: ${familyName}</div>`;
      return;
    }

    container.innerHTML = "";

    // 标题
    const header = document.createElement("h3");
    header.className = "card-title";
    header.textContent = familyName;
    container.appendChild(header);

    // 家族和弦音（以C为根音展示）
    const notesSec = document.createElement("div");
    notesSec.style.marginTop = "16px";
    const notesLabel = document.createElement("div");
    notesLabel.style.fontWeight = "bold";
    notesLabel.style.marginBottom = "8px";
    notesLabel.textContent =
      window.__("ref_family_chord") || "Family Chord (root C)";
    notesSec.appendChild(notesLabel);

    const noteGrid = document.createElement("div");
    noteGrid.className = "note-grid";
    familyIntervals.forEach((i) => {
      const note = conv.idxToNote[i % 12];
      const cell = document.createElement("div");
      cell.className = "note-cell";
      cell.innerHTML = `<div class="note">${note}</div>`;
      noteGrid.appendChild(cell);
    });
    notesSec.appendChild(noteGrid);
    container.appendChild(notesSec);

    // 该家族下所有音阶
    const scalesSec = document.createElement("div");
    scalesSec.style.marginTop = "16px";
    const scalesLabel = document.createElement("div");
    scalesLabel.style.fontWeight = "bold";
    scalesLabel.style.marginBottom = "8px";
    scalesLabel.textContent = `${window.__("ref_same_family") || "Scales in this family"} (${scales.length})`;
    scalesSec.appendChild(scalesLabel);

    if (scales.length > 0) {
      const scaleGrid = document.createElement("div");
      scaleGrid.style.display = "flex";
      scaleGrid.style.flexWrap = "wrap";
      scaleGrid.style.gap = "8px";

      scales.forEach((s) => {
        const badge = document.createElement("span");
        badge.style.padding = "6px 12px";
        badge.style.borderRadius = "6px";
        badge.style.background = "rgba(255,255,255,0.08)";
        badge.style.fontSize = "0.9em";
        badge.style.cursor = "pointer";
        badge.title = `${s.scale_name[0]} — ${s.id}`;
        badge.textContent = s.scale_name[0];
        badge.addEventListener("click", () => jumpToScale("C", s.id));
        scaleGrid.appendChild(badge);
      });
      scalesSec.appendChild(scaleGrid);
    }
    container.appendChild(scalesSec);
  }

  // ============ 辅助：生成关联音阶小卡片列表 ============
  function makeScaleList(scales, root, ms) {
    const container = document.createElement("div");
    container.style.display = "flex";
    container.style.flexWrap = "wrap";
    container.style.gap = "8px";

    scales.forEach((s) => {
      const card = document.createElement("div");
      card.style.padding = "10px 14px";
      card.style.borderRadius = "8px";
      card.style.background = "rgba(255,255,255,0.05)";
      card.style.border = "1px solid rgba(255,255,255,0.08)";
      card.style.cursor = "pointer";
      card.style.transition = "background 0.2s";
      card.addEventListener("click", () => jumpToScale(root, s.id));
      card.addEventListener(
        "mouseenter",
        () => (card.style.background = "rgba(255,255,255,0.1)"),
      );
      card.addEventListener(
        "mouseleave",
        () => (card.style.background = "rgba(255,255,255,0.05)"),
      );

      // 计算此关联音阶的首个避免音（如果有）
      const avoidIds = s.avoid_intervals_ids || [];
      const intervals = s.intervals || [];

      // 顶部音阶名
      const nameEl = document.createElement("div");
      nameEl.style.fontWeight = "bold";
      nameEl.style.fontSize = "0.9em";
      nameEl.style.marginBottom = "4px";
      nameEl.style.display = "inline-block";
      nameEl.textContent = s.scale_name[0];
      card.appendChild(nameEl);

      // 音符预览（微型网格）
      if (intervals.length > 0) {
        const rootIdx = conv.noteToIdx[root];
        const microGrid = document.createElement("div");
        microGrid.style.display = "flex";
        microGrid.style.gap = "3px";
        microGrid.style.marginTop = "6px";

        const avoidSet = new Set(
          avoidIds.map((i) => intervals[i]).map((v) => (rootIdx + v) % 12),
        );
        intervals.forEach((i) => {
          const val = (rootIdx + i) % 12;
          const n = conv.idxToNote[val];
          const dot = document.createElement("span");
          dot.style.padding = "2px 5px";
          dot.style.borderRadius = "3px";
          dot.style.fontSize = "0.75em";
          if (avoidSet.has(val)) {
            dot.style.background = "rgba(255, 80, 80, 0.25)";
            dot.style.color = "#ff8888";
          } else {
            dot.style.background = "rgba(255,255,255,0.06)";
          }
          dot.textContent = n;
          microGrid.appendChild(dot);
        });
        card.appendChild(microGrid);
      }

      container.appendChild(card);
    });

    return container;
  }
  // ==================== 五度圈面板 ====================

  // 功能名称 — 通过 i18n 动态获取
  function getFuncNames() {
    return {
      tonic: window.__("circle_func_tonic") || "Tonic",
      supertonic: window.__("circle_func_supertonic") || "Supertonic",
      mediant: window.__("circle_func_mediant") || "Mediant",
      subdom: window.__("circle_func_subdominant") || "Subdominant",
      dominant: window.__("circle_func_dominant") || "Dominant",
      submed: window.__("circle_func_submediant") || "Submediant",
      leading: window.__("circle_func_leading") || "Leading Tone",
      subtonic: window.__("circle_func_subtonic") || "Subtonic",
    };
  }

  function buildMajorFuncs() {
    const f = getFuncNames();
    return [
      f.tonic,
      f.supertonic,
      f.mediant,
      f.subdom,
      f.dominant,
      f.submed,
      f.leading,
    ];
  }

  function buildMinorFuncs() {
    const f = getFuncNames();
    return [
      f.tonic,
      f.supertonic,
      f.mediant,
      f.subdom,
      f.dominant,
      f.submed,
      f.subtonic,
    ];
  }

  function buildHarmonicMajorFuncs() {
    const f = getFuncNames();
    return [
      f.tonic,
      f.supertonic,
      f.mediant,
      f.subdom,
      f.dominant,
      f.submed,
      f.leading,
    ];
  }

  function buildHarmonicMinorFuncs() {
    const f = getFuncNames();
    return [
      f.tonic,
      f.supertonic,
      f.mediant,
      f.subdom,
      f.dominant,
      f.submed,
      f.leading,
    ];
  }

  function updateNeoPath(targetEl, chordA, chordB, maxSteps = 8) {
    let paths;
    try {
      paths = brain.nrt.findPath(chordA, chordB, maxSteps);
    } catch (e) {
      targetEl.innerHTML = `<div class="result-card">${e.message}</div>`;
      return;
    }

    targetEl.innerHTML = "";

    if (!paths || paths.length === 0) {
      const noPath = document.createElement("div");
      noPath.className = "result-card";
      noPath.style.textAlign = "center";
      noPath.style.padding = "30px";
      noPath.innerHTML = `
      <div style="font-size:2em; margin-bottom:12px;">✗</div>
      <div class="small-muted">${window.__("neo_path_no_path") || "No connection path found"}</div>
      <div style="margin-top:12px; font-size:1.1em;">
        <span style="color:var(--accent);">${chordA}</span>
        <span style="color:var(--muted); margin:0 8px;">→</span>
        <span style="color:var(--accent-2);">${chordB}</span>
      </div>
      <div class="small-muted" style="margin-top:8px;">(${window.__("neo_path_steps") || "max"}: ${maxSteps} ${window.__("neo_path_steps") || "steps"})</div>
    `;
      targetEl.appendChild(noPath);
      return;
    }

    // 最优路径
    const optimalPath = paths[0];
    renderPathCard(targetEl, optimalPath, chordA, chordB, true);

    // 其他路径
    if (paths.length > 1) {
      const altTitle = document.createElement("h4");
      altTitle.className = "section-title";
      altTitle.style.marginTop = "24px";
      altTitle.style.marginBottom = "12px";
      altTitle.textContent = window.__("neo_path_alternative") || "Alternative Paths";
      targetEl.appendChild(altTitle);

      paths.slice(1, Math.min(6, paths.length)).forEach((p) => {
        renderPathCard(targetEl, p, chordA, chordB, false);
      });
    }
  }

  function renderPathCard(container, pathData, chordA, chordB, isOptimal) {
    const card = document.createElement("div");
    card.className = "result-card";
    card.style.margin = "12px 0";
    card.style.background = isOptimal
      ? "linear-gradient(135deg, hsl(170, 25%, 18%), hsl(170, 20%, 10%))"
      : "linear-gradient(135deg, hsl(260, 12%, 16%), hsl(260, 8%, 9%))";

    if (isOptimal) {
      card.style.border = "1px solid var(--accent-2)";
    }

    // 头部：标题 + 步数徽章
    const header = document.createElement("div");
    header.style.display = "flex";
    header.style.justifyContent = "space-between";
    header.style.alignItems = "center";
    header.style.marginBottom = "14px";

    const title = document.createElement("div");
    title.className = "card-title";
    title.style.margin = "0";
    title.textContent = isOptimal
      ? `${window.__("neo_path_optimal") || "Optimal Path"}`
      : `${window.__("neo_path_alternative") || "Path"}`;

    const stepsBadge = document.createElement("span");
    stepsBadge.className = "spice-badge";
    stepsBadge.style.background = isOptimal ? "var(--accent-2)" : "rgba(255,255,255,0.1)";
    stepsBadge.style.color = "#fff";
    stepsBadge.textContent = `${pathData.steps} ${window.__("neo_path_steps") || "steps"}`;

    header.appendChild(title);
    header.appendChild(stepsBadge);
    card.appendChild(header);

    // 路径流程图
    const flowContainer = document.createElement("div");
    flowContainer.style.display = "flex";
    flowContainer.style.flexWrap = "wrap";
    flowContainer.style.alignItems = "center";
    flowContainer.style.justifyContent = "center";
    flowContainer.style.gap = "4px";
    flowContainer.style.padding = "8px 0";

    pathData.path.forEach((step, i) => {
      // 和弦块
      const chordEl = document.createElement("div");
      chordEl.style.padding = "6px 12px";
      chordEl.style.borderRadius = "6px";
      chordEl.style.background = "rgba(255,255,255,0.08)";
      chordEl.style.fontWeight = "bold";
      chordEl.style.fontSize = "0.9em";
      chordEl.textContent = step.from;
      flowContainer.appendChild(chordEl);

      // 变换操作箭头
      const arrowEl = document.createElement("div");
      arrowEl.style.display = "flex";
      arrowEl.style.flexDirection = "column";
      arrowEl.style.alignItems = "center";
      arrowEl.style.padding = "0 4px";
      arrowEl.innerHTML = `
      <span style="font-size:1em; color:var(--accent);">→</span>
      <span style="font-size:0.65em; color:var(--accent-2); font-weight:bold; white-space:nowrap;">${step.operation}</span>
    `;
      flowContainer.appendChild(arrowEl);

      // 最后一步显示目标和弦（高亮）
      if (i === pathData.path.length - 1) {
        const targetEl = document.createElement("div");
        targetEl.style.padding = "6px 12px";
        targetEl.style.borderRadius = "6px";
        targetEl.style.background = "rgba(0, 181, 173, 0.2)";
        targetEl.style.border = "1px solid var(--accent-2)";
        targetEl.style.fontWeight = "bold";
        targetEl.style.fontSize = "0.9em";
        targetEl.style.color = "var(--accent-2)";
        targetEl.textContent = step.to;
        flowContainer.appendChild(targetEl);
      }
    });

    card.appendChild(flowContainer);

    // 每步和弦的音符展示
    const notesRow = document.createElement("div");
    notesRow.style.display = "flex";
    notesRow.style.flexWrap = "wrap";
    notesRow.style.gap = "10px";
    notesRow.style.marginTop = "14px";

    pathData.chords.forEach((chordName) => {
      try {
        const info = brain.converter._ensureNotesAndRoot(chordName);
        if (info && info.length >= 3) {
          const block = document.createElement("div");
          block.style.textAlign = "center";
          block.style.padding = "6px 8px";
          block.style.borderRadius = "6px";
          block.style.background = "rgba(255,255,255,0.03)";
          block.style.minWidth = "60px";

          const nameDiv = document.createElement("div");
          nameDiv.style.fontWeight = "bold";
          nameDiv.style.fontSize = "0.75em";
          nameDiv.style.marginBottom = "4px";
          nameDiv.style.color = "var(--muted)";
          nameDiv.textContent = chordName;
          block.appendChild(nameDiv);

          const noteRow = document.createElement("div");
          noteRow.style.display = "flex";
          noteRow.style.gap = "3px";
          noteRow.style.justifyContent = "center";
          info.slice(0, 4).forEach((n) => {
            const nc = document.createElement("span");
            nc.style.padding = "1px 5px";
            nc.style.borderRadius = "3px";
            nc.style.background = "rgba(255,255,255,0.1)";
            nc.style.fontSize = "0.72em";
            nc.textContent = n;
            noteRow.appendChild(nc);
          });
          block.appendChild(noteRow);

          // 箭头分隔（最后一个不显示）
          if (chordName !== pathData.chords[pathData.chords.length - 1]) {
            const wrapper = document.createElement("div");
            wrapper.style.display = "flex";
            wrapper.style.alignItems = "center";
            wrapper.style.gap = "6px";
            wrapper.appendChild(block);

            const sep = document.createElement("span");
            sep.style.color = "var(--accent)";
            sep.style.fontSize = "0.9em";
            sep.textContent = "→";
            wrapper.appendChild(sep);

            notesRow.appendChild(wrapper);
          } else {
            notesRow.appendChild(block);
          }
        }
      } catch (e) { }
    });

    card.appendChild(notesRow);
    container.appendChild(card);
  }

  // 绑定新里曼运行按钮
  document.getElementById("neo-run").addEventListener("click", () => {
    const target = document.getElementById("panel-neo-body");
    const val = document.getElementById("neo-input").value;
    updateNeo(target, val);
  });

  // 路径查找按钮事件
  const neoPathRunBtn = document.getElementById("neo-path-run");
  if (neoPathRunBtn) {
    neoPathRunBtn.addEventListener("click", () => {
      const target = document.getElementById("panel-neo-body");
      const fromChord = document.getElementById("neo-path-from").value.trim();
      const toChord = document.getElementById("neo-path-to").value.trim();
      const maxSteps = parseInt(document.getElementById("neo-max-steps").value) || 8;

      if (!fromChord || !toChord) {
        target.innerHTML = `<div class="small-muted">${window.__("cannot_parse_input")}</div>`;
        return;
      }

      updateNeoPath(target, fromChord, toChord, maxSteps);
    });

    // 支持回车触发
    document.getElementById("neo-path-to").addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        neoPathRunBtn.click();
      }
    });
  }

  // Bind run buttons and inputs per-panel
  function localizeClassicalText(text) {
    if (window.__lang !== "zh") return text;
    const exact = {
      "Classical tertian harmony: triads and seventh chords; only the dominant may use a ninth.": "古典三度叠置和声 以三和弦 七和弦为主 仅属功能允许使用九和弦 ",
      "diatonic triad": "调内三和弦",
      "diatonic seventh": "调内七和弦",
      "diatonic ninth": "调内九和弦",
      "cadential six-four": "终止四六和弦",
      "dominant ninth": "属九和弦",
      "Neapolitan sixth": "那不勒斯六和弦",
      "double dominant": "重属和弦",
      "secondary dominant": "离调属和弦",
      "Italian augmented sixth": "意大利增六和弦",
      "French augmented sixth": "法国增六和弦",
      "German augmented sixth": "德国增六和弦",
      "tonic group": "主功能组",
      "subdominant group": "下属功能组",
      "dominant group": "属功能组",
      "leading-tone group": "导功能组",
      "altered chord group": "变和弦组",
      "Sposobin functional DNA: recommendations follow the reference project's next-chord graph.": "基于斯波索宾功能和声连接规则生成推荐 ",
      "unclassified": "未分类",
      "Continue by functional contrast or common-tone prolongation.": "通过功能对比继续 或用共同音延长当前功能 ",
      "Resolve toward the tonic; raise the leading tone in minor.": "向主功能解决 小调中须使用升高的导音 ",
      "Bass remains on scale degree 5; 6-5 and 4-3 resolve into V or V7.": "低音保持在属音 外声部按 6-5、4-3 解决到 V 或 V7。",
      "Use first inversion (N6), then move to K64 or V; double the bass is usually preferred.": "采用第一转位 N6 随后连接 K64 或 V 通常优先重复低音 ",
      "Resolve the augmented sixth outward by semitone to scale degree 5, then continue to V.": "增六音程向外半音解决到属音 再进入 V。",
      "Resolve through K64 to avoid parallel fifths, then continue to V.": "先经过 K64 以规避平行五度 再进入 V。",
      "Resolve the seventh downward and the leading tone upward; the ninth resolves downward.": "七音下行 导音上行 九音下行解决 ",
    };
    if (exact[text]) return exact[text];
    const secondary = text.match(/^Resolve to ([^(]+) \(([^)]+)\); retain common tones and resolve the temporary leading tone upward\.$/);
    if (secondary) return `解决到 ${secondary[1].trim()}（${secondary[2]}） 保留共同音 临时导音上行解决 `;
    return text;
  }

  function classicalModeLabel(mode = "major") {
    return {
      "all-generic": "/",
      "major-generic": "大调(不分)",
      "minor-generic": "小调(不分)",
      major: "自然大调",
      "harmonic-major": "和声大调",
      "melodic-major": "旋律大调",
      minor: "自然小调",
      "harmonic-minor": "和声小调",
      "melodic-minor": "旋律小调",
    }[mode] || mode;
  }

  function comparableClassicalMode(mode = "major") {
    if (mode === "major-generic") return "major";
    if (mode === "minor-generic") return "minor";
    return mode;
  }

  function concreteClassicalModes(mode = "major") {
    const majorModes = ["major", "harmonic-major", "melodic-major"];
    const minorModes = ["minor", "harmonic-minor", "melodic-minor"];
    if (mode === "all-generic") return [...majorModes, ...minorModes];
    if (mode === "major-generic") return majorModes;
    if (mode === "minor-generic") return minorModes;
    return [mode];
  }

  function updateClassicalHarmony(targetEl) {
    compositionAudio.stop();
    stopClassicalSequencePlayback();
    const key = document.getElementById("classical-key")?.value || "C";
    const mode = document.getElementById("classical-mode")?.value || "major";
     const modulationKey = document.getElementById("classical-mod-key")?.value || "G";
     const modulationMode = document.getElementById("classical-mod-mode")?.value || "major";
     let input = document.getElementById("classical-input")?.value.trim() || "";
     const hasInput = Boolean(input);
     const modeIsMinor = mode.includes("minor");
    if (hasInput && classicalLastKey !== null && classicalLastKey !== key) {
      input = modeIsMinor ? "t" : "T";
      document.getElementById("classical-input").value = input;
      classicalSegments.push({ key, mode, symbols: [input] });
     } else if (hasInput && classicalLastMode !== null && classicalLastMode !== mode) {
      input = modeIsMinor ? "t" : "T";
      document.getElementById("classical-input").value = input;
       classicalSegments = [{ key, mode, symbols: [input] }];
     }
     if (classicalPendingChain && classicalPendingChain.key === key && classicalPendingChain.mode === mode) {
       const segment = classicalSegments[classicalSegments.length - 1] || { key, mode, symbols: [] };
       segment.key = key;
       segment.mode = mode;
       segment.symbols = classicalPendingChain.symbols.slice();
       if (!classicalSegments.length) classicalSegments.push(segment);
       classicalPendingChain = null;
     }
    classicalLastKey = key;
    classicalLastMode = mode;
    if (hasInput && !classicalSegments.length) classicalSegments = [{ key, mode, symbols: [input] }];
    classicalChain = classicalSegments.length ? classicalSegments[classicalSegments.length - 1].symbols : [];
    try {
      const report = hasInput ? classical.recommend(input, key, mode, 16) : null;
      targetEl.innerHTML = "";

      const workbench = document.createElement("div");
      workbench.className = "classical-workbench";
      const pickerPane = document.createElement("aside");
      pickerPane.className = "classical-picker-pane";
      const resultPane = document.createElement("div");
      resultPane.className = "classical-result-pane";

      const chainBar = document.createElement("div");
      chainBar.className = "classical-chain result-card";
      const displayClassicalSymbol = symbol => symbol;
       if (report) {
         const activeSegment = classicalSegments[classicalSegments.length - 1];
         if (!activeSegment) {
           classicalSegments = [{ key, mode, symbols: [report.current.symbol] }];
         } else if (!activeSegment.symbols.length) {
           activeSegment.symbols = [report.current.symbol];
         } else if (activeSegment.symbols.length === 1) {
           // Keep a chain built by clicking recommendations. The raw input
           // may be an alias (e.g. K64 vs K₆₄), so normalize only its final
           // node instead of replacing the entire sequence.
           const lastValue = activeSegment.symbols[0];
           if (lastValue === input || lastValue === report.current.symbol || lastValue === report.current.baseSymbol) activeSegment.symbols[0] = report.current.symbol;
         }
         classicalChain = classicalSegments[classicalSegments.length - 1].symbols;
       }
      const chainButtons = classicalChain.map((symbol, index) => `<button type="button" class="classical-chain-node" data-chain-index="${index}">${symbol}</button>${index < classicalChain.length - 1 ? "<span class=\"classical-chain-arrow\">→</span>" : ""}`).join("");
      const segmentFlow = classicalSegments.map((segment, segmentIndex) => {
        const segmentPalette = classical.getPalette(segment.key, segment.mode);
        const entries = new Map(segmentPalette.map(entry => [entry.symbol, entry]));
        const nodes = segment.symbols.map((symbol, index) => {
          const entry = entries.get(symbol);
          const categoryLabel = entry ? localizeClassicalText(entry.category) : "";
          const labels = entry
            ? `<span class="classical-chain-function">${entry.symbol}</span><span class="classical-chain-roman">${entry.roman}</span><span class="classical-chain-chord">${entry.chord}</span><span class="classical-chain-category">${categoryLabel}</span>`
            : `<span class="classical-chain-function">${symbol}</span>`;
          return `<span class="classical-chain-node-wrap"><button type="button" class="classical-chain-node" data-symbol="${symbol}" data-segment-index="${segmentIndex}" data-chain-index="${index}" title="${entry ? `${entry.symbol} / ${entry.roman} / ${entry.chord} / ${categoryLabel}` : symbol}">${labels}</button><button type="button" class="classical-chain-single-play" data-single-segment-index="${segmentIndex}" data-single-chain-index="${index}" aria-label="播放 ${entry ? `${entry.symbol} ${entry.chord}` : symbol}" title="播放此和弦">▶</button></span>${index < segment.symbols.length - 1 ? "<span class=\"classical-chain-arrow\">→</span>" : ""}`;
        }).join("");
        const keyLabelClass = segmentIndex ? "classical-chain-divider" : "classical-chain-key-start";
        return `<span class="${keyLabelClass}">│ Key=${segment.key} ${classicalModeLabel(segment.mode)} │</span>${nodes}`;
      }).join("");
      const playbackSettings = loadClassicalPlaybackSettings();
      chainBar.innerHTML = `<div class="classical-chain-head"><strong>连续和声连接</strong><div class="classical-chain-primary-actions"><button type="button" class="classical-chain-play" ${classicalChain.length ? "" : "disabled"}>▶ 播放</button><button type="button" class="classical-chain-back" ${classicalChain.length < 2 ? "disabled" : ""}>↶ 回退</button><button type="button" class="classical-chain-reset">× 清空</button></div></div><div class="classical-chain-flow">${segmentFlow || `<span class="small-muted">输入当前和弦 或从功能库选择起点</span>`}</div><details class="classical-playback-settings"><summary>播放设置 · ${playbackSettings.bpm} BPM · ${playbackSettings.meter}</summary><div class="classical-chain-controls"><label class="classical-chain-bpm">速度 <input class="classical-chain-tempo" type="range" min="40" max="640" step="1" value="${playbackSettings.bpm}" aria-label="播放速度"><input class="classical-chain-tempo-value" type="number" min="40" max="640" step="1" value="${playbackSettings.bpm}" aria-label="BPM 数值"> BPM</label><select class="classical-chain-meter" aria-label="播放拍号"><option value="4/4" ${playbackSettings.meter === "4/4" ? "selected" : ""}>4/4</option><option value="3/4" ${playbackSettings.meter === "3/4" ? "selected" : ""}>3/4</option><option value="6/8" ${playbackSettings.meter === "6/8" ? "selected" : ""}>6/8</option><option value="8/8" ${playbackSettings.meter === "8/8" ? "selected" : ""}>8/8</option><option value="12/16" ${playbackSettings.meter === "12/16" ? "selected" : ""}>12/16</option><option value="16/16" ${playbackSettings.meter === "16/16" ? "selected" : ""}>16/16</option></select><select class="classical-chain-play-mode" aria-label="序列播放方式"><option value="block" ${playbackSettings.mode === "block" ? "selected" : ""}>柱式和声</option><option value="arpeggio" ${playbackSettings.mode === "arpeggio" ? "selected" : ""}>琶音 1-3-5</option></select></div></details>`;
      const clampClassicalBpm = value => Math.max(40, Math.min(640, Math.round(Number(value) || 80)));
      const tempoSlider = chainBar.querySelector(".classical-chain-tempo");
      const tempoValue = chainBar.querySelector(".classical-chain-tempo-value");
      const meterSelect = chainBar.querySelector(".classical-chain-meter");
      const modeSelect = chainBar.querySelector(".classical-chain-play-mode");
      const syncClassicalTempo = value => {
        const bpm = clampClassicalBpm(value);
        if (tempoSlider) tempoSlider.value = String(bpm);
        if (tempoValue) tempoValue.value = String(bpm);
        saveClassicalPlaybackSettings({
          bpm,
          meter: meterSelect?.value || DEFAULT_CLASSICAL_PLAYBACK.meter,
          mode: modeSelect?.value || DEFAULT_CLASSICAL_PLAYBACK.mode,
        });
        return bpm;
      };
      tempoSlider?.addEventListener("input", event => syncClassicalTempo(event.currentTarget.value));
      tempoValue?.addEventListener("change", event => syncClassicalTempo(event.currentTarget.value));
      meterSelect?.addEventListener("change", () => saveClassicalPlaybackSettings({
        bpm: clampClassicalBpm(tempoValue?.value || tempoSlider?.value),
        meter: meterSelect.value,
        mode: modeSelect?.value || DEFAULT_CLASSICAL_PLAYBACK.mode,
      }));
      modeSelect?.addEventListener("change", () => saveClassicalPlaybackSettings({
        bpm: clampClassicalBpm(tempoValue?.value || tempoSlider?.value),
        meter: meterSelect?.value || DEFAULT_CLASSICAL_PLAYBACK.meter,
        mode: modeSelect.value,
      }));
      chainBar.querySelectorAll(".classical-chain-single-play").forEach(button => button.addEventListener("click", event => {
        compositionAudio.stop();
        event.stopPropagation();
        const segmentIndex = Number(button.dataset.singleSegmentIndex);
        const chainIndex = Number(button.dataset.singleChainIndex);
        const segment = classicalSegments[segmentIndex];
        const symbol = segment?.symbols?.[chainIndex];
        const entry = symbol ? classical.getPalette(segment.key, segment.mode).find(item => item.symbol === symbol) : null;
        if (!entry?.notes?.length) return;
        stopClassicalSequencePlayback();
        chainBar.querySelectorAll(".classical-chain-node.is-playing").forEach(node => node.classList.remove("is-playing"));
        chainBar.querySelector(`[data-segment-index="${segmentIndex}"][data-chain-index="${chainIndex}"]`)?.classList.add("is-playing");
        playChord(classicalMidiFreqs(entry), 1.4);
        setTimeout(() => chainBar.querySelector(`[data-segment-index="${segmentIndex}"][data-chain-index="${chainIndex}"]`)?.classList.remove("is-playing"), 1450);
      }));
      chainBar.querySelector(".classical-chain-play")?.addEventListener("click", event => {
        compositionAudio.stop();
        const playButton = event.currentTarget;
        if (playButton.dataset.playing === "true") {
          stopClassicalSequencePlayback();
          chainBar.querySelectorAll(".classical-chain-node.is-playing").forEach(node => node.classList.remove("is-playing"));
          playButton.dataset.playing = "false";
          playButton.textContent = "▶ 播放序列";
          return;
        }
        const sequence = [];
        let lastRootMidi = null;
        const playbackMode = chainBar.querySelector(".classical-chain-play-mode")?.value || "block";
        const meter = chainBar.querySelector(".classical-chain-meter")?.value || "4/4";
        const beatCount = Math.max(1, Number(meter.split("/")[0]) || 4);
        const bpm = syncClassicalTempo(chainBar.querySelector(".classical-chain-tempo-value")?.value ?? chainBar.querySelector(".classical-chain-tempo")?.value);
        const beatMs = 60000 / bpm;
        const barMs = beatMs * beatCount;
        const sequenceEntries = [];
        classicalSegments.forEach((segment, segmentIndex) => {
          const entries = new Map(classical.getPalette(segment.key, segment.mode).map(entry => [entry.symbol, entry]));
          segment.symbols.forEach((symbol, chainIndex) => {
            const entry = entries.get(symbol);
            if (!entry) return;
            sequenceEntries.push(entry);
            sequence.push({ segmentIndex, chainIndex, mode: playbackMode });
          });
        });
        if (!sequence.length) return;
        const solved = classical.voiceSequence(sequenceEntries);
        let status = chainBar.querySelector('.classical-voicing-status');
        if (!status) { status = document.createElement('div'); status.className = 'classical-voicing-status'; status.setAttribute('role', 'status'); chainBar.append(status); }
        if (!solved.ok) { status.textContent = solved.reason; return; }
        status.textContent = '四部连接已校验 B / T / A / S 固定声部 与转位低音';
        sequence.forEach((step, i) => { step.freqs = solved.voices[i].map(n => 440 * 2 ** ((n - 69) / 12)); });
        const voiceTable = document.createElement('div'); voiceTable.className = 'classical-voice-table';
        solved.voices.forEach((v,i) => { const row = document.createElement('div'); row.textContent = `${sequenceEntries[i].symbol}   ${v.map(midiName).join(' / ')}`; voiceTable.append(row); });
        status.append(voiceTable);
        stopClassicalSequencePlayback();
        const playbackId = classicalSequencePlaybackId;
        playButton.dataset.playing = "true";
        playButton.textContent = "■ 停止";
        let eventIndex = 0;
        sequence.forEach(step => {
          const arpSource = step.freqs;
          const frequencies = step.mode === "arpeggio"
            ? Array.from({ length: beatCount }, (_, index) => arpSource[index % arpSource.length]).filter(Boolean)
            : [step.freqs];
          frequencies.forEach((frequency, frequencyIndex) => {
            classicalSequenceTimers.push(setTimeout(() => {
            if (playbackId !== classicalSequencePlaybackId) return;
            chainBar.querySelectorAll(".classical-chain-node.is-playing").forEach(node => node.classList.remove("is-playing"));
            chainBar.querySelector(`[data-segment-index="${step.segmentIndex}"][data-chain-index="${step.chainIndex}"]`)?.classList.add("is-playing");
            playChord(step.mode === "arpeggio" ? [frequency] : frequency, step.mode === "arpeggio" ? 0.55 : Math.max(0.8, barMs / 1000 * 0.9), { interrupt: frequencyIndex === 0 || step.mode !== "arpeggio" });
          }, eventIndex++ * (step.mode === "arpeggio" ? beatMs : barMs)));
          });
        });
        const stepDuration = playbackMode === "arpeggio" ? beatMs : barMs;
        classicalSequenceTimers.push(setTimeout(() => {
          if (playbackId !== classicalSequencePlaybackId) return;
          chainBar.querySelectorAll(".classical-chain-node.is-playing").forEach(node => node.classList.remove("is-playing"));
          playButton.dataset.playing = "false";
          playButton.textContent = "▶ 播放序列";
          classicalSequenceTimers = [];
        }, eventIndex * stepDuration + 180));
      });
      chainBar.querySelector(".classical-chain-back")?.addEventListener("click", () => {
        if (classicalChain.length < 2) return;
        classicalChain.pop();
        document.getElementById("classical-input").value = classicalChain[classicalChain.length - 1];
        updateClassicalHarmony(targetEl);
      });
      chainBar.querySelector(".classical-chain-reset")?.addEventListener("click", () => {
        classicalSegments = [];
        classicalChain = [];
        document.getElementById("classical-input").value = "";
        updateClassicalHarmony(targetEl);
      });
      chainBar.querySelectorAll(".classical-chain-node[data-chain-index]").forEach(button => button.addEventListener("click", () => {
        const segmentIndex = Number(button.dataset.segmentIndex);
        classicalSegments = classicalSegments.slice(0, segmentIndex + 1);
        classicalSegments[segmentIndex].symbols = classicalSegments[segmentIndex].symbols.slice(0, Number(button.dataset.chainIndex) + 1);
        classicalChain = classicalSegments[segmentIndex].symbols;
        document.getElementById("classical-input").value = button.dataset.symbol;
        updateClassicalHarmony(targetEl);
      }));
      targetEl.appendChild(workbench);
      workbench.append(resultPane);
      resultPane.appendChild(chainBar);

      // The picker stays near the current sequence so users do not have to
      // scroll past recommendation cards just to choose the next function.
      const recommendationSection = document.createElement("section");
      recommendationSection.className = "classical-recommendations";

      const paths = hasInput ? classical.findPaths(input, key, mode, 4, 8) : [];
      const pathBar = document.createElement("section");
      pathBar.className = "classical-paths result-card";
      pathBar.innerHTML = `<div class="classical-palette-title">连续建议路线</div><div class="classical-path-list">${paths.map((path, index) => `<button type="button" class="classical-path" data-path-index="${index}"><span>${path.symbols.join(" → ")}</span><small>${path.symbols.length - 1} 步 · ${path.score.toFixed(1)}</small></button>`).join("")}</div>`;
      pathBar.querySelectorAll("[data-path-index]").forEach(button => button.addEventListener("click", () => {
        const selected = paths[Number(button.dataset.pathIndex)];
        classicalChain = selected.symbols;
        classicalSegments[classicalSegments.length - 1].symbols = classicalChain;
        document.getElementById("classical-input").value = selected.symbols[selected.symbols.length - 1];
        classicalActiveView = "recommendations";
        updateClassicalHarmony(targetEl);
      }));

      const modulationBar = document.createElement("section");
      modulationBar.className = "classical-modulations result-card";
      let modulationRoutes = [];
      const targetModeIsSpecific = concreteClassicalModes(modulationMode).length === 1;
      const targetMatchesCurrent = targetModeIsSpecific && modulationKey === key && comparableClassicalMode(mode) === modulationMode;
      if (hasInput && !targetMatchesCurrent) {
        modulationRoutes = concreteClassicalModes(modulationMode).flatMap(targetMode =>
          classical.suggestModulations(input, key, mode, modulationKey, targetMode, 6)
        );
      }
      const modulationTargetLabel = `${modulationKey} ${classicalModeLabel(modulationMode)}`;
      const modulationBody = !hasInput
        ? `<div class="small-muted">先输入当前和弦或点击功能组 再选择这里的转调方案 </div>`
        : targetMatchesCurrent
          ? `<div class="small-muted">目标调与当前调相同 不需要转调 </div>`
          : modulationRoutes.length
            ? modulationRoutes.map((route, index) => `<button type="button" class="classical-path modulation-path" data-modulation-index="${index}"><span>${route.sourceSymbols.join(" → ")} <b>│ Key=${route.targetKey} ${classicalModeLabel(route.targetMode)} │</b> ${route.targetSymbols.join(" → ")}</span><small>枢纽 ${route.pivot.chord} · 四部连接已校验</small></button>`).join("")
            : `<div class="small-muted">当前调性与目标调性之间没有找到可用的共同和弦枢纽 </div>`;
      modulationBar.innerHTML = `<div class="classical-palette-title">转调候选 · 到 ${modulationTargetLabel}</div><div class="small-muted classical-modulation-hint">点击下面的方案才会把转调路线加入连续和声连接 上方选项只负责指定目标调 </div><div class="classical-path-list">${modulationBody}</div>`;
      modulationBar.querySelectorAll("[data-modulation-index]").forEach(button => button.addEventListener("click", () => {
        const selected = modulationRoutes[Number(button.dataset.modulationIndex)];
        const sourceSegment = classicalSegments[classicalSegments.length - 1];
        sourceSegment.symbols = [...sourceSegment.symbols, ...selected.sourceSymbols.slice(1)];
        document.getElementById("classical-key").value = selected.targetKey;
        document.getElementById("classical-mode").value = selected.targetMode;
        classicalLastKey = selected.targetKey;
        classicalLastMode = selected.targetMode;
        classicalSegments.push({ key: selected.targetKey, mode: selected.targetMode, symbols: selected.targetSymbols });
        document.getElementById("classical-input").value = selected.targetSymbols[selected.targetSymbols.length - 1];
        classicalActiveView = "recommendations";
        updateClassicalHarmony(targetEl);
      }));

      // The reference Sposobin UI exposes the whole functional DNA as a
      // palette. Clicking a symbol makes it the current chord and refreshes
      // the exact next-chord recommendations for that node.
      const palette = classical.getPalette(key, mode);
      const paletteWrap = document.createElement("section");
      paletteWrap.className = "classical-palette result-card";
      const groups = [
        ["tonic group", "主功能组(T / DT)"],
        ["subdominant group", "下属功能组(S / TSVI / VII)"],
        ["dominant group", "属功能组(D / K)"],
        ["leading-tone group", "导功能组(Dᵥᵢᵢ)"],
        ["altered chord group", "变和弦组(N / +6)"],
        ["double dominant", "重属功能组(DD)"]
      ];
      const grouped = new Map(groups.map(([id, label]) => [id, { label, entries: [] }]));
      const tonicized = new Map();
      palette.forEach(entry => {
        if (entry.symbol.includes("/")) {
          const target = entry.symbol.split("/")[1];
          if (!tonicized.has(target)) tonicized.set(target, []);
          tonicized.get(target).push(entry);
        } else if (grouped.has(entry.category)) grouped.get(entry.category).entries.push(entry);
      });
      const makeGroup = (label, entries, extraClass = "") => {
        if (!entries.length) return "";
        const buttons = entries.map(entry => `<button type="button" class="classical-palette-btn ${extraClass}" data-classical-symbol="${entry.symbol}"><span>${entry.symbol}</span><small>${entry.roman || ""}${entry.chord ? ` · ${entry.chord}` : ""}</small></button>`).join("");
        return `<div class="classical-palette-group"><h4>${label}</h4><div class="classical-palette-grid">${buttons}</div></div>`;
      };
      const availableGroups = groups.filter(([id]) => grouped.get(id)?.entries.length);
      paletteWrap.innerHTML = `<div class="classical-palette-title">Sposobin 功能组</div><div class="classical-function-tabs">${availableGroups.map(([id]) => `<button type="button" class="classical-function-tab" data-function-group="${id}">${grouped.get(id).label.replace(/[（(].*$/, "")} <span>${grouped.get(id).entries.length}</span></button>`).join("")}</div><div class="classical-function-list"></div><div class="classical-palette-tonicization"><h4>离调与变音体系</h4><div class="classical-tonicization-tabs">${["II", "III", "IV", "V", "VI"].map(target => `<button type="button" class="classical-tonicization-tab" data-tonic-target="${target}">至 ${target} 级 <span>${(tonicized.get(target) || []).length}</span></button>`).join("")}</div><div class="classical-tonicization-list"></div></div>`;
      const appendClassicalSymbol = symbol => {
        const activeSegment = classicalSegments[classicalSegments.length - 1] || { key, mode, symbols: [] };
        if (!classicalSegments.length) classicalSegments.push(activeSegment);
        activeSegment.symbols.push(symbol);
        classicalChain = activeSegment.symbols;
        document.getElementById("classical-input").value = symbol;
        classicalActiveView = "recommendations";
        updateClassicalHarmony(targetEl);
      };
      const bindClassicalSymbolButtons = root => {
        root.querySelectorAll("[data-classical-symbol]").forEach(button => button.addEventListener("click", () => {
          appendClassicalSymbol(button.dataset.classicalSymbol);
        }));
      };
      const functionList = paletteWrap.querySelector(".classical-function-list");
      const renderFunctionGroup = id => {
        const group = grouped.get(id);
        if (!group) return;
        paletteWrap.querySelectorAll(".classical-function-tab").forEach(tab => tab.classList.toggle("active", tab.dataset.functionGroup === id));
        functionList.innerHTML = makeGroup(group.label, group.entries);
        bindClassicalSymbolButtons(functionList);
      };
      paletteWrap.querySelectorAll(".classical-function-tab").forEach(button => button.addEventListener("click", () => {
        renderFunctionGroup(button.dataset.functionGroup);
      }));
      const tonicList = paletteWrap.querySelector(".classical-tonicization-list");
      const renderTonicization = target => {
        tonicList.innerHTML = makeGroup(`副属和弦 · 至 ${target} 级`, tonicized.get(target) || [], "classical-tonicization-btn");
        bindClassicalSymbolButtons(tonicList);
      };
      paletteWrap.querySelectorAll(".classical-tonicization-tab").forEach(button => button.addEventListener("click", () => {
        paletteWrap.querySelectorAll(".classical-tonicization-tab").forEach(tab => tab.classList.remove("active"));
        button.classList.add("active");
        renderTonicization(button.dataset.tonicTarget);
      }));
      if (availableGroups.length) renderFunctionGroup(availableGroups[0][0]);
      pickerPane.appendChild(paletteWrap);

      const summary = document.createElement("div");
      summary.className = "classical-summary result-card";
      const modeLabel = classicalModeLabel(mode);
      summary.innerHTML = report
        ? `<div class="classical-summary-title">${key} ${modeLabel} · ${displayClassicalSymbol(report.current.symbol || input, true)}</div><div class="small-muted">${localizeClassicalText(report.constraints)}</div><div class="classical-current-meta">${localizeClassicalText(report.current.category || "unclassified")} · 功能 ${report.current.function || "—"} · 低音 ${report.current.bass || report.current.notes?.[0] || "—"}</div>`
        : `<div class="classical-summary-title">${key} ${modeLabel}</div><div class="small-muted">请选择或输入一个和弦 开始查看连续连接建议 </div>`;
      resultPane.appendChild(summary);

      const heading = document.createElement("div");
      heading.className = "classical-list-heading";
      heading.textContent = report ? `推荐衔接 · ${report.recommendations.length}` : "推荐衔接";
      recommendationSection.appendChild(heading);

      const list = document.createElement("div");
      list.className = "classical-rec-list";
      (report?.recommendations || []).forEach((item) => {
        const card = document.createElement("article");
        card.className = "classical-rec-card result-card";
        card.tabIndex = 0;
        card.setAttribute("role", "button");
        card.setAttribute("aria-label", `将 ${item.symbol} ${item.roman} ${item.chord} 加入连续和声连接`);
        card.title = "加入连续和声连接";
        const toneButtons = (item.notes || []).map(note => `<button type="button" class="classical-note" data-classical-note="${note}">${note}</button>`).join("");
        card.innerHTML = `<div class="classical-rec-top"><div><strong>${item.symbol}</strong><span class="classical-roman-name">${item.roman || item.symbol}</span><span class="classical-chord-name">${item.chord}</span></div><div class="classical-rec-actions"><span class="classical-score">${item.score.toFixed(1)}</span><span class="classical-add" aria-hidden="true">+</span></div></div><div class="classical-tags"><span>${localizeClassicalText(item.category)}</span><span>功能 ${item.function}</span><span>转位 ${item.figuredBass || "根位"}</span><span>低音 ${item.bass || "—"}</span></div><div class="classical-notes">${toneButtons}</div><div class="classical-meta">共同音 ${item.commonTones} · 声部距离 ${item.voiceLeading}</div><button type="button" class="classical-play" title="播放和弦">▶ 播放</button>`;
        const appendRecommendation = () => {
          const activeSegment = classicalSegments[classicalSegments.length - 1] || { key, mode, symbols: [] };
          if (!classicalSegments.length) classicalSegments.push(activeSegment);
          // Always mutate the segment that is rendered, not a stale alias.
          // This preserves K64 → D6 and longer recommendation chains.
          if (!activeSegment.symbols.length) activeSegment.symbols.push(input || report?.current?.symbol || item.symbol);
          activeSegment.symbols.push(item.symbol);
          classicalChain = activeSegment.symbols;
          classicalPendingChain = { key, mode, symbols: activeSegment.symbols.slice() };
          document.getElementById("classical-input").value = item.symbol;
          classicalActiveView = "recommendations";
          updateClassicalHarmony(targetEl);
        };
        card.addEventListener("click", event => {
          if (event.target.closest("button")) return;
          appendRecommendation();
        });
        card.addEventListener("keydown", event => {
          if (event.key !== "Enter" && event.key !== " ") return;
          event.preventDefault();
          appendRecommendation();
        });
        card.querySelector(".classical-play")?.addEventListener("click", () => {
          stopClassicalSequencePlayback();
          if (item.previousVoicing?.length) {
            const events = [item.previousVoicing, item.midiVoicing].flatMap((v,i) => v.map(midi => ({midi,beat:i*2,duration:1.8,velocity:.65})));
            compositionAudio.play(events,90,4,()=>{});
          } else playChord(classicalMidiFreqs(item));
        });
        const voiceLabel = document.createElement('div'); voiceLabel.className = 'classical-meta'; voiceLabel.textContent = `B / T / A / S  ${(item.midiVoicing || []).map(midiName).join(' / ')}`; card.append(voiceLabel);
        card.querySelector('.classical-play').textContent = '▶ 试听四部连接';
        card.querySelectorAll("[data-classical-note]").forEach(button => button.addEventListener("click", () => {
          playChord([noteToFrequency(button.dataset.classicalNote)], 0.7);
        }));
        list.appendChild(card);
      });
      recommendationSection.appendChild(list);

      const viewTabs = document.createElement("div");
      viewTabs.className = "classical-view-tabs";
      viewTabs.setAttribute("role", "tablist");
      const viewDefinitions = [
        ["recommendations", "推荐", report?.recommendations?.length || 0],
        ["paths", "路线", paths.length],
        ["modulations", "转调", modulationRoutes.length],
        ["palette", "功能库", palette.length],
      ];
      viewTabs.innerHTML = viewDefinitions.map(([id, label, count]) => `<button type="button" class="classical-view-tab" data-classical-view="${id}" role="tab"><span>${label}</span><small>${count}</small></button>`).join("");

      const viewStage = document.createElement("div");
      viewStage.className = "classical-view-stage";
      const viewPanels = new Map();
      viewDefinitions.forEach(([id]) => {
        const panel = document.createElement("div");
        panel.className = "classical-view-panel";
        panel.dataset.classicalViewPanel = id;
        panel.setAttribute("role", "tabpanel");
        viewPanels.set(id, panel);
        viewStage.appendChild(panel);
      });
      viewPanels.get("recommendations").appendChild(recommendationSection);
      viewPanels.get("paths").appendChild(pathBar);
      viewPanels.get("modulations").appendChild(modulationBar);
      viewPanels.get("palette").appendChild(paletteWrap);
      resultPane.append(viewTabs, viewStage);

      const setClassicalView = view => {
        classicalActiveView = viewPanels.has(view) ? view : "recommendations";
        viewTabs.querySelectorAll("[data-classical-view]").forEach(button => {
          const active = button.dataset.classicalView === classicalActiveView;
          button.classList.toggle("active", active);
          button.setAttribute("aria-selected", String(active));
        });
        viewPanels.forEach((panel, id) => {
          panel.hidden = id !== classicalActiveView;
        });
      };
      viewTabs.querySelectorAll("[data-classical-view]").forEach(button => button.addEventListener("click", () => {
        setClassicalView(button.dataset.classicalView);
      }));
      setClassicalView(hasInput ? classicalActiveView : "palette");
    } catch (error) {
      targetEl.innerHTML = `<div class="result-card classical-error">${error.message}</div>`;
    }
  }

  document.getElementById("classical-run")?.addEventListener("click", () => {
    classicalActiveView = "recommendations";
    updateClassicalHarmony(document.getElementById("panel-classical-body"));
  });
  document.getElementById("classical-input")?.addEventListener("keydown", event => {
    if (event.key === "Enter") document.getElementById("classical-run")?.click();
  });
  document.getElementById("classical-key")?.addEventListener("change", () => {
    updateClassicalHarmony(document.getElementById("panel-classical-body"));
  });
  document.getElementById("classical-mode")?.addEventListener("change", () => {
    updateClassicalHarmony(document.getElementById("panel-classical-body"));
  });
  document.getElementById("classical-mod-key")?.addEventListener("change", () => {
    updateClassicalHarmony(document.getElementById("panel-classical-body"));
  });
  document.getElementById("classical-mod-mode")?.addEventListener("change", () => {
    updateClassicalHarmony(document.getElementById("panel-classical-body"));
  });

  document.getElementById("chord-run").addEventListener("click", () => {
    const target = document.getElementById("panel-chord-body");
    const val = document.getElementById("chord-input").value;
    try {
      if (!val.trim()) throw new Error('empty');
      prettyChordRender(target, val);
      document.getElementById('chord-input').removeAttribute('aria-invalid');
    } catch {
      target.innerHTML = `<p class="input-error" role="alert">${window.__("chord_input_error")}</p>`;
      document.getElementById('chord-input').setAttribute('aria-invalid', 'true');
    }
  });
  document.getElementById('chord-input').addEventListener('keydown', event => {
    if (event.key === 'Enter') { event.preventDefault(); document.getElementById('chord-run').click(); }
  });
  document.querySelectorAll('[data-chord-example]').forEach(button => {
    button.addEventListener('click', () => {
      document.getElementById('chord-input').value = button.dataset.chordExample;
      document.getElementById('chord-run').click();
    });
  });
  document.getElementById("blues-run").addEventListener("click", () => {
    const target = document.getElementById("panel-blues-body");
    const val = document.getElementById("blues-input").value;
    updateBlues(target, val);
  });
  document.getElementById("lcc-run").addEventListener("click", () => {
    const target = document.getElementById("panel-lcc-body");
    const val = document.getElementById("lcc-input").value;
    updateLCC(target, val);
  });
  document.getElementById("cst-run").addEventListener("click", () => {
    const target = document.getElementById("panel-cst-body");
    const val = document.getElementById("cst-input").value;
    updateCST(target, val);
  });
  // add/remove behavior for key center chord inputs
  document
    .getElementById("add-keycenter-chord")
    .addEventListener("click", () => {
      const container = document.getElementById("keycenter-inputs");
      const entry = createKeyCenterEntry("");
      container.insertBefore(
        entry,
        document.getElementById("add-keycenter-chord"),
      );
    });

  document.getElementById("other-run").addEventListener("click", () => {
    const target = document.getElementById("panel-other-body");
    let val;
    if (
      currentOtherMode === "key_center" ||
      currentOtherMode === "progression" ||
      currentOtherMode === "guide"
    ) {
      // 这三种模式都从“可增删”列表收集和弦
      val = getKeyCenterValue();
    } else {
      val = document.getElementById("other-input").value;
    }
    processOther(target, val);
  });

  // 和弦衔接推荐面板 - 按钮事件绑定
  const recRunBtn = document.getElementById("rec-run");
  const recInput = document.getElementById("rec-input");
  const recPanelBody = document.getElementById("panel-rec-body");

  if (recRunBtn && recInput && recPanelBody) {
    recRunBtn.addEventListener("click", () => {
      const inputVal = recInput.value.trim();
      updateRec(recPanelBody, inputVal);
    });

    // 支持回车触发
    recInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        recRunBtn.click();
      }
    });
  }

  // 初始化默认显示第一个面板（保持原有逻辑）
  mountMicrotonal(playChord, createHeldPianoVoice);
  const defaultFeature =
    navButtons.length > 0 ? navButtons[0].dataset.feature : "chord";
  showOnlyFeature(defaultFeature);

  showOnlyFeature("chord");
  document.getElementById('chord-run').click();
  document.getElementById('cst-run').click();
  document.getElementById('lcc-run').click();
  document.getElementById('blues-run').click();
});
